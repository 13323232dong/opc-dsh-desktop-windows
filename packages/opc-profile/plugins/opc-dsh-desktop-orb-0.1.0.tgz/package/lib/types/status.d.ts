/** Minimal desktop-safe projection of the live DSH runtime. */
export type DesktopOrbState = 'idle' | 'running' | 'approval_required' | 'error';
export interface DesktopMember {
    readonly name: string;
    readonly status: 'running' | 'idle' | 'inactive' | 'provisioning' | 'failed';
}
export interface DesktopTask {
    readonly sessionId: string;
    readonly title: string;
    readonly status: DesktopOrbState;
    readonly members: readonly DesktopMember[];
    readonly latestResult?: string;
    readonly approval?: string;
}
export interface DesktopStatusSnapshot {
    readonly state: DesktopOrbState;
    readonly updatedAt: string;
    readonly activeCount: number;
    readonly task?: DesktopTask;
}
export interface RuntimeSession {
    readonly id: string;
    readonly events: readonly RuntimeEvent[];
}
export interface RuntimeAgent {
    readonly id: string;
    readonly status: 'running' | 'idle';
    readonly session: RuntimeSession;
}
export interface RuntimeEvent {
    readonly type: string;
    readonly time?: number;
    readonly data?: unknown;
}
export interface TeamReader {
    listMembers(agent: RuntimeAgent): readonly DesktopMember[];
}
/** Derive an owned, non-sensitive desktop snapshot from live agents. */
export declare function reduceDesktopStatus(agents: readonly RuntimeAgent[], teamReader: TeamReader | undefined, now?: Date): DesktopStatusSnapshot;
