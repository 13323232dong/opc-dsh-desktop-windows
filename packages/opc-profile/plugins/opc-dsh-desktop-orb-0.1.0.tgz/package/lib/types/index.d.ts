/** Loopback-only status endpoint consumed by the local OPC desktop orb. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "opc-desktop-orb";
export declare const inject: string[];
export interface Config {
    routePath: string;
}
export declare const Config: z<Schemastery.ObjectS<{
    routePath: z<string, string>;
}>, Schemastery.ObjectT<{
    routePath: z<string, string>;
}>>;
/** Register the local read-only runtime summary route. */
export declare function apply(ctx: Context, config: Config): void;
