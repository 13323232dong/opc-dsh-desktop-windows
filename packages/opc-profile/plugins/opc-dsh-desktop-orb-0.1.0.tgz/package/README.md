# OPC Desktop Orb

`@opc/dsh-desktop-orb` is a DSH host plugin that exposes a loopback-only `GET /opc-desktop/status` endpoint for the local macOS desktop orb.

The response contains only a task title, runtime state, team member states, the latest assistant result summary, and an outstanding approval summary. It never returns provider credentials or full session transcripts.
