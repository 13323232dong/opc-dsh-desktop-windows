declare global {
    interface Window {
        dshViralChase?: {
            open: () => Promise<{
                ok: true;
            }>;
        };
    }
}
export declare function ViralChaseLauncher(): JSX.Element;
