import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

test('wechat search waits for asynchronous AX value and submits the query', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /for _ in 0\.\.<8[\s\S]*attr\(search, "AXValue"\) == title/)
  assert.match(source, /AXUIElementSetAttributeValue\(search, "AXValue" as CFString, title as CFTypeRef\)/)
  assert.match(source, /guard received else \{ try fail\("WECHAT_SEARCH_UNAVAILABLE"/)
  assert.match(source, /guard received else[\s\S]*try key\(36\); pause\(0\.25\)/)
})
