export interface BillingContext {
    readonly conversationId: string;
    readonly rootConversationId?: string;
    readonly agentId?: string;
    readonly actionId?: string;
    readonly actionName?: string;
}
interface RuntimeSession {
    readonly id: string;
    readonly header: {
        readonly parentSession?: string;
        readonly origin?: 'subagent';
    };
}
export declare function runtimeBillingContext(session: RuntimeSession, findSession: (id: string) => RuntimeSession | undefined, action?: Omit<BillingContext, 'conversationId' | 'rootConversationId'>): BillingContext;
export declare function billingContextHeader(context: BillingContext): string;
export declare function toolBillingKey(sessionId: string, callId?: string): string;
export {};
