import { type ProductionEngine, type ProtagonistAnchor, type ShotImagesAggregate, type StoryboardRow, type ViralChaseJob, type ViralProductionApproval, type ViralProductionQuote, type ViralProductionRun, type ViralRuntimeStatus } from './workbench-model.js';
export type ViralVoiceSettingsInput = {
    readonly source: 'system';
    readonly voiceId: string;
    readonly languageBoost: 'Chinese' | 'Chinese,Yue' | 'English' | 'auto';
    readonly speed: number;
    readonly pitch: number;
    readonly volume: number;
    readonly configVersion: 'viral-voice-v1';
} | {
    readonly source: 'protagonist_clone';
    readonly languageBoost: 'Chinese' | 'Chinese,Yue' | 'English' | 'auto';
    readonly speed: number;
    readonly pitch: number;
    readonly volume: number;
    readonly configVersion: 'viral-voice-v1';
} | {
    readonly source: 'user_clone';
    readonly cloneId: string;
    readonly languageBoost: 'Chinese' | 'Chinese,Yue' | 'English' | 'auto';
    readonly speed: number;
    readonly pitch: number;
    readonly volume: number;
    readonly configVersion: 'viral-voice-v1';
};
export interface VoiceCloneSummary {
    readonly id: string;
    readonly name: string;
    readonly status: 'creating' | 'active' | 'failed' | 'deleted';
    readonly languageBoost: 'Chinese' | 'Chinese,Yue' | 'English' | 'auto';
    readonly previewUrl: string | null;
}
export interface VoiceRunInput {
    readonly voiceSettings?: ViralVoiceSettingsInput;
}
export interface ViralAudioPreview {
    readonly id: string;
    readonly status: 'quoted' | 'approved' | 'running' | 'succeeded' | 'failed' | 'stale';
    readonly scriptRevision: number;
    readonly voiceId: string;
    readonly speed: number;
    readonly pitch: number;
    readonly volume: number;
    readonly estimatedCredits: number;
    readonly contentHash: string;
    readonly approvalToken?: string;
    readonly audioUrl?: string;
    readonly durationMs?: number | null;
    readonly error?: string;
}
interface ViralJobEventHandlers {
    readonly onJob: (job: ViralChaseJob) => void;
    readonly onOpen: () => void;
    readonly onError: () => void;
}
interface EventSourceLike {
    addEventListener(type: string, listener: (event: Event) => void): void;
    close(): void;
}
type EventSourceFactory = (url: string) => EventSourceLike;
export declare function safeApiError(code: string | undefined, status: number): string;
export declare function runPreparationStep(sessionId: string, job: Pick<ViralChaseJob, 'id' | 'plan'>, step: 'extract' | 'rewrite', input: Readonly<Record<string, unknown>>): Promise<ViralChaseJob>;
export declare function cancelPreparationStep(sessionId: string, jobId: string, step: 'extract' | 'rewrite' | 'speech' | 'seedance_avatar' | 'edit' | 'metadata' | 'cover' | 'publish'): Promise<ViralChaseJob>;
/** Runs an already-approved creative step. The API remains the source of truth for all gates and costs. */
export declare function runCreativeStep(sessionId: string, job: Pick<ViralChaseJob, 'id' | 'plan'>, step: 'speech' | 'cover', input?: VoiceRunInput | ViralVoiceSettingsInput): Promise<ViralChaseJob>;
export declare function quoteAudioPreview(sessionId: string, jobId: string, input: {
    voiceId: string;
    speed: number;
    pitch: number;
    volume: number;
}): Promise<ViralAudioPreview>;
export declare function approveAudioPreview(sessionId: string, jobId: string, input: {
    previewId: string;
    previewHash: string;
    maxCost: number;
}): Promise<ViralAudioPreview>;
export declare function startAudioPreview(sessionId: string, jobId: string, approvalToken: string): Promise<ViralAudioPreview>;
export declare function loadViralJobs(sessionId: string, signal?: AbortSignal): Promise<ViralChaseJob[]>;
export declare function createViralJob(sessionId: string, input: {
    readonly sourceUrl?: string;
    readonly sourceText?: string;
}, idempotencyKey?: string): Promise<ViralChaseJob>;
export declare function subscribeViralJobEvents(sessionId: string, jobId: string, handlers: ViralJobEventHandlers, createSource?: EventSourceFactory): () => void;
export declare function saveScript(sessionId: string, jobId: string, input: {
    title: string;
    rows: readonly StoryboardRow[];
}): Promise<unknown>;
export declare function approveViralPlan(sessionId: string, jobId: string, input: {
    planId: string;
    revision: number;
}): Promise<unknown>;
export declare function saveShotPlan(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function requestPreproductionReview(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveGeneration(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function startGeneration(sessionId: string, job: ViralChaseJob): Promise<unknown>;
export declare function requestFinalReview(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveFinalDelivery(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function loadJobRevisions(sessionId: string, jobId: string): Promise<unknown>;
export declare function requestShotRevision(sessionId: string, jobId: string, input: {
    readonly finalReviewRevision: number;
    readonly shotNumbers: readonly string[];
    readonly reason: string;
}): Promise<unknown>;
export declare function loadShotImages(sessionId: string, jobId: string, signal?: AbortSignal): Promise<ShotImagesAggregate>;
export declare function quoteShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function runShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function rerunShotImage(sessionId: string, jobId: string, shotNumber: string, input: object): Promise<unknown>;
export declare function cancelShotImageRun(sessionId: string, jobId: string, runId: string): Promise<unknown>;
export declare function loadProtagonistAnchors(sessionId: string, signal?: AbortSignal): Promise<ProtagonistAnchor[]>;
export declare function uploadProtagonistVideo(sessionId: string, file: File): Promise<{
    readonly uploadId: string;
}>;
export declare function createProtagonistAnchor(sessionId: string, input: {
    readonly name: string;
    readonly uploadId: string;
}): Promise<ProtagonistAnchor>;
export declare function authorizeProtagonistAnchor(sessionId: string, anchorId: string): Promise<unknown>;
export declare function recheckProtagonistAnchor(sessionId: string, anchorId: string): Promise<unknown>;
export declare function revokeProtagonistAnchor(sessionId: string, anchorId: string): Promise<unknown>;
export declare function loadRuntimeStatus(sessionId: string, signal?: AbortSignal): Promise<ViralRuntimeStatus>;
export declare function quoteProduction(sessionId: string, jobId: string, input: {
    readonly protagonistAnchorId: string;
    readonly engine: ProductionEngine;
    readonly scriptRevision: number;
    readonly shotPlanRevision: number;
    readonly reviewRevision: number;
    readonly targetDurationSeconds?: number;
    readonly voiceSettings?: ViralVoiceSettingsInput;
}): Promise<ViralProductionQuote>;
export declare function loadVoiceClones(sessionId: string): Promise<readonly VoiceCloneSummary[]>;
export declare function uploadVoiceCloneSource(sessionId: string, file: File): Promise<string>;
export declare function createVoiceClone(sessionId: string, input: {
    name: string;
    sourceUploadId: string;
    previewText: string;
    authorization: {
        voiceOwnerConfirmed: true;
        syntheticUseConfirmed: true;
    };
}): Promise<VoiceCloneSummary>;
export declare function approveProduction(sessionId: string, jobId: string, input: {
    readonly quoteId: string;
    readonly quoteHash: string;
    readonly maxCost: number;
}): Promise<ViralProductionApproval>;
export declare function startProduction(sessionId: string, jobId: string, input: {
    readonly approvalToken: string;
}): Promise<ViralProductionRun>;
export declare function loadProductionStatus(sessionId: string, jobId: string, signal?: AbortSignal): Promise<{
    readonly quote?: ViralProductionQuote;
    readonly approval?: ViralProductionApproval;
    readonly run?: ViralProductionRun;
}>;
export declare function cancelProduction(sessionId: string, jobId: string): Promise<unknown>;
export declare function retryProductionStep(sessionId: string, jobId: string, step: string): Promise<unknown>;
export declare function exportProduction(sessionId: string, jobId: string, input: {
    readonly finalReviewRevision: number;
    readonly finalApprovalToken: string;
}): Promise<unknown>;
export declare function protectedViralMediaUrl(sessionId: string, path: string): string;
export {};
