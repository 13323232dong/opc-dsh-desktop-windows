export type PreparationStepKey = 'extract' | 'rewrite';
export type WorkflowStepKey = PreparationStepKey | 'speech' | 'seedance_avatar' | 'edit' | 'metadata' | 'cover' | 'publish';
interface PreparationFlowModalProps {
    readonly step: WorkflowStepKey;
    readonly status: string;
    readonly progress?: number;
    readonly needsApproval: boolean;
    readonly message: string;
    readonly error?: string | null;
    readonly sourceNote?: string;
    readonly preparing?: boolean;
    readonly resultText?: string;
    readonly resultSource?: string;
    readonly onResultChange?: (value: string) => void;
    readonly onContinueRewrite?: () => void;
    readonly onReturn?: () => void;
    readonly stepStates?: Record<string, string>;
    readonly startedAt?: number;
    readonly busy?: boolean;
    readonly onApprove: () => void;
    readonly onCancel: () => void;
    readonly onRetry: () => void;
    readonly onBackground: () => void;
    readonly onClose: () => void;
}
export declare function PreparationFlowModal(props: PreparationFlowModalProps): JSX.Element;
export {};
