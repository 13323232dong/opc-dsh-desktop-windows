import type { ViralChaseJob } from './workbench-model.js';
export interface PreparationMetadata {
    readonly startedAt?: number;
    readonly error?: string;
}
export declare function updatePreparationMetadata(previous: Readonly<Record<string, PreparationMetadata>>, jobId: string, step: string, patch: PreparationMetadata): Record<string, PreparationMetadata>;
/** Keep SSE updates newer than an overlapping list or execution response. */
export declare function mergePreparationJobs(previous: readonly ViralChaseJob[], incoming: readonly ViralChaseJob[]): ViralChaseJob[];
export declare function preparationLabel(job: ViralChaseJob | undefined, step: string, creating: boolean, failed: boolean): string;
