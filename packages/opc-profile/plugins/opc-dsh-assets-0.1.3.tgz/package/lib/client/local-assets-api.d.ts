export type LocalAssetKind = 'brand' | 'material' | 'knowledge';
export interface LocalAssetRecord {
    readonly id: string;
    readonly kind: LocalAssetKind;
    readonly name: string;
    readonly status: string;
    readonly storage: 'local';
    readonly privacy: '本地保存';
    readonly syncStatus?: string;
    readonly indexStatus?: string;
    readonly metadata?: Record<string, unknown>;
    readonly relativePath?: string;
    readonly mimeType?: string;
    readonly size?: number;
    readonly createdAt?: string;
    readonly updatedAt?: string;
}
export declare class LocalAssetsUnavailableError extends Error {
    readonly code = "local_assets_unavailable";
    constructor(message?: string);
}
export declare const localAssetsStatus: (sessionId: string) => Promise<Record<string, unknown>>;
export declare const localAssetsList: (sessionId: string, input?: Record<string, unknown>) => Promise<LocalAssetRecord[]>;
export declare const localAssetsGet: (sessionId: string, id: string) => Promise<LocalAssetRecord>;
export declare const localAssetsWrite: (sessionId: string, operation: string, input: Record<string, unknown>) => Promise<LocalAssetRecord>;
export declare const localAssetsArchive: (sessionId: string, id: string, archived: boolean) => Promise<LocalAssetRecord>;
export declare const localAssetsSearch: (sessionId: string, query: string, input?: Record<string, unknown>) => Promise<LocalAssetRecord[]>;
export declare const localAssetsExport: (sessionId: string) => Promise<Record<string, unknown>>;
export declare const localAssetsImport: (sessionId: string) => Promise<Record<string, unknown>>;
