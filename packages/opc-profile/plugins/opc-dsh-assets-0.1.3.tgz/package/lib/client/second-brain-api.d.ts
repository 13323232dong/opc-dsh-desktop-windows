export type SecondBrainState = 'not_created' | 'creating' | 'ready' | 'indexing' | 'failed' | 'unavailable';
export interface SecondBrainSnapshot {
    supported: boolean;
    status: SecondBrainState;
    rootPath: string;
    version: string;
    fileCount: number;
    indexedFileCount: number;
    lastIndexedAt: string | null;
    obsidianAvailable: boolean;
    errorCode: string | null;
    libraryMode: 'managed' | 'linked';
    result?: 'created' | 'already_exists';
    openedWith?: 'file-manager' | 'obsidian';
}
export declare const getSecondBrainStatus: () => Promise<SecondBrainSnapshot>;
export declare const createSecondBrain: () => Promise<SecondBrainSnapshot>;
export declare const linkExistingSecondBrain: (rootPath: string) => Promise<SecondBrainSnapshot>;
export declare const openSecondBrain: () => Promise<SecondBrainSnapshot>;
export declare const openSecondBrainInObsidian: () => Promise<SecondBrainSnapshot>;
export declare const rebuildSecondBrainIndex: () => Promise<SecondBrainSnapshot>;
