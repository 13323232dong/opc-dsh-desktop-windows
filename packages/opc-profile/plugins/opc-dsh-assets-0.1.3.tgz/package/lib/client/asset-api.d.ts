export type AssetKind = 'material' | 'work' | 'knowledge';
export interface AssetRecord {
    id: string;
    kind: string;
    name: string;
    status: string;
    metadata: Record<string, unknown>;
    sourceTool: string;
    sourceToolVersion: string;
    sourceAgentId: string | null;
    sourceSessionId: string | null;
    operationId: string | null;
    createdAt: string;
    updatedAt: string;
    url?: string;
    mimeType?: string;
    size?: number;
    storage?: 'local' | 'server';
    privacy?: '本地保存' | '服务器保存';
    syncStatus?: string;
    indexStatus?: string;
}
export interface AssetOperation {
    id: string;
    assetId: string | null;
    toolName: string;
    toolVersion: string;
    status: string;
    progress: number;
    stage: string | null;
    durationMs: number | null;
    costCents: number | null;
    errorCode: string | null;
    createdAt: string;
    completedAt: string | null;
}
export interface KnowledgeDocument {
    id: string;
    title: string;
    sourceType: string;
    sourceName?: string | null;
    version: number;
    updatedAt: string;
    chunks: Array<{
        id: string;
        question: string;
        answer: string;
        tags: string[];
        priority: number;
        version: number;
    }>;
    _count?: {
        chunks: number;
    };
}
export interface KnowledgeMatch {
    id: string;
    documentId: string;
    documentVersion: number;
    question: string;
    answer: string;
    tags: string[];
    score: number;
    matchedKeywords: string[];
}
export declare function encodeFileNameHeader(fileName: string): string;
export declare function pickLocalFile(): Promise<string | null>;
export declare const listAssets: (sessionId: string, params?: {
    kind?: string;
    query?: string;
    includeArchived?: boolean;
}) => Promise<AssetRecord[]>;
export declare const createAsset: (sessionId: string, input: {
    name: string;
    kind: "work";
    content?: string;
    metadata?: Record<string, unknown>;
}) => Promise<AssetRecord>;
export declare const updateAsset: (sessionId: string, id: string, input: {
    kind?: string;
    name?: string;
    content?: string;
    metadata?: Record<string, unknown>;
    status?: string;
}) => Promise<AssetRecord>;
export declare const setAssetArchived: (sessionId: string, id: string, archived: boolean, storage?: "local" | "server") => Promise<AssetRecord>;
export declare const assetOperations: (sessionId: string, id: string) => Promise<AssetOperation[]>;
export declare function uploadAsset(sessionId: string): Promise<AssetRecord | undefined>;
export declare const uploadAssetFromLocalPath: (sessionId: string, filePath: string, mimeType?: string) => Promise<AssetRecord>;
export declare const listKnowledge: (sessionId: string) => Promise<KnowledgeDocument[]>;
export declare const getKnowledge: (sessionId: string, id: string) => Promise<KnowledgeDocument>;
export declare const createKnowledge: (sessionId: string, input: {
    title: string;
    content: string;
    format: string;
    sourceName?: string;
}) => Promise<KnowledgeDocument>;
export declare const updateKnowledge: (sessionId: string, id: string, input: {
    title?: string;
    content?: string;
    format?: string;
}) => Promise<KnowledgeDocument>;
export declare const deleteKnowledge: (sessionId: string, id: string) => Promise<{
    id: string;
    deleted: boolean;
}>;
export declare const searchKnowledge: (sessionId: string, query: string) => Promise<KnowledgeMatch[]>;
export declare const importKnowledgeFromLocalPath: (sessionId: string, filePath: string, title?: string) => Promise<KnowledgeDocument>;
