export declare function SecondBrainPanel(): JSX.Element;
