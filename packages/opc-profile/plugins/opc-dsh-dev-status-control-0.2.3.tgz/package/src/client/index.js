import React from 'react'

export const inject = ['slots']

const PLUGIN_PATH = '/plugins/opc-dev-status-control'
const STORAGE_KEY = 'opc-dev-status-control.workspace-id'

function boardRequest(path) {
  return fetch(`${PLUGIN_PATH}${path}`, { credentials: 'same-origin', cache: 'no-store' }).then(async (response) => {
    const payload = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(payload.error ?? '本机 Codex 控制服务未启动')
    return payload
  })
}

function storedWorkspace() { try { return globalThis.localStorage?.getItem(STORAGE_KEY) ?? '' } catch { return '' } }
function storeWorkspace(id) { try { globalThis.localStorage?.setItem(STORAGE_KEY, id) } catch {} }

function relativeTime(value) {
  const minutes = Math.max(0, Math.floor((Date.now() - Number(value)) / 60_000))
  if (!Number.isFinite(minutes)) return '未知'
  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes} 分钟前`
  if (minutes < 1440) return `${Math.floor(minutes / 60)} 小时前`
  return `${Math.floor(minutes / 1440)} 天前`
}

function sessionTitle(session) {
  const title = String(session?.title ?? '').trim()
  return title && title !== '未命名任务' ? title : `未命名会话 · ${String(session?.id ?? '').slice(0, 8)}`
}

function openCodexThread(id, event) {
  event?.preventDefault()
  window.open(`codex://threads/${encodeURIComponent(id)}`, '_blank', 'noopener,noreferrer')
}

function badge(label, active = false) {
  return React.createElement('span', { style: { background: active ? '#e3f5ed' : '#edf1ef', borderRadius: 4, color: active ? '#087451' : '#58635f', fontSize: 12, fontWeight: 650, padding: '5px 9px', whiteSpace: 'nowrap' } }, label)
}

function ProjectOverview({ overview, collapsed, onToggle }) {
  const [selectedModule, setSelectedModule] = React.useState('')
  const muted = { color: 'var(--dsw-alias-label-secondary, #66716d)' }
  const modules = Array.isArray(overview?.modules) ? overview.modules : []
  const sources = Array.isArray(overview?.sources) ? overview.sources : []
  const selected = modules.find((item) => item.id === selectedModule)
  return React.createElement('section', { style: { background: 'linear-gradient(135deg, #f8fcfa 0%, #f5f9fc 100%)', border: '1px solid #dce6e1', borderRadius: 8, margin: '18px 0', overflow: 'hidden' } },
    React.createElement('header', { style: { alignItems: 'center', borderBottom: collapsed ? 0 : '1px solid #dce6e1', display: 'flex', justifyContent: 'space-between', padding: '15px 18px' } },
      React.createElement('div', null,
        React.createElement('p', { style: { color: '#1f7a59', fontSize: 11, fontWeight: 750, letterSpacing: 1, margin: '0 0 4px' } }, 'PROJECT MAP'),
        React.createElement('strong', { style: { fontSize: 18 } }, '项目概况'),
        React.createElement('span', { style: { ...muted, fontSize: 12, marginLeft: 9 } }, overview ? `实时资料生成 · ${new Date(overview.generatedAt).toLocaleTimeString('zh-CN')}` : '等待生成'),
      ),
      React.createElement('button', { 'aria-label': collapsed ? '展开项目概况' : '收起项目概况', onClick: onToggle, style: { background: 'transparent', border: '1px solid #cbd8d1', borderRadius: 5, color: '#375548', cursor: 'pointer', padding: '7px 10px' }, type: 'button' }, collapsed ? '展开' : '收起'),
    ),
    collapsed || !overview ? null : React.createElement('div', { style: { padding: 18 } },
      React.createElement('div', { style: { display: 'grid', gap: 12, gridTemplateColumns: 'minmax(190px, .9fr) minmax(320px, 1.5fr) minmax(220px, 1fr)' } },
        React.createElement('article', { style: { background: '#fff', border: '1px solid #dce6e1', borderRadius: 7, padding: 15 } },
          React.createElement('span', { style: { ...muted, fontSize: 12 } }, '项目核心'),
          React.createElement('strong', { style: { display: 'block', fontSize: 17, margin: '7px 0 12px' } }, overview.projectName),
          React.createElement('div', { style: { display: 'grid', gap: 8, gridTemplateColumns: '1fr 1fr' } },
            React.createElement('div', null, React.createElement('strong', { style: { fontSize: 22 } }, overview.sessionCount), React.createElement('small', { style: { ...muted, display: 'block' } }, '主对话')),
            React.createElement('div', null, React.createElement('strong', { style: { fontSize: 22 } }, overview.activeCount), React.createElement('small', { style: { ...muted, display: 'block' } }, '活动会话')),
          ),
          React.createElement('p', { style: { ...muted, fontSize: 12, lineHeight: 1.5, margin: '14px 0 0' } }, '只汇集可见 Codex 主对话、Git 分支与目录资料；需要结论时可让 DSH Agent 读取项目概况工具。'),
        ),
        React.createElement('article', { style: { background: '#fff', border: '1px solid #dce6e1', borderRadius: 7, padding: 15 } },
          React.createElement('span', { style: { ...muted, fontSize: 12 } }, '模块关系'),
          React.createElement('div', { style: { alignItems: 'center', display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 13 } },
            modules.length ? modules.map((module, index) => React.createElement(React.Fragment, { key: module.id }, index ? React.createElement('span', { style: { color: '#8ba59a', fontSize: 18 } }, '→') : null, React.createElement('button', { onClick: () => setSelectedModule(module.id), style: { background: selectedModule === module.id ? '#1e7656' : '#eef7f2', border: '1px solid #b9d9c9', borderRadius: 5, color: selectedModule === module.id ? '#fff' : '#225c44', cursor: 'pointer', fontSize: 13, padding: '8px 10px' }, type: 'button' }, module.name))) : React.createElement('span', { style: muted }, '未发现可展示模块')),
          selected ? React.createElement('p', { style: { color: '#2f4b3e', fontSize: 12, lineHeight: 1.5, margin: '13px 0 0' } }, `${selected.name}：${selected.kind}。目录结构可验证，具体职责待通过相关 Codex 对话确认。`) : React.createElement('p', { style: { ...muted, fontSize: 12, margin: '13px 0 0' } }, '点击模块查看可验证说明。'),
        ),
        React.createElement('article', { style: { background: '#fff', border: '1px solid #dce6e1', borderRadius: 7, padding: 15 } },
          React.createElement('span', { style: { ...muted, fontSize: 12 } }, '近期证据'),
          React.createElement('div', { style: { display: 'grid', gap: 8, marginTop: 10 } }, sources.slice(0, 4).map((source) => React.createElement('a', { href: `codex://threads/${encodeURIComponent(source.id)}`, key: source.id, onClick: (event) => openCodexThread(source.id, event), style: { color: '#315f76', fontSize: 13, overflow: 'hidden', textDecoration: 'none', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, source.title))),
          React.createElement('p', { style: { ...muted, fontSize: 12, margin: '13px 0 0' } }, overview.branches?.length ? `分支：${overview.branches.join('、')}` : '暂无可验证分支'),
        ),
      ),
    ),
  )
}

function CodexControlView() {
  const [workspaces, setWorkspaces] = React.useState([])
  const [workspaceId, setWorkspaceId] = React.useState('')
  const [sessions, setSessions] = React.useState([])
  const [overview, setOverview] = React.useState(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState('')
  const [query, setQuery] = React.useState('')
  const [overviewCollapsed, setOverviewCollapsed] = React.useState(false)
  const sequence = React.useRef(0)

  const refresh = React.useCallback(async (selectedWorkspace) => {
    if (!selectedWorkspace) return
    const requestId = ++sequence.current
    setLoading(true); setSessions([]); setOverview(null); setError('')
    try {
      const [sessionPayload, overviewPayload] = await Promise.all([boardRequest(`/sessions?workspace=${encodeURIComponent(selectedWorkspace)}`), boardRequest(`/overview?workspace=${encodeURIComponent(selectedWorkspace)}`)])
      if (requestId !== sequence.current) return
      setSessions(Array.isArray(sessionPayload.sessions) ? sessionPayload.sessions : [])
      setOverview(overviewPayload)
    } catch (cause) {
      if (requestId !== sequence.current) return
      setError(cause instanceof Error ? cause.message : '本机 Codex 控制服务未启动')
    } finally { if (requestId === sequence.current) setLoading(false) }
  }, [])

  React.useEffect(() => {
    let disposed = false
    void boardRequest('/workspaces').then((payload) => {
      const available = Array.isArray(payload.workspaces) ? payload.workspaces : []
      const initial = available.find((item) => item.id === storedWorkspace()) ?? available.find((item) => item.id === payload.defaultWorkspace) ?? available[0]
      if (disposed) return
      setWorkspaces(available); setWorkspaceId(initial?.id ?? '')
      if (initial) void refresh(initial.id)
      else { setError('未发现可用的本机 Codex 工作区'); setLoading(false) }
    }).catch((cause) => { if (!disposed) { setError(cause instanceof Error ? cause.message : '本机 Codex 控制服务未启动'); setLoading(false) } })
    return () => { disposed = true; sequence.current += 1 }
  }, [refresh])

  const onWorkspaceChange = (event) => { const next = event.target.value; storeWorkspace(next); setWorkspaceId(next); void refresh(next) }
  const visibleSessions = sessions.filter((session) => { const needle = query.trim().toLowerCase(); return !needle || [sessionTitle(session), session.branch, session.id].some((value) => String(value ?? '').toLowerCase().includes(needle)) })
  const activeCount = sessions.filter((session) => session.runtimeStatus === 'active').length
  const muted = { color: 'var(--dsw-alias-label-secondary, #66716d)' }
  const control = { background: 'var(--dsw-alias-bg-layer-1, #fff)', border: '1px solid var(--dsw-alias-border-secondary, #dce2df)', borderRadius: 6, color: 'var(--dsw-alias-label-primary, #202124)', height: 36, padding: '0 10px' }

  return React.createElement('section', { style: { color: 'var(--dsw-alias-label-primary, #202124)', maxWidth: 1180, padding: '18px 22px 28px' } },
    React.createElement('header', { style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', display: 'flex', gap: 18, justifyContent: 'space-between', paddingBottom: 16 } },
      React.createElement('div', null, React.createElement('p', { style: { color: '#176b4d', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 10, fontWeight: 700, letterSpacing: 1, margin: '0 0 6px' } }, 'LOCAL CODEX'), React.createElement('h2', { style: { fontSize: 22, margin: 0 } }, 'Codex 任务看板'), React.createElement('p', { style: { ...muted, fontSize: 13, margin: '6px 0 0' } }, '同步本机 Codex 当前项目的可见对话。')),
      React.createElement('div', { style: { alignItems: 'center', display: 'flex', gap: 8 } }, React.createElement('select', { 'aria-label': '选择 Codex 工作区', disabled: !workspaces.length, onChange: onWorkspaceChange, style: { ...control, maxWidth: 240 }, value: workspaceId }, workspaces.map((workspace) => React.createElement('option', { key: workspace.id, value: workspace.id }, workspace.name))), React.createElement('button', { 'aria-label': '更新项目概况', disabled: loading || !workspaceId, onClick: () => void refresh(workspaceId), style: { ...control, background: '#202124', borderColor: '#202124', color: '#fff', cursor: loading ? 'wait' : 'pointer' }, type: 'button' }, loading ? '同步中' : overview ? '更新概况' : '生成项目概况')),
    ),
    error ? React.createElement('p', { role: 'alert', style: { background: '#fce9e7', borderLeft: '3px solid #a4322f', color: '#a4322f', margin: '16px 0', padding: '10px 12px' } }, error) : null,
    React.createElement(ProjectOverview, { collapsed: overviewCollapsed, onToggle: () => setOverviewCollapsed((value) => !value), overview }),
    React.createElement('section', { style: { background: 'var(--dsw-alias-background-default, #fff)', border: '1px solid var(--dsw-alias-border-secondary, #dce2df)', borderRadius: 8, overflow: 'hidden' } },
      React.createElement('div', { style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', display: 'flex', gap: 12, justifyContent: 'space-between', padding: '13px 16px' } }, React.createElement('div', null, React.createElement('strong', { style: { fontSize: 17 } }, '当前项目 Codex 对话'), React.createElement('span', { style: { ...muted, fontSize: 12, marginLeft: 8 } }, `${sessions.length} 个主对话 · ${activeCount} 个活动`)), React.createElement('input', { 'aria-label': '搜索当前项目 Codex 对话', onChange: (event) => setQuery(event.target.value), placeholder: '搜索标题、分支或 Session', style: { ...control, maxWidth: 280, width: '100%' }, value: query })),
      React.createElement('div', { style: { maxHeight: 500, overflowY: 'auto' } }, visibleSessions.length ? visibleSessions.slice(0, 100).map((session) => React.createElement('a', { href: `codex://threads/${encodeURIComponent(session.id)}`, key: session.id, onClick: (event) => openCodexThread(session.id, event), style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', color: 'inherit', display: 'grid', gap: 12, gridTemplateColumns: 'minmax(260px, 1fr) 84px minmax(130px, .45fr) 88px', padding: '12px 16px', textDecoration: 'none' } }, React.createElement('span', { style: { color: '#315f76', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, sessionTitle(session)), badge(session.runtimeStatus === 'active' ? '活动中' : '状态未知', session.runtimeStatus === 'active'), React.createElement('code', { style: { ...muted, fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, session.branch || '未记录分支'), React.createElement('span', { style: { ...muted, fontSize: 12, textAlign: 'right' } }, relativeTime(session.updatedAt)))) : React.createElement('p', { style: { ...muted, margin: 0, padding: 28, textAlign: 'center' } }, loading ? '正在同步当前项目的 Codex 对话…' : '当前项目暂无可显示的主对话')),
      visibleSessions.length > 100 ? React.createElement('p', { style: { ...muted, fontSize: 12, margin: 0, padding: '9px 16px' } }, `仅显示前 100 个匹配会话，共 ${visibleSessions.length} 个。`) : null,
    ),
  )
}

export function apply(ctx) {
  ctx.slots.inject('conversation.view', () => ctx.slots.register({ name: 'conversation.view', id: 'opc-codex-control', order: 5, label: () => 'Codex 任务看板' }, CodexControlView))
}
