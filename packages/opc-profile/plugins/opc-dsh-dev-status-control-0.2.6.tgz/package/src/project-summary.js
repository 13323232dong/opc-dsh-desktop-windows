import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'

const FIELD_LIMITS = { recentWork: 300, overallProgress: 500, nextFocus: 300 }
const SUMMARY_KEYS = Object.keys(FIELD_LIMITS)
const SUMMARY_SYSTEM_PROMPT = `你负责总结一个软件项目的近期进度。只根据提供的可见 Codex 主对话资料回答，不猜测完成、测试或合并状态。
返回一个 JSON 对象，且只能包含 recentWork、overallProgress、nextFocus 三个字符串字段。
recentWork 用 1 至 3 句说明最近在做哪个功能或解决什么问题；overallProgress 用 1 至 3 句说明总体推进情况；nextFocus 用 1 至 2 句说明下一步重点。
语言必须简单、直白。资料不足时明确写“目前可确认的信息不足”。不要输出 Markdown、HTML、代码、路径、Session ID 或百分比。`

export function createProjectSummaryCache(path) {
  let entries = readCache(path)
  return {
    get(workspaceId) {
      return cloneEntry(entries[workspaceId])
    },
    set(workspaceId, value) {
      const next = { ...entries, [workspaceId]: cloneEntry(value) }
      persistCache(path, next)
      entries = next
    },
  }
}

export function createProjectSummaryService({ board, cache, agents, llm, now = Date.now }) {
  return {
    read(workspaceId) {
      const overview = board.projectOverview(workspaceId)
      const cached = cache.get(workspaceId)
      return {
        ...overview,
        generatedAt: cached?.generatedAt ?? null,
        summary: cached?.summary ?? null,
      }
    },
    async generate(workspaceId, sessionId) {
      const source = board.projectSummarySource(workspaceId)
      if (!source.sessions.length) throw new Error('当前项目暂无可总结的 Codex 对话')
      const route = resolveAgentRoute(agents?.get?.(sessionId))
      if (!route || !llm?.stream) throw new Error('当前 DSH 会话模型不可用')
      const text = await generateSummaryText(llm, route, source)
      const summary = parseProjectSummary(text)
      const value = { workspaceId: source.workspaceId, generatedAt: now(), summary }
      cache.set(source.workspaceId, value)
      return { ...board.projectOverview(source.workspaceId), ...value }
    },
  }
}

export function parseProjectSummary(value) {
  try {
    const raw = String(value ?? '').trim().replace(/^```(?:json)?\s*/iu, '').replace(/\s*```$/u, '')
    const parsed = JSON.parse(raw)
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('invalid')
    const extraKeys = Object.keys(parsed).filter((key) => !SUMMARY_KEYS.includes(key))
    if (extraKeys.length) throw new Error('invalid')
    return Object.fromEntries(SUMMARY_KEYS.map((key) => [key, cleanField(parsed[key], FIELD_LIMITS[key])]))
  } catch {
    throw new Error('项目进度生成失败，请重试')
  }
}

function resolveAgentRoute(agent) {
  if (!agent) return null
  const header = agent.session?.requestHeader?.()?.config
  const provider = agent.options?.provider ?? header?.provider
  const model = agent.options?.model ?? header?.model
  return typeof provider === 'string' && provider && typeof model === 'string' && model ? { provider, model } : null
}

async function generateSummaryText(llm, route, source) {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(new Error('project_summary_timeout')), 30_000)
  let deltas = ''
  let completed = ''
  const input = {
    projectName: source.projectName,
    conversations: source.sessions.map(({ title, progressText, updatedAt }) => ({ title, progressText: progressText || '', updatedAt })),
  }
  try {
    for await (const chunk of llm.stream({
      ...route,
      system: SUMMARY_SYSTEM_PROMPT,
      messages: [{ role: 'user', content: [{ type: 'text', text: JSON.stringify(input) }] }],
      maxTokens: 520,
      temperature: 0,
      signal: controller.signal,
    })) {
      if (chunk?.type === 'text-delta' && typeof chunk.text === 'string') deltas += chunk.text
      if (chunk?.type === 'block-end' && chunk.block?.type === 'text' && typeof chunk.block.text === 'string') completed = chunk.block.text
    }
  } catch {
    throw new Error('项目进度生成失败，请重试')
  } finally {
    clearTimeout(timeout)
  }
  return deltas || completed
}

function cleanField(value, limit) {
  if (typeof value !== 'string') throw new Error('invalid')
  const text = value.replace(/[\u0000-\u001f\u007f]/gu, ' ').replace(/\s+/gu, ' ').trim()
  if (!text || text.length > limit || /<\/?[a-z][^>]*>/iu.test(text)) throw new Error('invalid')
  return text
}

function readCache(path) {
  try {
    if (!existsSync(path)) return {}
    const parsed = JSON.parse(readFileSync(path, 'utf8'))
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {}
    return Object.fromEntries(Object.entries(parsed).flatMap(([workspaceId, value]) => {
      const entry = validCacheEntry(workspaceId, value)
      return entry ? [[workspaceId, entry]] : []
    }))
  } catch {
    return {}
  }
}

function persistCache(path, entries) {
  mkdirSync(dirname(path), { recursive: true })
  const temporary = `${path}.${process.pid}.tmp`
  writeFileSync(temporary, JSON.stringify(entries), { encoding: 'utf8', mode: 0o600 })
  renameSync(temporary, path)
}

function cloneEntry(value) {
  if (!value || typeof value !== 'object') return undefined
  return JSON.parse(JSON.stringify(value))
}

function validCacheEntry(workspaceId, value) {
  if (!value || typeof value !== 'object' || value.workspaceId !== workspaceId || !Number.isFinite(value.generatedAt)) return undefined
  try {
    return { workspaceId, generatedAt: value.generatedAt, summary: parseProjectSummary(JSON.stringify(value.summary)) }
  } catch {
    return undefined
  }
}
