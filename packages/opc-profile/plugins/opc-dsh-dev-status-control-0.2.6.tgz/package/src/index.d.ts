export declare const name: string
export declare const inject: readonly ['webServer', 'tools', 'systemPrompt', 'llm', 'agents']
export declare function apply(ctx: unknown): void
