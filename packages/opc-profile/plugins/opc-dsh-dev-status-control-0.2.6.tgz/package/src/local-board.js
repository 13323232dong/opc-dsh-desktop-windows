import { existsSync, readFileSync, readdirSync, realpathSync, statSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

const SESSIONS_QUERY = "SELECT id, title, name, agent_nickname, agent_role, first_user_message, preview, cwd, git_branch, source, thread_source, originator, project_id, coalesce(updated_at_ms, updated_at * 1000, 0) AS updated_at_ms FROM threads WHERE archived = 0 AND (trim(title) <> '' OR trim(name) <> '' OR trim(agent_nickname) <> '' OR trim(agent_role) <> '' OR trim(first_user_message) <> '' OR trim(preview) <> '') ORDER BY updated_at_ms DESC"
const PROJECT_ROOTS_QUERY = 'SELECT projects.id AS project_id, projects.name, projects.position AS project_position, project_roots.position AS root_position, project_roots.path FROM projects INNER JOIN project_roots ON project_roots.project_id = projects.id ORDER BY projects.position, project_roots.position'

const DEFAULT_WORKSPACES = [
  { id: 'opc', name: 'OPC智能体团队', path: '/Users/mac/OPC智能体团队' },
  { id: 'dsh-codex-control', name: 'DSH Codex 控制服务', path: '/Users/mac/.codex/worktrees/dsh-codex-control/control-service' },
  { id: 'openai-codex', name: 'OpenAI Codex', path: '/Users/mac/openai-codex' }
]

export class LocalCodexBoard {
  constructor(options = {}) {
    const codexHome = options.codexHome ?? join(homedir(), '.codex')
    this.databasePath = options.databasePath ?? join(codexHome, 'state_5.sqlite')
    this.locksPath = options.locksPath ?? join(codexHome, 'thread-writer-locks')
    this.configuredWorkspaces = (options.workspaces ?? DEFAULT_WORKSPACES).map((workspace) => ({
      ...workspace,
      path: canonicalPath(workspace.path),
      roots: [canonicalPath(workspace.path)],
    }))
    this.workspaces = [...this.configuredWorkspaces]
    this.defaultWorkspaceId = options.defaultWorkspaceId ?? 'opc'
    this.featureConfigPath = options.featureConfigPath ?? null
    this.worktreePathsCache = new Map()
  }

  listWorkspaces() {
    this.#refreshWorkspaces()
    return this.workspaces.map(({ id, name }) => ({ id, name, isDefault: id === this.defaultWorkspaceId }))
  }

  listSessions(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const locks = this.#lockNames()
    const sessions = this.#sessionRows(workspace).map((row) => ({
        id: String(row.id),
        title: normalizeTitle(row.title, row.name, row.first_user_message, row.preview),
        branch: String(row.git_branch ?? ''),
        updatedAt: Number(row.updated_at_ms) || 0,
        workspaceId: workspace.id,
        runtimeStatus: locks.has(String(row.id)) ? 'active' : 'idle',
      }))
    return { workspaceId: workspace.id, sessions }
  }

  projectOverview(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const sessions = this.listSessions(workspace.id).sessions
    return {
      workspaceId: workspace.id,
      projectName: workspace.name,
      sessionCount: sessions.length,
      activeCount: sessions.filter((session) => session.runtimeStatus === 'active').length,
    }
  }

  projectSummarySource(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const overview = this.projectOverview(workspace.id)
    const sessions = this.#sessionRows(workspace).slice(0, 20).map((row) => ({
      title: normalizeTitle(row.title, row.name, row.first_user_message, row.preview).slice(0, 160),
      progressText: summaryText(row.preview, row.first_user_message),
      updatedAt: Number(row.updated_at_ms) || 0,
    }))
    return { ...overview, sessions }
  }

  status(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const sessions = this.listSessions(workspace.id).sessions
    const features = this.#loadFeatures().map((feature) => {
      const matchedSessions = sessions.filter((session) => feature.sessionIds.includes(session.id) || feature.titleIncludes.some((title) => session.title.includes(title)))
      const git = readGitState(workspace.path, feature.branch, feature.paths)
      return deriveFeatureStatus(feature, matchedSessions, git)
    })
    return { generatedAt: Date.now(), workspaceId: workspace.id, features }
  }

  listTasks(workspaceId, query = '') {
    const result = this.status(workspaceId)
    const needle = String(query ?? '').trim().toLowerCase()
    const tasks = result.features
      .filter((feature) => !needle || [feature.name, feature.status, feature.mergeDecision, feature.nextStep].some((value) => String(value ?? '').toLowerCase().includes(needle)))
      .map((feature) => ({
        id: feature.id,
        name: feature.name,
        status: feature.status,
        mergeDecision: feature.mergeDecision ?? '未判断',
        nextStep: feature.nextStep ?? '等待下一步',
        updatedAt: feature.updatedAt,
        sessions: (feature.sessions ?? []).map(({ id, title, runtimeStatus, updatedAt }) => ({ id, title, runtimeStatus, updatedAt })),
      }))
    return { generatedAt: result.generatedAt, workspaceId: result.workspaceId, tasks, total: tasks.length }
  }

  #workspace(workspaceId) {
    if (typeof workspaceId !== 'string' || !/^[a-z0-9-]{2,64}$/u.test(workspaceId)) throw new Error('工作区不可用')
    this.#refreshWorkspaces()
    const workspace = this.workspaces.find((item) => item.id === workspaceId)
    if (!workspace || !existsSync(workspace.path)) throw new Error('工作区不可用')
    return workspace
  }

  #sessionRows(workspace) {
    return this.#withDatabase((database) => database.prepare(SESSIONS_QUERY).all()
      .filter((row) => this.#belongsToWorkspace(row, workspace))
      .filter((row) => !isInternalSubagent(row)))
  }

  #refreshWorkspaces() {
    this.worktreePathsCache.clear()
    const configured = this.configuredWorkspaces
      .filter((workspace) => isProjectDirectory(workspace.path))
      .map((workspace) => ({ ...workspace, roots: [workspace.path] }))
    const claimedProjectIds = new Set()
    const projects = this.#codexProjects()

    for (const workspace of configured) {
      const project = projects.find((candidate) => candidate.roots.includes(workspace.path))
      if (!project) continue
      workspace.projectId = project.projectId
      workspace.roots = [...project.roots]
      claimedProjectIds.add(project.projectId)
    }

    const discovered = projects
      .filter((project) => !claimedProjectIds.has(project.projectId))
      .map((project) => ({
        id: projectWorkspaceId(project.projectId),
        name: project.name,
        path: project.roots[0],
        roots: [...project.roots],
        projectId: project.projectId,
      }))
    this.workspaces = [...configured, ...discovered]
  }

  #codexProjects() {
    return this.#withDatabase((database) => {
      let rows
      try {
        rows = database.prepare(PROJECT_ROOTS_QUERY).all()
      } catch {
        return []
      }
      const projects = new Map()
      for (const row of rows) {
        const path = canonicalPath(String(row.path))
        if (!isProjectDirectory(path)) continue
        const projectId = String(row.project_id)
        const project = projects.get(projectId) ?? { projectId, name: String(row.name), roots: [] }
        if (!project.roots.includes(path)) project.roots.push(path)
        projects.set(projectId, project)
      }
      return [...projects.values()].filter((project) => project.roots.length > 0)
    })
  }

  #belongsToWorkspace(row, workspace) {
    const projectId = String(row.project_id ?? '').trim()
    if (projectId) return workspace.projectId === projectId
    const candidatePath = String(row.cwd ?? '')
    if (!candidatePath) return false
    const candidate = canonicalPath(candidatePath)
    const exactRootOwner = this.workspaces.find((item) => (item.roots ?? [item.path]).includes(candidate))
    if (exactRootOwner) return exactRootOwner.id === workspace.id
    return (workspace.roots ?? [workspace.path]).some((root) => this.#worktreePaths(root).has(candidate))
  }

  #worktreePaths(workspacePath) {
    if (this.worktreePathsCache.has(workspacePath)) return this.worktreePathsCache.get(workspacePath)
    const paths = new Set([workspacePath])
    try {
      const output = execFileSync('git', ['worktree', 'list', '--porcelain'], { cwd: workspacePath, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 2_000 })
      for (const line of output.split('\n')) if (line.startsWith('worktree ')) paths.add(canonicalPath(line.slice('worktree '.length)))
    } catch {}
    this.worktreePathsCache.set(workspacePath, paths)
    return paths
  }

  #lockNames() {
    try {
      return new Set(readdirSync(this.locksPath).filter((name) => name.endsWith('.lock')).map((name) => name.slice(0, -5)))
    } catch {
      return new Set()
    }
  }

  #withDatabase(run) {
    let database
    try {
      database = new DatabaseSync(this.databasePath, { readOnly: true })
      return run(database)
    } catch {
      throw new Error('本机 Codex 数据库不可用')
    } finally {
      database?.close()
    }
  }

  #loadFeatures() {
    if (!this.featureConfigPath || !existsSync(this.featureConfigPath)) return []
    try {
      const config = JSON.parse(readFileSync(this.featureConfigPath, 'utf8'))
      return Array.isArray(config.features) ? config.features.map((feature) => ({
        ...feature,
        sessionIds: Array.isArray(feature.sessionIds) ? feature.sessionIds : [],
        titleIncludes: Array.isArray(feature.titleIncludes) ? feature.titleIncludes : [],
        paths: Array.isArray(feature.paths) ? feature.paths : [],
      })) : []
    } catch {
      return []
    }
  }
}

function isInternalSubagent(row) {
  return Boolean(String(row.agent_nickname ?? '').trim() || String(row.agent_role ?? '').trim()) ||
    isInternalAgentMarker(row.source) ||
    hasStructuredSubagentSource(row.source) ||
    isInternalAgentMarker(row.thread_source) ||
    isInternalAgentMarker(row.originator)
}

function isInternalAgentMarker(value) {
  return ['subagent', 'agent', 'child', 'guardian_review', 'opc-agent-session'].includes(String(value ?? '').trim().toLowerCase())
}

function hasStructuredSubagentSource(value) {
  if (typeof value !== 'string' || !value.trim().startsWith('{')) return false
  try {
    const source = JSON.parse(value)
    return Boolean(source && typeof source === 'object' && Object.hasOwn(source, 'subagent'))
  } catch {
    return false
  }
}

function summaryText(preview, firstUserMessage) {
  return String(preview || firstUserMessage || '')
    .replace(/codex:\/\/threads\/[0-9a-z-]+/giu, '')
    .replace(/[\u0000-\u001f\u007f]/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
    .slice(0, 500)
}

function deriveFeatureStatus(feature, sessions, git) {
  const active = sessions.some((session) => session.runtimeStatus === 'active')
  let status = '状态未知'
  if (active) status = '正在开发'
  else if (sessions.some((session) => session.runtimeStatus === 'error')) status = '异常中断'
  else if (git?.dirty) status = '开发中，有未提交改动'
  else if (git?.merged) status = '已合并'
  else if (git && git.ahead > 0) status = '已提交，待测试或合并'
  else if (sessions.length) status = '暂停，等待继续'
  return { ...feature, status, sessions: [...sessions].sort((left, right) => right.updatedAt - left.updatedAt), git, updatedAt: Math.max(0, ...sessions.map((session) => session.updatedAt), git?.updatedAt ?? 0) }
}

function readGitState(repository, branch, paths) {
  if (!branch || !existsSync(join(repository, '.git'))) return null
  try {
    const run = (args) => execFileSync('git', args, { cwd: repository, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 5_000 }).trim()
    const currentBranch = run(['branch', '--show-current'])
    const changed = run(['status', '--porcelain=v1', '--', ...paths]).split('\n').filter(Boolean)
    const [behind = 0, ahead = 0] = run(['rev-list', '--left-right', '--count', `main...${branch}`]).split(/\s+/u).map(Number)
    let merged = false
    try { execFileSync('git', ['merge-base', '--is-ancestor', branch, 'main'], { cwd: repository, stdio: 'ignore', timeout: 5_000 }); merged = true } catch {}
    const updatedAt = Number(run(['log', '-1', '--format=%ct', branch])) * 1000 || 0
    return { branch, currentBranch, behind, ahead, merged, dirty: changed.length > 0, changedCount: changed.length, dirtyBranch: changed.length ? currentBranch : null, updatedAt }
  } catch {
    return null
  }
}

function normalizeTitle(...values) {
  for (const value of values) {
    const title = readableTitle(String(value ?? '').replace(/\s+/gu, ' ').trim())
    if (!title) continue
    return title.length > 80 ? `${title.slice(0, 80)}…` : title
  }
  return '未命名任务'
}

function readableTitle(value) {
  if (!value || /^https?:\/\//u.test(value)) return ''
  const referenced = value.replace(/^codex:\/\/threads\/[0-9a-f-]{36}\s*/iu, '').trim()
  return referenced.startsWith('codex://') ? '' : referenced
}

function isProjectDirectory(path) {
  try {
    return path !== '/' && statSync(path).isDirectory()
  } catch {
    return false
  }
}

function canonicalPath(path) {
  const resolved = resolve(path)
  try {
    return realpathSync(resolved)
  } catch {
    return resolved
  }
}

function projectWorkspaceId(projectId) {
  return `project-${createHash('sha256').update(projectId).digest('hex').slice(0, 12)}`
}
