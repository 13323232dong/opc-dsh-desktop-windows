export interface MaterialMatcherGatewayConfig {
    readonly apiBaseUrl?: string;
    readonly identityHmacSecret?: string;
}
export interface MaterialMatcherPrincipal {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
}
export interface MaterialMatcherGatewayDependencies {
    readonly fetcher?: typeof fetch;
    readonly resolveIdentity: (sessionId: string, parentSessionId?: string) => Promise<MaterialMatcherPrincipal | undefined>;
    readonly environment?: NodeJS.ProcessEnv;
    readonly now?: () => number;
    readonly nonce?: () => string;
}
export interface MaterialMatcherGatewayRequest {
    readonly sessionId: string;
    readonly parentSessionId?: string;
    readonly approvalCallId?: string;
    readonly action: string;
    readonly input: unknown;
}
export declare class MaterialMatcherGatewayError extends Error {
}
export declare function createMaterialMatcherGateway(config: MaterialMatcherGatewayConfig, dependencies: MaterialMatcherGatewayDependencies): {
    execute(request: MaterialMatcherGatewayRequest): Promise<unknown>;
};
