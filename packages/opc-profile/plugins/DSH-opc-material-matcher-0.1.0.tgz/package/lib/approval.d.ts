import type { PreToolDecision } from '@deepseek-ai/dsh-tools';
export declare function materialMatcherApprovalDecision(toolName: string, next: () => Promise<PreToolDecision>): Promise<PreToolDecision>;
