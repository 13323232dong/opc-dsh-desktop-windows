# DSH-opc-material-matcher

OPC 商户素材智能匹配 DSH 插件。它提供素材搜索、分镜匹配、匹配预检、剪辑计划写入、索引状态和反馈记录六个稳定工具。

插件只通过 OPC 受信会话网关访问当前租户素材；不会向 Agent 或浏览器暴露向量、Embedding、OSS、SQL、供应商密钥或外部签名 URL。向量服务不可用时，服务端自动降级为关键词、标签和属性搜索。

## 剪映草稿

插件内置 `vendor/jianying-editor-skill` 的草稿生成库（MIT），用于把已确认的
`EditDecisionList` 转换为剪映草稿目录。生成结果包含 `draft_content.json` 和
`draft_meta_info.json`，视频素材以本地绝对路径登记，时间单位为微秒，可直接复制到
剪映的 Projects 目录后打开并人工微调。上游 skill 的原始说明保存在
`vendor/jianying-editor-skill/SKILL.md`；插件不复制其浏览器自动导出或账号操作能力。

本次真实验证草稿：

`/Users/mac/Movies/JianyingPro/User Data/Projects/OPC-猪肉店-素材智能匹配粗剪`

搜索、分镜匹配、预检和索引状态为只读操作。`material_match_apply` 进入 DSH 原生逐次审批流程，用户批准后才会写入剪辑计划；反馈写入无需弹窗，但必须通过租户、素材、片段和索引版本校验。所有网关请求使用 HMAC v2 同时绑定身份、请求路径、正文摘要和幂等键，防止请求内容在传输中被替换。

## 配置

- `OPC_API_BASE_URL`
- `OPC_DSH_IDENTITY_HMAC_SECRET`（至少 32 个字符）

运行时还必须提供 `opcDshIdentity` 服务，用于将当前 DSH Session 解析为受信租户、用户和 Agent 身份。
