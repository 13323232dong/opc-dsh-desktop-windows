# Security policy

Report security issues privately to the OPC maintainers. Do not include access credentials, OAuth callback parameters, document contents, or customer asset identifiers in public issues.
