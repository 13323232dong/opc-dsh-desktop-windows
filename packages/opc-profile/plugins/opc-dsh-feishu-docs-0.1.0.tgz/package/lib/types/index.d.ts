import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type FeishuGatewayConfig } from './gateway.ts';
export declare const name = "opc-feishu-docs";
export declare const inject: string[];
export interface Config extends FeishuGatewayConfig {
    readonly egoCommand?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export type { FeishuGatewayConfig, FeishuGatewayRequest } from './gateway.ts';
export { FeishuBrowserError, createFeishuBrowserRunner, parseFeishuBrowserResult } from './browser-runner.ts';
