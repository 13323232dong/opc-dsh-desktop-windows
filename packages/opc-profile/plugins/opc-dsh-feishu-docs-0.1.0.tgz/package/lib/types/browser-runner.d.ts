import { spawn as nodeSpawn } from 'node:child_process';
export interface FeishuBrowserRunner {
    run(operation: 'connectionStatus' | 'create', input: Record<string, unknown>, signal?: AbortSignal): Promise<Record<string, unknown>>;
}
export interface FeishuBrowserRunnerDependencies {
    readonly spawn?: typeof nodeSpawn;
    readonly environment?: NodeJS.ProcessEnv;
}
export declare class FeishuBrowserError extends Error {
}
export declare function parseFeishuBrowserResult(stdout: string, stderr: string): Record<string, unknown>;
export declare function createFeishuBrowserRunner(command?: string, taskName?: string, dependencies?: FeishuBrowserRunnerDependencies): FeishuBrowserRunner;
