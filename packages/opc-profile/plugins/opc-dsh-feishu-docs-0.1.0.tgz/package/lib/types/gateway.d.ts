export interface FeishuGatewayConfig {
    readonly apiBaseUrl?: string;
    readonly tenantId?: string;
    readonly userId?: string;
}
export interface FeishuGatewayRequest {
    readonly agentId: string;
    readonly sessionId?: string;
    readonly parentSessionId?: string;
    readonly action: string;
    readonly input: unknown;
}
export interface FeishuGatewayPrincipal {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId?: string;
}
export interface FeishuGatewayDependencies {
    readonly fetcher?: typeof fetch;
    readonly environment?: NodeJS.ProcessEnv;
    readonly createRequestId?: () => string;
    readonly resolveIdentity?: (sessionId: string, parentSessionId?: string) => Promise<FeishuGatewayPrincipal | undefined>;
}
export declare class FeishuGatewayError extends Error {
}
export declare function createFeishuGateway(config: FeishuGatewayConfig, dependencies?: FeishuGatewayDependencies): {
    execute(request: FeishuGatewayRequest): Promise<unknown>;
};
