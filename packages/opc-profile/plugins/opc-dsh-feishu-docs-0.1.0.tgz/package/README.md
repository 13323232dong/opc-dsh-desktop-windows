# OPC 飞书文档 DSH 插件

`@opc/dsh-feishu-docs` 将通用飞书云文档操作注册为 DSH 模型工具。它只将受控参数和可信的 OPC 会话身份转发给 OPC API；飞书 OAuth、Token、素材授权、审批、任务恢复和飞书 SDK 调用都由 OPC API 管理。

## 工具

- 查看飞书连接状态
- 读取飞书文档
- 创建飞书文档
- 追加飞书文档内容
- 更新飞书文档内容
- 查询飞书操作状态

创建、追加和更新属于外部资源写入。插件不自行确认，OPC API 必须在执行前完成统一预检和逐次审批。

## 配置

`cordis.patch.yml` 接受 `apiBaseUrl`、`tenantId` 与 `userId`。生产环境应由 DSH Session 网关注入租户和用户身份，并通过环境变量提供 `OPC_AGENT_API_KEY`；浏览器不得提供或覆盖这些值。
