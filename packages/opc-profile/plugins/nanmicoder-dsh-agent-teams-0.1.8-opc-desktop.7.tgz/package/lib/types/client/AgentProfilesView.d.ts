import type { AgentProfileSeed, ToolLibraryClient } from '../tool-library-contracts.ts';
export declare function AgentProfilesView({ client, members }: {
    readonly client: ToolLibraryClient;
    readonly members: readonly AgentProfileSeed[];
}): import("react").JSX.Element;
