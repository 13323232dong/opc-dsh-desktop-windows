export interface TeamLearningInput {
    readonly baseUrl?: string;
    readonly secret?: string;
    readonly tenantId: string;
    readonly userId: string;
    readonly profileId: string;
    readonly taskId: string;
    readonly sourceRunId: string;
    readonly status: 'succeeded' | 'failed';
    readonly summary: string;
}
/** Best-effort bridge; learning failure must never change the team task outcome. */
export declare function recordTeamTaskLearning(input: TeamLearningInput, fetcher?: typeof fetch): Promise<void>;
