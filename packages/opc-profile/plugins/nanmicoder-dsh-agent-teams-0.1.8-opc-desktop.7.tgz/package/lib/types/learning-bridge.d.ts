/**
 * Best-effort bridge from the local Agent Teams state machine to Harness
 * terminal learning. The bridge is deliberately optional: a missing Harness
 * endpoint must never change the task terminal state.
 */
export type TeamLearningStatus = 'succeeded' | 'failed';
export interface TeamLearningSubmission {
    readonly sourceId: string;
    readonly teamId: string;
    readonly taskId: string;
    readonly attemptId?: string;
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
    readonly profileId?: string;
    readonly sessionId: string;
    readonly status: TeamLearningStatus;
    readonly subject: string;
    readonly description?: string;
    readonly output?: string;
    readonly startedAt?: number;
    readonly completedAt?: number;
}
export interface TeamLearningBridgeConfig {
    readonly enabled?: boolean;
    readonly baseUrl?: string;
    readonly apiKey?: string;
    readonly timeoutMs?: number;
}
type LearningFetcher = typeof fetch;
/**
 * Submit one terminal task as an idempotent learning request.
 *
 * The endpoint is intentionally a fixed server route; callers cannot provide
 * an arbitrary URL or forward credentials in the request body.
 */
export declare function submitTeamTaskLearning(config: TeamLearningBridgeConfig, input: TeamLearningSubmission, fetcher?: LearningFetcher): Promise<void>;
export {};
