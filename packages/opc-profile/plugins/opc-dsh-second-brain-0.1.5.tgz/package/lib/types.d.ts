export type SecondBrainStatusName = 'not_created' | 'creating' | 'ready' | 'indexing' | 'failed' | 'unavailable';
export interface SecondBrainStatus {
    readonly supported: boolean;
    readonly status: SecondBrainStatusName;
    readonly rootPath: string;
    readonly version: string;
    readonly fileCount: number;
    readonly indexedFileCount: number;
    readonly lastIndexedAt: string | null;
    readonly obsidianAvailable: boolean;
    readonly errorCode: string | null;
    readonly libraryMode: 'managed' | 'linked';
}
export interface SecondBrainSearchResult {
    readonly title: string;
    readonly relativePath: string;
    readonly sourceType: string;
    readonly updatedAt: string;
    readonly snippet: string;
}
export interface SecondBrainSearchResponse {
    readonly results: readonly SecondBrainSearchResult[];
    readonly total: number;
    readonly truncated: boolean;
}
export declare class SecondBrainError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
