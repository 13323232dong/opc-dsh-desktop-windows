export declare const VAULT_VERSION = "1";
export declare const VAULT_DIRECTORIES: readonly ["00-导航", "01-原始资料", "02-Wiki", "03-规则与技能", "04-经验", "04-经验/待审核", ".second-brain"];
export declare const VAULT_FILES: Readonly<Record<string, string>>;
