# @opc/DSH-dong-computer-use

OPC 的 macOS 原生电脑控制 DSH 插件。它通过 Accessibility 观察和操作指定应用，使用 Agent/Session/Turn 作用域、过期观察保护、控制审批和一次性确认。

当前版本提供应用健康检查、界面观察和确认提案基础工具。原生 helper 需要 macOS Accessibility 权限；没有权限或 helper 未构建时会失败关闭，不会执行输入。插件不接受 shell、AppleScript、任意脚本、Cookie、密码或任意文件路径，也不绕过验证码。

安装：

```bash
dsh plugin --profile <profile> add /Users/mac/OPC智能体团队/dsh-plugins/DSH-dong-computer-use
```
