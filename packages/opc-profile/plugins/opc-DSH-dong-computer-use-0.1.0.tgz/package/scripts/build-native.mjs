import { mkdir } from 'node:fs/promises'; await mkdir('native/macos/build',{recursive:true}); console.log('macOS helper build requires Xcode; protocol stub is source-only')
