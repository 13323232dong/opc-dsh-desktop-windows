import Foundation
while let line = readLine(), let data = line.data(using: .utf8), let obj = try? JSONSerialization.jsonObject(with: data) as? [String:Any], let id = obj["requestId"] as? String { let out:[String:Any] = ["version":1,"requestId":id,"ok":true,"result":["status":"stub"]]; let d = try! JSONSerialization.data(withJSONObject: out); print(String(data:d,encoding:.utf8)!) }
