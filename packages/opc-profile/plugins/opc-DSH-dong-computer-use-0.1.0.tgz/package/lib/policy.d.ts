export type ActionType = 'observe' | 'wait' | 'press' | 'set_value' | 'type_text' | 'key' | 'click' | 'scroll' | 'drag';
export declare function riskFor(action: ActionType): 'read' | 'control' | 'sensitive';
export declare function assertAllowed(action: ActionType, secure?: boolean): void;
