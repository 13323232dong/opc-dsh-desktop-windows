export interface TrustedIdentity {
    readonly agentId: string;
    readonly sessionId: string;
    readonly turnId: string;
    readonly tenantId?: string;
}
export declare function identityFromContext(ctx: unknown): TrustedIdentity;
export declare function sameScope(a: TrustedIdentity, b: TrustedIdentity): boolean;
