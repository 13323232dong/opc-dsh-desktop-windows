import type { ComputerService } from './service.js';
export declare function registerComputerTools(ctx: any, service: ComputerService, provider: {
    request: (request: unknown) => Promise<unknown>;
}): () => void;
