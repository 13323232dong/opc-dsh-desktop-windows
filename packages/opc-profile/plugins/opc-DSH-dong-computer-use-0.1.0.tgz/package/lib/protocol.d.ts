export declare const PROTOCOL_VERSION = 1;
export type RpcMethod = 'observe' | 'action' | 'wait' | 'health' | 'stop';
export type RpcRequest = {
    version: 1;
    requestId: string;
    method: RpcMethod;
    payload?: Record<string, unknown>;
};
export type RpcResponse = {
    version: 1;
    requestId: string;
    ok: boolean;
    result?: unknown;
    error?: {
        code: string;
        message: string;
    };
};
export declare const ERROR_CODES: readonly ["COMPUTER_PERMISSION_REQUIRED", "COMPUTER_OBSERVATION_EXPIRED", "COMPUTER_TARGET_NOT_FOUND", "COMPUTER_TARGET_AMBIGUOUS", "COMPUTER_ACTION_NOT_ALLOWED", "COMPUTER_HELPER_UNAVAILABLE", "COMPUTER_CONFIRMATION_REQUIRED", "COMPUTER_SENSITIVE_INPUT_BLOCKED"];
export declare function validateRequest(value: unknown): RpcRequest;
export declare function validateActionCoordinates(x: number, y: number): void;
export declare function validateText(text: string): void;
