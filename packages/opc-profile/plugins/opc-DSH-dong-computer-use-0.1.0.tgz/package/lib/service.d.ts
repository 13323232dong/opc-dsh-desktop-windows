import type { TrustedIdentity } from './identity.js';
import type { Observation } from './observation.js';
import { type ActionType } from './policy.js';
export declare class ComputerService {
    private ttl;
    private confirmations;
    private locks;
    private observations;
    constructor(ttl?: number);
    remember(o: Observation): Observation;
    observation(id: string): Observation;
    precheck(identity: TrustedIdentity, o: Observation, action: ActionType): {
        status: string;
        risk: "read";
        confirmation?: undefined;
    } | {
        status: string;
        risk: "control" | "sensitive";
        confirmation: {
            id: `${string}-${string}-${string}-${string}-${string}`;
            hash: string;
            used: boolean;
            expires: number;
            agentId: string;
            sessionId: string;
            turnId: string;
            observationId: string;
            action: string;
        };
    };
    execute(identity: TrustedIdentity, o: Observation, action: ActionType, confirmationId?: string): {
        status: string;
        action: ActionType;
    };
}
