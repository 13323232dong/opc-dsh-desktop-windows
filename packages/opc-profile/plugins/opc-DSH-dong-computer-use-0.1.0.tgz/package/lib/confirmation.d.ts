type Token = {
    id: string;
    agentId: string;
    sessionId: string;
    turnId: string;
    observationId: string;
    action: string;
    hash: string;
    used: boolean;
    expires: number;
};
export declare class ConfirmationStore {
    private tokens;
    create(x: Omit<Token, 'id' | 'hash' | 'used' | 'expires'>, ttl?: number): {
        id: `${string}-${string}-${string}-${string}-${string}`;
        hash: string;
        used: boolean;
        expires: number;
        agentId: string;
        sessionId: string;
        turnId: string;
        observationId: string;
        action: string;
    };
    consume(id: string, scope: Omit<Token, 'id' | 'hash' | 'used' | 'expires'>): Token;
}
export {};
