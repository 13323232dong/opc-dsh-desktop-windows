export declare function sanitizeText(input: string): string;
