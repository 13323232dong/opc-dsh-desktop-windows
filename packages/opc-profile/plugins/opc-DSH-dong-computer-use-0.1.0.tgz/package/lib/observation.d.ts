export type Element = {
    index: number;
    targetHandle: string;
    role: string;
    name: string;
    value?: string;
    actions: string[];
    secure: boolean;
};
export type Observation = {
    observationId: string;
    expiresAt: string;
    app: {
        bundleId: string;
        pid: number;
        name: string;
    };
    window: {
        windowId: string;
        title: string;
        frame: {
            x: number;
            y: number;
            width: number;
            height: number;
        };
    };
    elements: Element[];
};
export declare function createObservation(input: Omit<Observation, 'observationId' | 'expiresAt' | 'elements'> & {
    elements?: Array<Omit<Element, 'targetHandle'>>;
}, ttlMs?: number): Observation;
export declare function assertFresh(o: Observation, now?: number): void;
export declare function sameWindow(a: Observation, b: Observation): boolean;
