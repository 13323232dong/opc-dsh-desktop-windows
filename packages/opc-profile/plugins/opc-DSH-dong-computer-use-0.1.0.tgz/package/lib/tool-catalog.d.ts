export declare const computerToolCatalog: {
    readonly groupId: "computer-control";
    readonly title: "电脑控制";
    readonly iconKey: "monitor-cog";
    readonly tools: readonly [{
        readonly id: "computer_list_apps";
        readonly title: "查看电脑应用";
        readonly risk: "read";
    }, {
        readonly id: "computer_observe";
        readonly title: "观察应用界面";
        readonly risk: "read";
    }, {
        readonly id: "computer_confirm";
        readonly title: "申请电脑控制确认";
        readonly risk: "control";
    }, {
        readonly id: "computer_click";
        readonly title: "点击界面元素";
        readonly risk: "control";
    }, {
        readonly id: "computer_set_value";
        readonly title: "填写文本";
        readonly risk: "sensitive";
    }, {
        readonly id: "computer_type_text";
        readonly title: "输入文字";
        readonly risk: "sensitive";
    }, {
        readonly id: "computer_press_key";
        readonly title: "发送快捷键";
        readonly risk: "control";
    }, {
        readonly id: "computer_scroll";
        readonly title: "滚动界面";
        readonly risk: "control";
    }, {
        readonly id: "computer_drag";
        readonly title: "拖拽界面";
        readonly risk: "control";
    }, {
        readonly id: "computer_wait";
        readonly title: "等待界面变化";
        readonly risk: "read";
    }];
};
