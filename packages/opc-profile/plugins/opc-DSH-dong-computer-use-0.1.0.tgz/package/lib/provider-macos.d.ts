export declare class MacProvider {
    private command;
    private child?;
    private pending;
    private ready?;
    constructor(command?: string);
    start(): Promise<void>;
    request(req: unknown): Promise<unknown>;
    stop(): Promise<void>;
}
