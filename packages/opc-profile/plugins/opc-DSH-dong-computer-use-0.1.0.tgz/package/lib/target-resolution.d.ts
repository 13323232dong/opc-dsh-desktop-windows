import type { Observation, Element } from './observation.js';
export declare function resolveTarget(o: Observation, target: string | number): Element;
