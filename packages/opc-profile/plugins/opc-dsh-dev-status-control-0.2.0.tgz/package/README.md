# DSH Codex 任务看板

在本机 DSH Desktop 内显示 Codex 工作区、Session、运行状态和开发状态。看板是 DSH 原生标签，不会打开独立浏览器窗口。

工作区只从本机 Codex 的非归档 Session 自动发现；客户端只传工作区 ID，Host 每次都重新校验归属。看板读取不依赖 `127.0.0.1:4173`。

模型侧发送严格分为两步：`codex_session_send` 只创建待确认提案并返回摘要，得到用户明确确认后再调用 `codex_session_confirm_send`。确认提案绑定发起 Agent、一次性消费且受过期时间限制；插件不直接注入 Codex 进程。当前版本保留本机控制服务作为发送路径，桌面端自动生命周期接入属于后续阶段。
