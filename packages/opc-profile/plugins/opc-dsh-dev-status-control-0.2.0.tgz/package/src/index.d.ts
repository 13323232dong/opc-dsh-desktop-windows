export declare const name: string
export declare const inject: readonly ['webServer', 'tools']
export declare function apply(ctx: unknown): void
