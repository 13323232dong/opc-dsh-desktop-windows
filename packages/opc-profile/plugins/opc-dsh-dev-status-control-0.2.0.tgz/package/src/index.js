import { defineTool } from '@deepseek-ai/dsh-tools'
import { LocalCodexBoard } from './local-board.js'
import { homedir } from 'node:os'
import { join } from 'node:path'

const PANEL_ORIGIN = () => process.env.OPC_DEV_STATUS_URL ?? 'http://127.0.0.1:4173'
const MAX_MESSAGE_LENGTH = 8000
const PLUGIN_PATH = '/plugins/opc-dev-status-control'

export const name = 'opc-dev-status-control'
export const inject = ['webServer', 'tools', 'systemPrompt']

/**
 * Build the model-facing send handlers. Keeping the pending proposal in this
 * closure prevents a different Agent session from confirming it.
 */
export function createSessionInstructionHandlers({ request: requestFn = request } = {}) {
  const pending = new Map()

  async function prepare(args, exec = {}) {
    const input = args ?? {}
    const agentId = String(exec.agent?.id ?? '')
    if (!agentId) throw new Error('Codex 指令必须由 Agent 会话发起')
    if (typeof input.workspace_id !== 'string' || typeof input.session_id !== 'string' || typeof input.message !== 'string') throw new Error('必须提供工作区、Session 和指令')
    if (input.message.trim().length === 0 || input.message.length > MAX_MESSAGE_LENGTH) throw new Error('指令不能为空且不能超过 8000 字符')
    const proposal = await requestFn('/api/sessions/' + encodeURIComponent(input.session_id) + '/messages', {
      method: 'POST',
      body: { workspaceId: input.workspace_id, message: input.message, sourceSessionId: agentId },
      headers: { 'x-dsh-plugin': 'opc-dev-status-control', 'x-dsh-session-id': agentId },
    })
    if (!proposal?.taskId || !proposal?.proposal) throw new Error('Codex 指令提案未生成')
    const key = `${agentId}:${proposal.taskId}`
    pending.set(key, { agentId, workspaceId: input.workspace_id, sessionId: input.session_id, proposal: proposal.proposal })
    return { ...proposal, status: 'awaiting_confirmation', confirmationRequired: true, workspaceId: input.workspace_id, sessionId: input.session_id }
  }

  async function confirm(args, exec = {}) {
    const input = args ?? {}
    const agentId = String(exec.agent?.id ?? '')
    if (!agentId) throw new Error('Codex 指令必须由 Agent 会话发起')
    if (typeof input.task_id !== 'string' || !input.proposal || typeof input.proposal !== 'object') throw new Error('必须提供待确认的指令提案')
    const key = `${agentId}:${input.task_id}`
    const entry = pending.get(key)
    if (!entry || !sameProposal(entry.proposal, input.proposal)) throw new Error('指令提案不存在、已确认或不属于当前 Agent')
    if (Date.parse(String(entry.proposal.expiresAt ?? '')) <= Date.now()) {
      pending.delete(key)
      throw new Error('指令提案已过期，请重新发起')
    }
    pending.delete(key)
    const result = await requestFn('/api/sessions/messages/confirm', {
      method: 'POST',
      body: { taskId: input.task_id, proposal: input.proposal },
      headers: { 'x-dsh-plugin': 'opc-dev-status-control', 'x-dsh-session-id': agentId },
    })
    return { ...result, sent: result?.success === true || result?.status === 'sent', workspaceId: entry.workspaceId, sessionId: entry.sessionId, taskId: input.task_id }
  }

  return { prepare, confirm }
}

export function apply(ctx) {
  const server = ctx.get?.('webServer')
  const board = new LocalCodexBoard({
    featureConfigPath: process.env.OPC_DEV_STATUS_FEATURE_CONFIG ?? join(homedir(), 'opc-dev-status', 'config.json'),
    defaultWorkspaceId: 'opc',
  })
  const instructionHandlers = createSessionInstructionHandlers()
  ctx.systemPrompt?.section?.({
    name: 'opc-dev-status-control:voice-routing',
    order: 135,
    text: '当用户询问当前项目有哪些任务、开发状态或 Codex 进展时，先调用 codex_project_list 确认项目，再调用 codex_task_list 读取任务；用中文播报任务名称、状态和下一步。不要把本机绝对路径、密钥或完整 Session 内容播报给用户。向 Codex 发送指令必须先调用 codex_session_send 生成提案，向用户复述目标和正文，只有明确确认后才调用 codex_session_confirm_send。',
  })
  if (server?.register) server.register({ kind: 'prefix', path: PLUGIN_PATH, handler: async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://dsh.local')
    try {
      const result = localBoardRoute(req.method, url, board)
      if (result) return json(res, 200, result)
    } catch (error) {
      return json(res, 503, { error: error instanceof Error ? error.message : '本机 Codex 控制服务未启动' })
    }
    const target = new URL(req.url ?? '/', PANEL_ORIGIN())
    target.pathname = target.pathname.replace(PLUGIN_PATH, '/api') || '/api'
    const response = await fetch(target, { method: req.method, headers: { cookie: req.headers.cookie ?? '' }, body: req.method === 'GET' ? undefined : req, ...(req.method === 'GET' ? {} : { duplex: 'half' }) })
    res.statusCode = response.status
    res.setHeader('content-type', response.headers.get('content-type') ?? 'application/json')
    res.end(Buffer.from(await response.arrayBuffer()))
  }})
  ctx.provide?.('opcDevStatusControl', {
    async workspaces() { return { defaultWorkspace: board.listWorkspaces()[0]?.id ?? '', workspaces: board.listWorkspaces() } },
    async status(workspace) { return board.status(workspace) },
    async prepareSessionInstruction(sessionId, input) { return request(`/api/sessions/${encodeURIComponent(sessionId)}/messages`, { method: 'POST', body: input }) },
    async confirmSessionInstruction(input) { return request('/api/sessions/messages/confirm', { method: 'POST', body: input }) },
  })
  // Model-facing tool: every Agent (including voice Agents) can request a
  // Codex Session instruction through the same authenticated two-step flow.
  // The panel remains responsible for workspace/session authorization.
  const tools = ctx.tools
  if (tools?.register) {
    tools.register(defineTool({
      name: 'codex_project_list',
      description: '读取本机 Codex 项目工作区。用户未明确指定项目时，必须使用返回的 defaultWorkspaceId（OPC智能体团队），不要根据当前 DSH cwd 自行改选其他项目。',
      parameters: {},
      output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
      async execute() {
        const workspaces = board.listWorkspaces()
        const defaultWorkspace = workspaces.find((workspace) => workspace.isDefault) ?? workspaces[0]
        return { defaultWorkspaceId: defaultWorkspace?.id ?? '', defaultWorkspaceName: defaultWorkspace?.name ?? '', workspaces }
      },
    }))
    tools.register(defineTool({
      name: 'codex_session_list',
      description: '读取指定本机 Codex 项目的会话标题、状态和 Session ID。用户说“搜一下当前项目”或要查 Codex 历史时，workspace_id 使用 codex_project_list 返回的 defaultWorkspaceId；未明确指定项目时固定使用 OPC智能体团队，不根据当前 DSH cwd 推断。',
      parameters: {
        workspace_id: { type: 'string' },
        query: { type: 'string' },
      },
      output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
      async execute(args = {}) {
        const workspaces = board.listWorkspaces()
        const workspaceId = typeof args.workspace_id === 'string' && args.workspace_id ? args.workspace_id : 'opc'
        const result = board.listSessions(workspaceId)
        const query = typeof args.query === 'string' ? args.query.trim().toLowerCase() : ''
        const sessions = query ? result.sessions.filter((session) => [session.title, session.branch, session.id].some((value) => String(value).toLowerCase().includes(query))) : result.sessions
        return { ...result, sessions: sessions.slice(0, 100), total: sessions.length }
      },
    }))
    tools.register(defineTool({
      name: 'codex_task_list',
      description: '读取本机 OPC 智能体团队的 Codex 任务看板。用户说“当前项目有哪些任务”“现在开发到哪了”“有哪些待测试事项”时调用。本工具的当前项目固定为 OPC智能体团队（workspaceId=opc），绝不能使用 DSH 当前 cwd 或模型传入的其他 workspace_id 覆盖。只有用户明确点名其他项目时，才调用 codex_workspace_task_list。返回任务名称、状态、合并判断、下一步和关联 Session 标题。只读，不执行指令。',
      parameters: {
        workspace_id: { type: 'string' },
        query: { type: 'string' },
      },
      output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
      async execute(args = {}) {
        board.listWorkspaces()
        return board.listTasks('opc', args.query)
      },
    }))
    tools.register(defineTool({
      name: 'codex_workspace_task_list',
      description: '读取用户明确指定的本机 Codex 工作区任务。仅当用户明确说出其他项目名称或 workspace_id 时调用；不能用于回答“当前项目”。',
      parameters: {
        workspace_id: { type: 'string', required: true },
        query: { type: 'string' },
      },
      output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
      async execute(args = {}) {
        const workspaceId = typeof args.workspace_id === 'string' ? args.workspace_id.trim() : ''
        return board.listTasks(workspaceId || 'opc', args.query)
      },
    }))
    tools.register(defineTool({
      name: 'codex_session_send',
      description: '向指定 Codex Session 创建一条待确认指令提案。此工具只准备，不会发送；必须向用户展示提案并得到明确确认后，再调用 codex_session_confirm_send。',
      parameters: {
        workspace_id: { type: 'string', required: true },
        session_id: { type: 'string', required: true },
        message: { type: 'string', required: true },
      },
      output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
      async execute(args, exec = {}) { return instructionHandlers.prepare(args, exec) },
    }))
    tools.register(defineTool({
      name: 'codex_session_confirm_send',
      description: '确认并发送先前由 codex_session_send 创建的 Codex 指令提案。仅在用户明确确认摘要后调用一次。',
      parameters: {
        task_id: { type: 'string', required: true },
        proposal: { type: 'object', required: true, additionalProperties: true },
      },
      output: { schema: { type: 'object', additionalProperties: true }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
      async execute(args, exec = {}) { return instructionHandlers.confirm(args, exec) },
    }))
  }
}

function sameProposal(left, right) {
  return JSON.stringify(left) === JSON.stringify(right)
}

function localBoardRoute(method, url, board) {
  if (method !== 'GET') return undefined
  if (url.pathname === `${PLUGIN_PATH}/workspaces`) {
    const workspaces = board.listWorkspaces()
    return { defaultWorkspace: workspaces[0]?.id ?? '', workspaces }
  }
  if (url.pathname === `${PLUGIN_PATH}/sessions`) return board.listSessions(url.searchParams.get('workspace'))
  if (url.pathname === `${PLUGIN_PATH}/status`) return board.status(url.searchParams.get('workspace'))
  return undefined
}

function json(response, status, payload) {
  response.statusCode = status
  response.setHeader('content-type', 'application/json; charset=utf-8')
  response.setHeader('cache-control', 'no-store')
  response.end(JSON.stringify(payload))
}

async function request(path, options = {}) {
  const response = await fetch(new URL(path, PANEL_ORIGIN()), { method: options.method ?? 'GET', headers: { 'content-type': 'application/json', ...(options.headers ?? {}) }, body: options.body ? JSON.stringify(options.body) : undefined })
  const payload = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(payload.error ?? '开发状态面板暂不可用')
  return payload
}
