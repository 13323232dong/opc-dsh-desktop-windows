import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
type SessionClaims = {
    tenantName?: string;
    accountName?: string;
    userId?: string;
    boundEmail?: string;
    role?: 'platform_admin' | 'tenant_owner';
};
declare global {
    interface Window {
        dshDesktopAuth?: {
            signOut(): Promise<{
                ok: boolean;
            }>;
            current?(): Promise<SessionClaims & {
                authenticated: boolean;
            }>;
        };
        dshDesktopCredits?: {
            balance(): Promise<{
                credits: string;
                cnyEquivalent: string;
            }>;
        };
    }
}
export type AccountSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'opcAccount'>;
/** Merchant account controls shown as a first-class DSH settings section. */
export declare function AccountSection({ t }: AccountSectionProps): import("react").JSX.Element;
export {};
