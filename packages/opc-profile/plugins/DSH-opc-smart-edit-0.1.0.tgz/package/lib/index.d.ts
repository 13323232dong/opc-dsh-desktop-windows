import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "DSH-opc-smart-edit";
export declare const inject: string[];
export interface Config {
    readonly apiBaseUrl?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, _config: Config): void;
