import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import './smart-edit.css';
export declare function SmartEditView(_props: ConvViewProps): JSX.Element;
