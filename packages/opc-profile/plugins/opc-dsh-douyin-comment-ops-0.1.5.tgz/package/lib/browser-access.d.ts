import { IncomingMessage, ServerResponse } from "node:http";

//#region src/browser-access.d.ts
interface BrowserPrincipal {
  agentId: string;
  tenantId?: string;
  userId?: string;
  loginSessionId?: string;
}
interface Grant {
  sessionId: string;
  principal: BrowserPrincipal;
  expiresAt: number;
}
/** One-use launch tickets and per-tab HttpOnly sessions, scoped to this module. */
declare function createBrowserAccess(now?: () => number): {
  issue(sessionId: string, principal: BrowserPrincipal): string;
  exchange(ticket: string, res: ServerResponse, secure: boolean): {
    scope: string;
  };
  resolve(req: IncomingMessage, requested: string): (Grant & {
    secret: string;
  }) | undefined;
  clear(): void;
};
declare function sameOriginRequest(req: IncomingMessage): boolean;
declare function samePrincipal(a: BrowserPrincipal, b: BrowserPrincipal): boolean;
declare const browserHtml = "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>\u540C\u884C\u622A\u6D41 \u00B7 Evan\u8D85\u7EA7\u7BA1\u5BB6</title></head><body style=\"margin:0;background:#f5f7fb;font-family:system-ui,sans-serif\"><div id=\"root\"></div><script type=\"module\" src=\"/plugins/opc-douyin-comment-ops/browser.js\"></script></body></html>";
//#endregion
export { BrowserPrincipal, browserHtml, createBrowserAccess, sameOriginRequest, samePrincipal };
//# sourceMappingURL=browser-access.d.ts.map