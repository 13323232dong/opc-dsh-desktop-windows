import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
declare global {
    interface Window {
        /** Installed by the trusted Electron preload, never by a browser page. */
        dshDesktopAuth?: {
            signOut(): Promise<{
                ok: boolean;
            }>;
            openMerchantConsole(): Promise<{
                ok: boolean;
            }>;
        };
    }
}
export type AccountSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'opcAccount'>;
/** Merchant account controls shown as a first-class DSH settings section. */
export declare function AccountSection({ t }: AccountSectionProps): import("react").JSX.Element;
