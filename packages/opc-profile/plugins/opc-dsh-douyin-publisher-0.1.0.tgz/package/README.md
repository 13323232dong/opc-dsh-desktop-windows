# @opc/dsh-douyin-publisher

DSH 的抖音发布专用插件。它只提供五个稳定工具：

- `douyin_upload`：上传本地视频到已登录的抖音创作者中心草稿
- `douyin_fill`：填写标题、简介和可见范围
- `douyin_preflight`：执行发布前检查并生成一次性确认令牌
- `douyin_confirm_publish`：在用户明确确认后发布
- `douyin_status`：查询草稿或作品状态

插件通过服务端 Ego Lite 任务空间操作抖音创作者中心，不接受账号密码、Cookie、第三方 API Key 或任意 URL。发布工具必须同时收到 `confirm: true` 和最新预检令牌；预检参数发生变化后旧令牌失效。

## 安装

```bash
dsh plugin --profile <profile> add /Users/mac/OPC智能体团队/dsh-plugins/opc-douyin-publisher
```

首次使用需要用户在 Ego Lite 任务空间完成登录或人机验证。遇到验证码时工具会失败关闭，不尝试绕过验证。
