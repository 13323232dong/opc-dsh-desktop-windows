export type Visibility = 'private' | 'public' | 'friends';
export interface EgoRunner {
    run(operation: string, input: Record<string, unknown>): Promise<Record<string, unknown>>;
}
export interface DouyinAccount {
    readonly loggedIn: boolean;
    readonly displayName?: string;
    readonly accountId?: string;
    readonly profileUrl?: string;
}
export interface DraftRecord {
    readonly draftId: string;
    readonly agentId: string;
    readonly videoPath: string;
    readonly title?: string;
    readonly description?: string;
    readonly visibility: Visibility;
    readonly confirmationToken?: string;
    readonly published: boolean;
}
