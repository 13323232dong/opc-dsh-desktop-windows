import type { EgoRunner, Visibility, DouyinAccount } from './types.ts';
export declare class PublisherInputError extends Error {
}
export interface PublisherConfig {
    readonly maxVideoBytes?: number;
}
export interface UploadInput {
    readonly videoPath: string;
}
export interface FillInput {
    readonly draftId: string;
    readonly title: string;
    readonly description?: string;
    readonly visibility?: Visibility;
}
export interface PreflightResult {
    readonly draftId: string;
    readonly ready: boolean;
    readonly issues: string[];
    readonly confirmationToken?: string;
    readonly title: string;
    readonly visibility: Visibility;
}
export declare function createPublisherService(runner: EgoRunner, config?: PublisherConfig): {
    account(agentId: string): Promise<DouyinAccount>;
    upload(agentId: string, input: UploadInput): Promise<{
        draftId: string;
        status: "uploaded";
        visibility: "private";
    }>;
    fill(agentId: string, input: FillInput): Promise<{
        draftId: string;
        status: "filled";
        title: string;
        visibility: Visibility;
    }>;
    preflight(agentId: string, draftId: string): Promise<PreflightResult>;
    publish(agentId: string, input: {
        readonly draftId: string;
        readonly confirmationToken: string;
        readonly confirm: boolean;
    }): Promise<{
        draftId: string;
        published: boolean;
        status: string;
    }>;
    status(agentId: string, draftId: string): Promise<{
        draftId: string;
        title: string;
        status: string;
        published: boolean;
    }>;
};
