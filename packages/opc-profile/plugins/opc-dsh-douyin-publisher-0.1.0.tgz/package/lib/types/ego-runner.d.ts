import type { EgoRunner } from './types.ts';
/** Ego Lite may emit cliLog output on either stream, depending on its host. */
export declare function parseEgoRunnerResult(stdout: string, stderr: string): Record<string, unknown>;
export declare function createEgoBrowserRunner(egoCommand: string | undefined, taskName: string): EgoRunner;
