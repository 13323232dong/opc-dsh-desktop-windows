import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "opc-douyin-publisher";
export declare const inject: string[];
export interface Config {
    readonly egoCommand?: string;
    readonly maxVideoBytes?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export type { DraftRecord, EgoRunner, Visibility, DouyinAccount } from './types.ts';
export { createPublisherService } from './publisher.ts';
