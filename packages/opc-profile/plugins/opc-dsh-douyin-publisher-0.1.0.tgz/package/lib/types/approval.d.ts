import type { PreToolDecision } from '@deepseek-ai/dsh-tools';
export declare function douyinApprovalDecision(toolName: string, next: () => Promise<PreToolDecision>): Promise<PreToolDecision>;
