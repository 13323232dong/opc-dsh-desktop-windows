import AppKit
import ApplicationServices
import CryptoKit
import Foundation

let bundle = "com.tencent.xinWeChat"
struct Failure: Error { let code: String; let message: String }
func fail(_ code: String, _ message: String) throws -> Never { throw Failure(code: code, message: message) }
func attr(_ e: AXUIElement, _ key: String) -> String {
    var value: CFTypeRef?; guard AXUIElementCopyAttributeValue(e, key as CFString, &value) == .success else { return "" }
    return value as? String ?? ""
}
func children(_ e: AXUIElement, _ key: String = "AXChildren") -> [AXUIElement] {
    var value: CFTypeRef?; AXUIElementCopyAttributeValue(e, key as CFString, &value)
    return value as? [AXUIElement] ?? []
}
func element(_ e: AXUIElement, _ key: String) -> AXUIElement? {
    var value: CFTypeRef?
    guard AXUIElementCopyAttributeValue(e, key as CFString, &value) == .success, let value else { return nil }
    return (value as! AXUIElement)
}
func nodes(_ e: AXUIElement, _ depth: Int = 0) -> [AXUIElement] {
    guard depth < 20 else { return [] }
    if attr(e, "AXIdentifier").hasSuffix("MessageCellView") { return [e] }
    return [e] + children(e).prefix(1500).flatMap { nodes($0, depth + 1) }
}
func controls(_ e: AXUIElement, _ depth: Int = 0) -> [AXUIElement] {
    guard depth < 15 else { return [] }
    if attr(e, "AXRole") == "AXTable", ["消息", "会话"].contains(name(e)) { return [e] }
    return [e] + children(e).prefix(500).flatMap { controls($0, depth + 1) }
}
func windowControls(_ application: AXUIElement) -> [AXUIElement] {
    let windows = children(application, "AXWindows") + (element(application, "AXFocusedWindow").map { [$0] } ?? [])
    return windows.isEmpty ? controls(application) : windows.flatMap { controls($0) }
}
func name(_ e: AXUIElement) -> String {
    for key in ["AXTitle", "AXDescription", "AXValue"] { let s = attr(e, key); if !s.isEmpty { return s } }
    return ""
}
func accessibleText(_ e: AXUIElement) -> String {
    // Visible chat rows have a very large AX subtree. Read the row itself,
    // direct controls, and one shallow descendant level only. This cap keeps
    // periodic preview polling below the helper deadline on large chat lists.
    let direct = children(e).prefix(24)
    let shallow = direct.flatMap { children($0).prefix(12) }
    return ([e] + direct + shallow).flatMap {
        [attr($0, "AXTitle"), attr($0, "AXDescription"), attr($0, "AXValue"), attr($0, "AXIdentifier")]
    }.filter { !$0.isEmpty }.joined(separator: " | ")
}
func emit(_ object: [String: Any]) {
    if let data = try? JSONSerialization.data(withJSONObject: object), let text = String(data: data, encoding: .utf8) {
        FileHandle.standardOutput.write(Data((text + "\n").utf8))
    }
}
func pause(_ seconds: Double) { RunLoop.current.run(until: Date().addingTimeInterval(seconds)) }
func requestAccessibility() -> [String: Any] {
    let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
    let ready = AXIsProcessTrustedWithOptions(options)
    return ["ready": ready, "permissionRequested": true]
}
func app(_ activate: Bool = true) throws -> AXUIElement {
    guard AXIsProcessTrusted() else { try fail("WECHAT_ACCESSIBILITY_REQUIRED", "请在系统设置授予桌面应用辅助功能权限") }
    guard let running = NSRunningApplication.runningApplications(withBundleIdentifier: bundle).first else { try fail("WECHAT_NOT_RUNNING", "请先打开并登录 Mac 微信") }
    if activate {
        running.activate(options: [.activateAllWindows]); pause(0.5)
        for _ in 0..<10 {
            if NSWorkspace.shared.frontmostApplication?.bundleIdentifier == bundle { break }
            running.activate(options: [.activateAllWindows]); pause(0.2)
        }
    }
    let element = AXUIElementCreateApplication(running.processIdentifier)
    AXUIElementSetMessagingTimeout(element, 0.5)
    return element
}
func ensureForeground() throws {
    if NSWorkspace.shared.frontmostApplication?.bundleIdentifier != bundle {
        // DSH can briefly reclaim focus between two sequential tool calls.
        // Re-activate WeChat once and verify it is frontmost before any AX
        // action; only an unresolved focus change is treated as a failure.
        guard let running = NSRunningApplication.runningApplications(withBundleIdentifier: bundle).first else {
            try fail("WECHAT_FOCUS_CHANGED", "微信窗口焦点已切换，操作暂停")
        }
        running.activate(options: [.activateAllWindows]); pause(0.25)
    }
    guard NSWorkspace.shared.frontmostApplication?.bundleIdentifier == bundle else { try fail("WECHAT_FOCUS_CHANGED", "微信窗口焦点已切换，操作暂停") }
}
func press(_ e: AXUIElement) throws {
    try ensureForeground()
    if AXUIElementPerformAction(e, "AXPress" as CFString) == .success { return }
    var value: CFTypeRef?, point = CGPoint.zero, size = CGSize.zero
    guard AXUIElementCopyAttributeValue(e, "AXPosition" as CFString, &value) == .success, let p = value,
          AXValueGetValue(p as! AXValue, .cgPoint, &point) else { try fail("WECHAT_ELEMENT_UNAVAILABLE", "微信控件无法定位") }
    guard AXUIElementCopyAttributeValue(e, "AXSize" as CFString, &value) == .success, let s = value,
          AXValueGetValue(s as! AXValue, .cgSize, &size), size.width > 0, size.height > 0 else { try fail("WECHAT_ELEMENT_UNAVAILABLE", "微信控件不可见") }
    let center = CGPoint(x: point.x + size.width / 2, y: point.y + size.height / 2)
    CGEvent(mouseEventSource: nil, mouseType: .leftMouseDown, mouseCursorPosition: center, mouseButton: .left)?.post(tap: .cghidEventTap)
    CGEvent(mouseEventSource: nil, mouseType: .leftMouseUp, mouseCursorPosition: center, mouseButton: .left)?.post(tap: .cghidEventTap)
}
func key(_ code: CGKeyCode, _ flags: CGEventFlags = []) throws {
    try ensureForeground()
    let down = CGEvent(keyboardEventSource: nil, virtualKey: code, keyDown: true), up = CGEvent(keyboardEventSource: nil, virtualKey: code, keyDown: false)
    down?.flags = flags; up?.flags = flags
    down?.post(tap: .cghidEventTap); up?.post(tap: .cghidEventTap)
}
func typeText(_ text: String) throws {
    try ensureForeground()
    let clipboard = NSPasteboard.general
    let saved = (clipboard.pasteboardItems ?? []).map { item -> [NSPasteboard.PasteboardType: Data] in
        var values: [NSPasteboard.PasteboardType: Data] = [:]
        for type in item.types { if let data = item.data(forType: type) { values[type] = data } }
        return values
    }
    defer {
        clipboard.clearContents()
        let restored = saved.map { values -> NSPasteboardItem in
            let item = NSPasteboardItem(); for (type, data) in values { item.setData(data, forType: type) }; return item
        }
        clipboard.writeObjects(restored)
    }
    clipboard.clearContents(); clipboard.setString(text, forType: .string)
    try key(9, .maskCommand); pause(0.25)
}
func all(_ application: AXUIElement) -> [AXUIElement] {
    let windows = children(application, "AXWindows")
    return windows.isEmpty ? nodes(application) : windows.flatMap { nodes($0) }
}
func chatRows(_ table: AXUIElement) -> [AXUIElement] {
    let directRows = (children(table, "AXVisibleChildren") + children(table, "AXRows")).filter {
        attr($0, "AXRole") == "AXRow" && (!attr($0, "AXIdentifier").isEmpty || !name($0).isEmpty)
    }
    if !directRows.isEmpty { return Array(directRows.prefix(120)) }
    var stack = Array(children(table).prefix(80).reversed()), inspected = 0, rows: [AXUIElement] = []
    while let element = stack.popLast(), inspected < 1200 && rows.count < 120 {
        inspected += 1
        let isChatRow = attr(element, "AXRole") == "AXRow" && (!attr(element, "AXIdentifier").isEmpty || !name(element).isEmpty)
        if isChatRow { rows.append(element); continue }
        stack.append(contentsOf: children(element).prefix(80).reversed())
    }
    return rows
}
func account(_ application: AXUIElement, _ allowInteraction: Bool = true) throws -> String {
    let snapshot = windowControls(application)
    if let existing = snapshot.map(name).first(where: { $0.hasPrefix("微信号:") || $0.hasPrefix("微信号：") }) {
        if allowInteraction { try key(53); pause(0.2) }
        return existing.replacingOccurrences(of: "微信号:", with: "").replacingOccurrences(of: "微信号：", with: "").trimmingCharacters(in: .whitespaces)
    }
    if !allowInteraction { try fail("WECHAT_ACCOUNT_UNAVAILABLE", "无法在不激活微信的情况下确认当前微信账号") }
    guard let avatar = snapshot.first(where: { attr($0, "AXRole") == "AXButton" && name($0) == "账户头像" }) else {
        try fail("WECHAT_LOGIN_REQUIRED", "未找到已登录微信账号入口")
    }
    try press(avatar)
    var identifier: String?
    for _ in 0..<10 {
        pause(0.15)
        identifier = windowControls(application).map(name).first { $0.hasPrefix("微信号:") || $0.hasPrefix("微信号：") }
        if identifier != nil { break }
    }
    try key(53); pause(0.15)
    guard let identifier else { try fail("WECHAT_ACCOUNT_UNAVAILABLE", "无法确认当前微信账号") }
    return identifier.replacingOccurrences(of: "微信号:", with: "").replacingOccurrences(of: "微信号：", with: "").trimmingCharacters(in: .whitespaces)
}
func composer(_ application: AXUIElement, _ title: String) throws -> AXUIElement {
    let elements = controls(application)
    let inputs = elements.filter { attr($0, "AXRole") == "AXTextArea" && (attr($0, "AXTitle") == title || attr($0, "AXDescription") == title) }
    let headings = elements.filter { attr($0, "AXRole") == "AXStaticText" && name($0) == title }
    guard inputs.count == 1, !headings.isEmpty else { try fail("WECHAT_CHAT_MISMATCH", "当前会话标题与目标联系人不一致") }
    return inputs[0]
}
func visibleChatTitle(_ row: AXUIElement, _ query: String) -> String? {
    let raw = name(row)
    guard !raw.isEmpty else { return nil }
    let title = raw.split(separator: ",", maxSplits: 1).first.map(String.init)?.trimmingCharacters(in: .whitespaces) ?? ""
    guard title == query || title.hasPrefix(query + "（") else { return nil }
    return title
}
func openContact(_ application: AXUIElement, _ title: String, verifyComposer: Bool = true) throws -> String {
    guard !title.isEmpty, title.count <= 100, !title.contains("\n") else { try fail("WECHAT_CONTACT_INVALID", "联系人名称无效") }
    // System chats such as 文件传输助手 are often omitted from search results,
    // but remain present in the visible chat table. Prefer that exact row when
    // available so we do not depend on WeChat's search index for built-ins.
    let chatTable = controls(application).first { attr($0, "AXRole") == "AXTable" && name($0) == "会话" }
    let visibleRows = (chatTable.map { nodes($0) } ?? all(application)).filter { row in
        guard attr(row, "AXRole") == "AXRow" else { return false }
        let text = name(row)
        return attr(row, "AXIdentifier") == "MMChatsTableCellView_0" || text.contains("ID: MMChatsTableCellView_0")
    }
    let visibleMatches = visibleRows.compactMap { visibleChatTitle($0, title) }
    let visibleUnique = Array(Set(visibleMatches)).sorted()
    if visibleUnique.count == 1, let resolvedTitle = visibleUnique.first,
       let row = visibleRows.first(where: { visibleChatTitle($0, title) == resolvedTitle }) {
        try press(row); pause(0.4); if verifyComposer { _ = try composer(application, resolvedTitle) }; return resolvedTitle
    }
    if visibleUnique.count > 1 { try fail("WECHAT_CONTACT_AMBIGUOUS", "搜索到多个同名联系人") }
    // Always search to discover ambiguous names instead of trusting the currently selected chat.
    try key(3, .maskCommand); pause(0.15)
    let fields = controls(application).filter { attr($0, "AXRole") == "AXTextField" }
    guard let search = fields.first(where: { attr($0, "AXPlaceholderValue") == "搜索" }) ?? fields.first(where: { attr($0, "AXSubrole") == "AXSearchField" }) else { try fail("WECHAT_SEARCH_UNAVAILABLE", "微信搜索框不可用") }
    try press(search)
    AXUIElementSetAttributeValue(search, "AXFocused" as CFString, kCFBooleanTrue)
    try key(0, .maskCommand); try typeText(title)
    // WeChat updates the AX value asynchronously after paste. Re-read it
    // briefly before failing, otherwise a valid Chinese name is rejected
    // during the first accessibility tick.
    var received = false
    for _ in 0..<8 {
        if attr(search, "AXValue") == title { received = true; break }
        pause(0.15)
    }
    if !received {
        // Some WeChat builds expose a stale AXValue even though the native
        // field accepts AXValue writes. Set it once as a fallback, then
        // verify again before continuing to search.
        _ = AXUIElementSetAttributeValue(search, "AXValue" as CFString, title as CFTypeRef)
        pause(0.25)
        received = attr(search, "AXValue") == title
    }
    guard received else { try fail("WECHAT_SEARCH_UNAVAILABLE", "搜索框没有接收完整联系人名称") }
    try key(36); pause(0.25)
    pause(0.7)
    let searchSnapshot = all(application)
    // Search result rows expose title as text on supported WeChat versions. Exclude chat header by requiring row ancestor below.
    let resultRows = searchSnapshot.filter { e in
        // Depending on the WeChat build, the stable cell id is exposed either
        // as AXIdentifier or embedded in the row's accessible description.
        // The outer selectable wrapper has neither, so accepting both forms
        // avoids counting one result twice while still excluding empty rows.
        guard attr(e, "AXRole") == "AXRow" else { return false }
        let identifier = attr(e, "AXIdentifier")
        let description = name(e)
        let isStableCell = identifier == "MMChatsTableCellView_0" || description.contains("ID: MMChatsTableCellView_0")
        let isNamedResult = description.contains(title) || nodes(e).contains { node in
            // Newer WeChat builds put the contact text in a compound row
            // value instead of a standalone AXStaticText child.
            name(node).contains(title)
        }
        guard isNamedResult else { return false }
        // Some builds omit the id on the inner row but still expose its name.
        // The wrapper row has no name, so allowing named rows remains safe.
        return isStableCell || !description.isEmpty
    }
    var unique: [AXUIElement] = [], signatures = Set<String>()
    for row in resultRows {
        let signature = name(row)
        if !signature.isEmpty && signatures.insert(signature).inserted { unique.append(row) }
    }
    if unique.count > 1 { try fail("WECHAT_CONTACT_AMBIGUOUS", "搜索到多个同名联系人") }
    if let row = unique.first { try press(row) }
    else { try fail("WECHAT_CONTACT_NOT_FOUND", "未找到唯一匹配的微信联系人") }
    pause(0.4); if verifyComposer { _ = try composer(application, title) }
    return title
}
func messages(_ application: AXUIElement, _ title: String) throws -> [[String: String]] {
    _ = try composer(application, title)
    guard let table = controls(application).first(where: { attr($0, "AXRole") == "AXTable" && name($0) == "消息" }) else { try fail("WECHAT_MESSAGES_UNAVAILABLE", "微信消息列表不可读") }
    var stamp = "", occurrences: [String: Int] = [:], result: [[String: String]] = []
    for node in nodes(table) {
        let identifier = attr(node, "AXIdentifier"), label = name(node)
        if identifier == "MMTimeStampCellView" { stamp = label }
        guard identifier == "MMTextMessageCellView" else { continue }
        let outgoing = label.hasPrefix("我说:") || label.hasPrefix("我说：")
        let incoming = label.hasPrefix(title + "说:") || label.hasPrefix(title + "说：")
        guard outgoing || incoming else { try fail("WECHAT_DIRECTION_UNKNOWN", "无法确认消息发送方向") }
        let prefixLength = outgoing ? 3 : title.count + 2
        let text = String(label.dropFirst(prefixLength)), direction = outgoing ? "outgoing" : "incoming"
        let key = stamp + "|" + direction + "|" + text
        occurrences[key, default: 0] += 1
        let id = SHA256.hash(data: Data((key + "|" + String(occurrences[key]!)).utf8)).map { String(format: "%02x", $0) }.joined()
        result.append(["id": id, "text": text, "direction": direction, "timestampLabel": stamp])
    }
    return result
}
func currentChatHasFailure(_ application: AXUIElement) -> Bool {
    guard let table = controls(application).first(where: { attr($0, "AXRole") == "AXTable" && name($0) == "消息" }) else { return false }
    return nodes(table).contains { element in
        let label = name(element)
        return label.contains("发送失败") || label.contains("消息已发出，但被对方拒收") || label.contains("开启了朋友验证")
    }
}
func chatPreviews(_ application: AXUIElement, _ accountId: String) -> [[String: Any]] {
    guard let table = controls(application).first(where: { attr($0, "AXRole") == "AXTable" && name($0) == "会话" }) else { return [] }
    var chats: [[String: Any]] = [], seen = Set<String>()
    for row in chatRows(table) {
        let raw = accessibleText(row)
        guard raw.contains("ID: MMChatsTableCellView_0") || attr(row, "AXIdentifier") == "MMChatsTableCellView_0" else { continue }
        let parts = raw.split(separator: ",", omittingEmptySubsequences: false).map { String($0).trimmingCharacters(in: .whitespaces) }
        let title = parts.first(where: { !$0.isEmpty && !$0.hasPrefix("ID:") && $0 != "MMChatsTableCellView_0" }) ?? ""
        let excludedTitles: Set<String> = ["公众号", "服务号", "服务号消息", "订阅号", "订阅号消息", "文件传输助手", "file transfer", "file transfer assistant", "filehelper", "official accounts", "subscription accounts", "service accounts"]
        guard !title.isEmpty, !excludedTitles.contains(title.lowercased()), seen.insert(title).inserted else { continue }
        let preview = parts.dropFirst().first(where: { !$0.isEmpty && !$0.hasPrefix("ID:") && !$0.contains("条未读") }) ?? ""
        let unread = raw.range(of: "([0-9]+|99\\+)条未读", options: .regularExpression).flatMap { match -> Int? in
            Int(String(raw[match]).replacingOccurrences(of: "条未读", with: "").replacingOccurrences(of: "+", with: ""))
        } ?? 0
        let hasUnread = unread > 0 || raw.contains("未读消息") || raw.contains("unread") || raw.contains("红点")
        let id = accountId + ":" + title
        let signature = SHA256.hash(data: Data((raw + "|" + preview + "|" + String(unread) + "|" + String(hasUnread)).utf8)).map { String(format: "%02x", $0) }.joined()
        chats.append(["id": id, "title": title, "preview": preview, "unreadCount": unread, "hasUnread": hasUnread, "signature": signature])
    }
    return chats
}
func handle(_ request: [String: Any]) throws -> [String: Any] {
    let method = request["method"] as? String ?? "", payload = request["payload"] as? [String: Any] ?? [:], id = request["requestId"] as? String ?? ""
    guard ["probe", "status", "requestAccessibility", "findContact", "listChats", "openChat", "readChat", "readHistory", "readComposer", "draft", "sendAction", "readSendEvidence", "send"].contains(method) else { try fail("WECHAT_METHOD_INVALID", "不支持的微信操作") }
    var requestedPages = 1
    if method == "readHistory", let rawPages = payload["pages"] {
        guard let number = rawPages as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
              number.doubleValue == Double(number.intValue), (1...5).contains(number.intValue) else {
            try fail("WECHAT_HISTORY_PAGES_INVALID", "历史读取页数必须为 1 到 5 的整数")
        }
        requestedPages = number.intValue
    }
    if method == "requestAccessibility" { return requestAccessibility() }
    if method == "probe" {
        let application = try app(false)
        var pid: pid_t = 0
        AXUIElementGetPid(application, &pid)
        let loggedIn = controls(application).contains { attr($0, "AXRole") == "AXButton" && name($0) == "账户头像" }
        return ["ready": loggedIn, "processId": Int(pid), "failureCode": loggedIn ? NSNull() : "WECHAT_LOGIN_REQUIRED"]
    }
    let readOnlyScan = method == "listChats"
    let expectedAccountId = payload["accountId"] as? String
    if readOnlyScan && (expectedAccountId == nil || expectedAccountId!.isEmpty) {
        try fail("WECHAT_ACCOUNT_UNAVAILABLE", "后台扫描缺少已确认的微信账号")
    }
    let application = try app(!readOnlyScan)
    var pid: pid_t = 0
    AXUIElementGetPid(application, &pid)
    if readOnlyScan && payload["processId"] as? Int != Int(pid) {
        try fail("WECHAT_ACCOUNT_CHANGED", "微信进程已变化，请重新确认账号")
    }
    let accountId = readOnlyScan ? expectedAccountId! : try account(application)
    if method == "status" { return ["accountId": accountId, "processId": Int(pid), "ready": true] }
    if method == "listChats" { return ["accountId": accountId, "chats": chatPreviews(application, accountId)] }
    let contact = payload["contact"] as? [String: Any] ?? [:]
    let title = payload["name"] as? String ?? contact["title"] as? String ?? contact["name"] as? String ?? payload["contact"] as? String ?? ""
    if let expected = contact["accountId"] as? String, expected != accountId { try fail("WECHAT_ACCOUNT_CHANGED", "微信账号已切换") }
    emit(["requestId": id, "stage": "locating"])
    let resolvedTitle = try openContact(application, title, verifyComposer: method != "findContact")
    let identity: [String: Any] = ["accountId": accountId, "id": accountId + ":" + resolvedTitle, "contactId": accountId + ":" + resolvedTitle, "title": resolvedTitle, "name": resolvedTitle]
    if method == "findContact" { return identity }
    if method == "openChat" { return identity.merging(["status": "opened"]) { _, new in new } }
    if method == "readComposer" {
        let input = try composer(application, resolvedTitle)
        return identity.merging(["value": attr(input, "AXValue"), "available": true]) { _, new in new }
    }
    let baseline = try messages(application, resolvedTitle)
    if method == "readChat" { return identity.merging(["messages": baseline]) { _, new in new } }
    if method == "readHistory" {
        // Only the currently loaded AX text messages are verified. No reliable
        // table-specific pagination action is established for supported builds.
        // Do not send global scroll keys or repeat expensive full-tree scans:
        // preserve the 45-second helper deadline and report the actual coverage.
        let timeLabels = baseline.compactMap { $0["timestampLabel"] }.reduce(into: [String]()) { labels, label in
            if !label.isEmpty && !labels.contains(label) { labels.append(label) }
        }
        let coverage: [String: Any] = ["pagesRead": 1, "requestedPages": requestedPages,
            "complete": false, "source": "wechat_accessibility", "timeLabels": timeLabels]
        return identity.merging(["messages": baseline, "coverage": coverage]) { _, new in new }
    }
    guard let text = payload["text"] as? String, !text.isEmpty, text.count <= 3000, !text.contains("\0") else { try fail("WECHAT_TEXT_INVALID", "发送文本为空或过长") }
    let input = try composer(application, resolvedTitle)
    let existingDraft = attr(input, "AXValue")
    if method == "sendAction" {
        guard existingDraft == text else { try fail("WECHAT_COMPOSER_MISMATCH", "微信输入框正文与待发送内容不一致") }
        try ensureForeground(); try press(input); try key(36)
        return ["status": "action_performed", "accountId": accountId, "contactId": accountId + ":" + resolvedTitle]
    }
    if method == "readSendEvidence" {
        return ["status": "observed", "accountId": accountId, "contactId": accountId + ":" + resolvedTitle, "messages": baseline, "composer": existingDraft, "failure": currentChatHasFailure(application)]
    }
    let replaceExisting = payload["replaceExisting"] as? Bool ?? false
    if !existingDraft.isEmpty && !replaceExisting { try fail("WECHAT_EXISTING_DRAFT", "微信输入框已有草稿，未覆盖") }
    emit(["requestId": id, "stage": "inputting"])
    try press(input)
    if !existingDraft.isEmpty {
        try key(0, .maskCommand); try key(51); pause(0.1)
        guard attr(input, "AXValue").isEmpty else { try fail("WECHAT_DRAFT_REPLACE_FAILED", "无法清除微信输入框原有草稿") }
    }
    guard AXUIElementSetAttributeValue(input, "AXValue" as CFString, text as CFTypeRef) == .success, attr(input, "AXValue") == text else { try fail("WECHAT_INPUT_UNAVAILABLE", "微信输入框未接收完整文本") }
    if method == "draft" { return ["status": "drafted", "evidence": ["kind": "input_draft", "clientDisplayed": true, "sent": false, "replacedExistingDraft": !existingDraft.isEmpty]] }
    _ = try composer(application, resolvedTitle); try ensureForeground()
    emit(["requestId": id, "stage": "sending"])
    try key(36)
    emit(["requestId": id, "stage": "verifying"])
    let oldCount = baseline.filter { $0["direction"] == "outgoing" && $0["text"] == text }.count
    for _ in 0..<20 {
        pause(0.25)
        guard NSWorkspace.shared.frontmostApplication?.bundleIdentifier == bundle else { break }
        guard let current = try? messages(application, resolvedTitle) else { break }
        let failures = currentChatHasFailure(application)
        if failures { try fail("WECHAT_PLATFORM_REJECTED", "微信界面显示发送失败或接收限制") }
        let matching = current.filter { $0["direction"] == "outgoing" && $0["text"] == text }
        if matching.count > oldCount, current.last?["direction"] == "outgoing", current.last?["text"] == text, attr(input, "AXValue").isEmpty {
            return ["status": "sent", "evidence": ["kind": "new_outgoing_bubble", "messageId": current.last!["id"]!, "clientDisplayed": true, "recipientRead": false]]
        }
    }
    return ["status": "unknown", "failureCode": "WECHAT_SEND_UNKNOWN"]
}
if let line = readLine(), let data = line.data(using: .utf8), let request = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
    let id = request["requestId"] as? String ?? ""
    do { emit(["requestId": id, "ok": true, "result": try handle(request)]) }
    catch let error as Failure { emit(["requestId": id, "ok": false, "error": ["code": error.code, "message": error.message]]) }
    catch { emit(["requestId": id, "ok": false, "error": ["code": "WECHAT_HELPER_ERROR", "message": "微信本地控制组件异常"]]) }
}
