# OPC 内容发布审核

基于 `yuwen-cool/yuwen-publish-precheck` 的本地规则资产，向 DSH Agent 暴露一个受控、只读的发布前文本审核工具。它只审稿，不执行发布，不提供绕审建议；身份、审计和用户规则数据均由 OPC API 管理。
