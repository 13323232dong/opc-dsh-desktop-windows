export interface PublishPrecheckGatewayConfig {
    readonly apiBaseUrl?: string;
    readonly tenantId?: string;
    readonly userId?: string;
}
export interface PublishPrecheckGatewayRequest {
    readonly agentId: string;
    readonly input: unknown;
}
export interface PublishPrecheckGatewayDependencies {
    readonly fetcher?: typeof fetch;
    readonly environment?: NodeJS.ProcessEnv;
    readonly createRequestId?: () => string;
}
export declare class PublishPrecheckGatewayError extends Error {
}
/** Calls the fixed OPC server-side precheck adapter without exposing credentials to a model. */
export declare function createPublishPrecheckGateway(config: PublishPrecheckGatewayConfig, dependencies?: PublishPrecheckGatewayDependencies): {
    scan(request: PublishPrecheckGatewayRequest): Promise<unknown>;
};
