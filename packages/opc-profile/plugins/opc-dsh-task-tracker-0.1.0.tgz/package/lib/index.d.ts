import { Context } from "@deepseek-ai/cordis";
//#region src/index.d.ts
declare const name = "opc-task-tracker";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { apply, inject, name };
//# sourceMappingURL=index.d.ts.map