import { Context } from "@deepseek-ai/cordis";
//#region src/index.d.ts
interface VoiceTaskBoardChannel {
  createFromVoice(input: {
    sourceSessionId: string;
    title: string;
    summary: string;
  }): Promise<Record<string, unknown>>;
  confirmVoiceTask(input: {
    sourceSessionId: string;
    taskId: string;
    confirmationId: string;
    instruction: string;
  }): Promise<Record<string, unknown>>;
  cancelVoiceTask(input: {
    sourceSessionId: string;
    taskId: string;
    confirmationId: string;
  }): Promise<Record<string, unknown>>;
}
declare const name = "opc-task-tracker";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { VoiceTaskBoardChannel, apply, inject, name };
//# sourceMappingURL=index.d.ts.map