# OPC Task Tracker

DSH 顶部“任务”标签，展示当前租户的大任务状态。任务卡只读，审批仍在原对话完成。

部署 DSH 服务端时设置 `OPC_TASKS_PROXY_URL` 指向 Harness（例如 `http://127.0.0.1:3010`）。插件只在 host 进程转发当前登录会话凭证，浏览器不会获得 OPC/Harness 密钥。
