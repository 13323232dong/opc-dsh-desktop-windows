# OPC Viral Chase DSH plugin

This host-side plugin exposes the OPC 一键追爆 workflow to DeepSeek Harness.
It only registers DSH tools and forwards calls to the OPC API. Provider
credentials, tenant authorization, billing, plan gates, and media execution
remain in the OPC control plane.

Configure `apiBaseUrl`, `tenantId`, and `userId` from the authenticated OPC
session. `OPC_API_BASE_URL`, `OPC_TENANT_ID`, `OPC_USER_ID`, and
`OPC_AGENT_API_KEY` are also supported. The plugin refuses to run when a
tenant or user identity is missing.

The CEO agent should call `viral_chase_create`, then
`viral_chase_prepare_plan`, and wait for explicit user approval before calling
any paid step tool. The seven creative steps are extract, rewrite, speech,
seedance avatar, edit, metadata, and cover. Publishing is deliberately not
part of this plugin's default workflow and remains an independent approval.

```bash
pnpm install
pnpm typecheck
pnpm build
pnpm test
```
