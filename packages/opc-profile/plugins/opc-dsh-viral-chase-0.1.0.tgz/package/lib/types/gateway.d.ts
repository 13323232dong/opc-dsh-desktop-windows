export interface ViralChaseGatewayConfig {
    readonly apiBaseUrl?: string;
    readonly tenantId?: string;
    readonly userId?: string;
    readonly identityHmacSecret?: string;
}
export interface ViralChaseGatewayDependencies {
    readonly fetcher?: typeof fetch;
    readonly environment?: NodeJS.ProcessEnv;
    readonly createRequestId?: () => string;
    readonly resolveIdentity?: (sessionId: string, parentSessionId?: string) => Promise<{
        tenantId: string;
        userId: string;
        agentId: string;
    } | undefined>;
}
export interface ViralChaseToolRequest {
    readonly agentId: string;
    readonly sessionId?: string;
    readonly parentSessionId?: string;
    readonly action: ViralChaseAction;
    readonly input: Record<string, unknown>;
    readonly idempotencyKey?: string;
}
export type ViralChaseAction = 'create' | 'list' | 'status' | 'list_anchors' | 'create_anchor' | 'runtime_status' | 'generate_script' | 'quote_production' | 'approve_production' | 'start_production' | 'production_status' | 'cancel_production' | 'retry_production_step' | 'review_final_video' | 'request_revision' | 'approve_final' | 'export' | 'prepare_plan' | 'approve_plan' | 'extract_copy' | 'rewrite_copy' | 'synthesize_voice' | 'generate_video' | 'edit_video' | 'generate_metadata' | 'generate_cover' | 'save_script' | 'generate_shot_plan' | 'review_preproduction' | 'approve_generation' | 'generate_motion_shot' | 'export_script_to_feishu' | 'feishu_export_status' | 'get_shot_images' | 'quote_shot_images' | 'approve_shot_images' | 'generate_shot_images' | 'regenerate_shot_image' | 'cancel_shot_image_run';
export declare class ViralChaseGatewayError extends Error {
    readonly status?: number;
    readonly code?: string;
    constructor(message: string, details?: {
        status?: number;
        code?: string;
    });
}
/** A thin trusted adapter. It never calls providers or accepts identity from model input. */
export declare function createViralChaseGateway(config: ViralChaseGatewayConfig, dependencies?: ViralChaseGatewayDependencies): {
    execute(request: ViralChaseToolRequest): Promise<unknown>;
};
