export declare const STORYBOARD_COLUMNS: readonly [{
    readonly key: "shot_number";
    readonly title: "镜号";
}, {
    readonly key: "time_range";
    readonly title: "时间";
}, {
    readonly key: "reference_visual";
    readonly title: "参考画面";
}, {
    readonly key: "shot_size";
    readonly title: "景别";
}, {
    readonly key: "camera_movement";
    readonly title: "镜头/运镜";
}, {
    readonly key: "dialogue_audio";
    readonly title: "台词/音效";
}, {
    readonly key: "lighting_mood";
    readonly title: "光影/氛围";
}, {
    readonly key: "material_source";
    readonly title: "素材来源";
}, {
    readonly key: "notes";
    readonly title: "备注";
}];
export type StoryboardColumnKey = typeof STORYBOARD_COLUMNS[number]['key'];
export type StoryboardRow = Record<StoryboardColumnKey, string> & {
    readonly referenceImageAssetId?: string;
};
export interface ShotImageSpec {
    readonly shotNumber: string;
    readonly prompt: string;
    readonly negativePrompt?: string;
    readonly modelId?: string;
    readonly ratio?: string;
    readonly resolution?: string;
}
export interface ShotImageQuote {
    readonly id?: string;
    readonly quoteId?: string;
    readonly proposalId?: string;
    readonly status?: string;
    readonly estimatedCost?: number;
    readonly unitCost?: number;
    readonly contentHash?: string;
    readonly shotNumbers?: readonly string[];
    readonly expiresAt?: string;
}
export interface ShotImageApproval {
    readonly id?: string;
    readonly quoteId?: string;
    readonly token?: string;
    readonly approvalToken?: string;
    readonly quoteHash?: string;
}
export interface ShotImageRun {
    readonly id?: string;
    readonly runId?: string;
    readonly status?: string;
    readonly progress?: number;
    readonly error?: string;
}
export interface ShotImageItem {
    readonly shotNumber: string;
    readonly status?: 'missing' | 'quoting' | 'awaiting_approval' | 'queued' | 'generating' | 'ready' | 'failed' | 'stale';
    readonly prompt?: string;
    readonly imageUrl?: string;
    readonly previewUrl?: string;
    readonly assetId?: string;
    readonly runId?: string;
    readonly error?: string;
}
export interface ShotImagesAggregate {
    readonly specs: readonly ShotImageSpec[];
    readonly currentQuote?: ShotImageQuote;
    readonly currentApproval?: ShotImageApproval;
    readonly runs: readonly ShotImageRun[];
    readonly items: readonly ShotImageItem[];
}
export interface StoryboardScript {
    readonly id?: string;
    readonly revision: number;
    readonly title: string;
    readonly rows: readonly StoryboardRow[];
    readonly source?: string;
    readonly createdAt?: string;
    readonly artifactHash?: string;
    readonly contentHash?: string;
}
export interface ShotPlan {
    readonly id?: string;
    readonly revision: number;
    readonly scriptRevision: number;
    readonly shots: readonly Record<string, unknown>[];
    readonly estimatedCost?: number;
    readonly createdAt?: string;
    readonly scriptHash?: string;
    readonly artifactHash?: string;
    readonly contentHash?: string;
}
export interface PreproductionReview {
    readonly revision: number;
    readonly scriptRevision: number;
    readonly shotPlanRevision: number;
    readonly status: 'approved' | 'needs_revision' | 'blocked' | string;
    readonly score?: number;
    readonly risks?: readonly string[];
    readonly requiredChanges?: readonly string[];
    readonly suggestedChanges?: readonly string[];
    readonly reviewerVersion?: string;
    readonly checklist?: readonly {
        readonly item?: string;
        readonly passed?: boolean;
        readonly note?: string;
    }[];
    readonly createdAt?: string;
    readonly scriptHash?: string;
    readonly shotPlanHash?: string;
    readonly artifactHash?: string;
    readonly contentHash?: string;
}
export interface GenerationApproval {
    readonly scriptRevision: number;
    readonly shotPlanRevision: number;
    readonly reviewRevision: number;
    readonly status?: string;
    readonly token?: string;
    readonly confirmationToken?: string;
    readonly approvalToken?: string;
    readonly approvedAt?: string;
    readonly approvedBy?: string;
    readonly artifactHash?: string;
    readonly reviewArtifactHash?: string;
}
export interface FinalVideoArtifact {
    readonly artifactHash: string;
    readonly url?: string;
    readonly assetId?: string;
    readonly createdAt?: string;
}
export interface FinalVideoReview {
    readonly revision: number;
    readonly status: 'approved' | 'needs_revision' | 'blocked' | string;
    readonly scriptRevision?: number;
    readonly shotPlanRevision?: number;
    readonly generationApprovalToken?: string;
    readonly videoAssetId?: string;
    readonly videoVersion?: number;
    readonly videoHash: string;
    readonly contentHash: string;
    readonly videoArtifactHash?: string;
    readonly artifactHash?: string;
    readonly score?: number;
    readonly requiredChanges?: readonly string[];
    readonly affectedShotNumbers?: readonly string[];
    readonly findings?: readonly {
        readonly message?: string;
        readonly severity?: string;
        readonly shotNumbers?: readonly string[];
        readonly requiredAction?: string;
    }[];
    readonly checklist?: readonly {
        readonly item?: string;
        readonly passed?: boolean;
        readonly note?: string;
    }[];
    readonly reviewerVersion?: string;
    readonly createdAt?: string;
}
export interface FinalUserApproval {
    readonly finalReviewRevision: number;
    readonly videoHash: string;
    readonly artifactHash: string;
    readonly reviewRevision?: number;
    readonly videoArtifactHash?: string;
    readonly reviewArtifactHash?: string;
    readonly token?: string;
    readonly confirmationToken?: string;
    readonly approvalToken?: string;
    readonly approvedAt?: string;
}
export interface ViralChaseJob {
    readonly id: string;
    readonly name?: string;
    readonly sourceUrl?: string;
    readonly sourceText?: string;
    readonly status?: string;
    readonly progress?: number;
    readonly estimatedCost?: number;
    readonly chargedCost?: number;
    readonly createdAt?: string;
    readonly updatedAt?: string;
    readonly plan?: {
        readonly id?: string;
        readonly revision?: number;
        readonly approvalStatus?: string;
        readonly status?: string;
    };
    readonly storyboard?: {
        readonly currentRevision?: number;
        readonly versions?: readonly StoryboardScript[];
    };
    readonly shotPlanning?: {
        readonly currentRevision?: number;
        readonly versions?: readonly ShotPlan[];
    };
    readonly preproductionReviews?: readonly PreproductionReview[];
    readonly generationApproval?: GenerationApproval;
    readonly steps?: readonly {
        readonly key?: string;
        readonly status?: string;
        readonly progress?: number;
        readonly output?: Readonly<Record<string, unknown>>;
    }[];
    readonly finalVideo?: FinalVideoArtifact;
    readonly finalVideoReviews?: readonly FinalVideoReview[];
    readonly finalReviews?: readonly FinalVideoReview[];
    readonly finalApproval?: FinalUserApproval;
}
export interface WorkbenchGate {
    readonly hasScript: boolean;
    readonly hasShotPlan: boolean;
    readonly preReviewApproved: boolean;
    readonly userApproved: boolean;
    readonly canGenerate: boolean;
    readonly nextAction: 'script' | 'shot-plan' | 'review' | 'approve' | 'generate';
}
export interface FinalGate {
    readonly hasGeneratedVideo: boolean;
    readonly finalReviewApproved: boolean;
    readonly userFinalApproved: boolean;
    readonly canExport: boolean;
    readonly nextAction: 'generate' | 'final-review' | 'final-approve' | 'export';
}
export interface ShotPlanDraftInput {
    readonly scriptRevision: number;
    readonly shots: readonly {
        shotNumber: string;
        timeRange: string;
        targetDuration: number;
        scriptSegment: string;
        visualGoal: string;
        shotSize: string;
        sourceType: 'asset_library' | 'minimax_h3' | 'seedance' | 'hyperframes';
        materialCandidates: readonly {
            assetId: string;
            score: number;
        }[];
        protagonistAnchorId?: string;
        engine: 'asset_library' | 'minimax_h3' | 'seedance' | 'hyperframes';
        captions: string;
        sound: string;
        music: string;
        transition: string;
        authorizationStatus: 'confirmed' | 'pending' | 'blocked';
        estimatedCost: number;
        fallback: string;
    }[];
}
export declare function currentScript(job: Pick<ViralChaseJob, 'storyboard'>): StoryboardScript | undefined;
export declare function currentShotPlan(job: Pick<ViralChaseJob, 'shotPlanning' | 'storyboard'>): ShotPlan | undefined;
export declare function currentApprovedReview(job: Pick<ViralChaseJob, 'storyboard' | 'shotPlanning' | 'preproductionReviews'>): PreproductionReview | undefined;
export declare function deriveWorkbenchGate(job: Pick<ViralChaseJob, 'storyboard' | 'shotPlanning' | 'preproductionReviews' | 'generationApproval'>): WorkbenchGate;
export declare function currentFinalReview(job: Pick<ViralChaseJob, 'finalVideoReviews' | 'finalReviews'>): FinalVideoReview | undefined;
export declare function currentApprovedFinalReview(job: Pick<ViralChaseJob, 'finalVideoReviews' | 'finalReviews'>): FinalVideoReview | undefined;
export declare function deriveFinalGate(job: Pick<ViralChaseJob, 'steps' | 'finalVideo' | 'finalVideoReviews' | 'finalReviews' | 'finalApproval'>): FinalGate;
export declare function emptyStoryboardRow(index: number): StoryboardRow;
export declare function moveStoryboardRow(rows: readonly StoryboardRow[], index: number, offset: -1 | 1): StoryboardRow[];
export declare function normalizeShotImages(value: unknown): ShotImagesAggregate;
export declare function buildShotPlanDraft(script: StoryboardScript): ShotPlanDraftInput;
export declare function normalizeJobs(value: unknown): ViralChaseJob[];
