import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
export declare function ViralChaseWorkbench({ sessionId }: ConvViewProps): JSX.Element;
