export interface RevocableProtagonistAnchor {
    readonly id: string;
    readonly authorizationStatus: string;
}
interface ProtagonistAnchorRevokerDependencies {
    readonly sessionId: string;
    readonly confirm: (message: string) => boolean;
    readonly revoke: (sessionId: string, anchorId: string) => Promise<unknown>;
    readonly refresh: () => Promise<unknown>;
    readonly resetAuthorizationConfirmation: () => void;
    readonly onBusy: (busy: boolean) => void;
    readonly onNotice: (message: string) => void;
    readonly onError: (message: string) => void;
    readonly onStart?: () => void;
}
export declare function canRevokeProtagonistAnchor(anchor: RevocableProtagonistAnchor | undefined): boolean;
export declare function createProtagonistAnchorRevoker(dependencies: ProtagonistAnchorRevokerDependencies): (anchor: RevocableProtagonistAnchor | undefined) => Promise<void>;
export {};
