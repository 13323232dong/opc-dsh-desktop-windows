export declare function installWorkbenchStyles(): void;
