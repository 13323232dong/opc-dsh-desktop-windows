import { type ShotImagesAggregate, type StoryboardRow, type ViralChaseJob } from './workbench-model.js';
export declare function loadViralJobs(sessionId: string, signal?: AbortSignal): Promise<ViralChaseJob[]>;
export declare function saveScript(sessionId: string, jobId: string, input: {
    title: string;
    rows: readonly StoryboardRow[];
}): Promise<unknown>;
export declare function saveShotPlan(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function requestPreproductionReview(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveGeneration(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function startGeneration(sessionId: string, job: ViralChaseJob): Promise<unknown>;
export declare function requestFinalReview(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveFinalDelivery(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function loadJobRevisions(sessionId: string, jobId: string): Promise<unknown>;
export declare function requestShotRevision(sessionId: string, jobId: string, input: {
    readonly finalReviewRevision: number;
    readonly shotNumbers: readonly string[];
    readonly reason: string;
}): Promise<unknown>;
export declare function loadShotImages(sessionId: string, jobId: string, signal?: AbortSignal): Promise<ShotImagesAggregate>;
export declare function quoteShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function runShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function rerunShotImage(sessionId: string, jobId: string, shotNumber: string, input: object): Promise<unknown>;
export declare function cancelShotImageRun(sessionId: string, jobId: string, runId: string): Promise<unknown>;
