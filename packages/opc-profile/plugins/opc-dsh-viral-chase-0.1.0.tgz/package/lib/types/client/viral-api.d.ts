import { type ProductionEngine, type ProtagonistAnchor, type ShotImagesAggregate, type StoryboardRow, type ViralChaseJob, type ViralProductionApproval, type ViralProductionQuote, type ViralProductionRun, type ViralRuntimeStatus } from './workbench-model.js';
interface ViralJobEventHandlers {
    readonly onJob: (job: ViralChaseJob) => void;
    readonly onOpen: () => void;
    readonly onError: () => void;
}
interface EventSourceLike {
    addEventListener(type: string, listener: (event: Event) => void): void;
    close(): void;
}
type EventSourceFactory = (url: string) => EventSourceLike;
export declare function safeApiError(code: string | undefined, status: number): string;
export declare function loadViralJobs(sessionId: string, signal?: AbortSignal): Promise<ViralChaseJob[]>;
export declare function subscribeViralJobEvents(sessionId: string, jobId: string, handlers: ViralJobEventHandlers, createSource?: EventSourceFactory): () => void;
export declare function saveScript(sessionId: string, jobId: string, input: {
    title: string;
    rows: readonly StoryboardRow[];
}): Promise<unknown>;
export declare function saveShotPlan(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function requestPreproductionReview(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveGeneration(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function startGeneration(sessionId: string, job: ViralChaseJob): Promise<unknown>;
export declare function requestFinalReview(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveFinalDelivery(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function loadJobRevisions(sessionId: string, jobId: string): Promise<unknown>;
export declare function requestShotRevision(sessionId: string, jobId: string, input: {
    readonly finalReviewRevision: number;
    readonly shotNumbers: readonly string[];
    readonly reason: string;
}): Promise<unknown>;
export declare function loadShotImages(sessionId: string, jobId: string, signal?: AbortSignal): Promise<ShotImagesAggregate>;
export declare function quoteShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function approveShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function runShotImages(sessionId: string, jobId: string, input: object): Promise<unknown>;
export declare function rerunShotImage(sessionId: string, jobId: string, shotNumber: string, input: object): Promise<unknown>;
export declare function cancelShotImageRun(sessionId: string, jobId: string, runId: string): Promise<unknown>;
export declare function loadProtagonistAnchors(sessionId: string, signal?: AbortSignal): Promise<ProtagonistAnchor[]>;
export declare function uploadProtagonistVideo(sessionId: string, file: File): Promise<{
    readonly uploadId: string;
}>;
export declare function createProtagonistAnchor(sessionId: string, input: {
    readonly name: string;
    readonly uploadId: string;
}): Promise<ProtagonistAnchor>;
export declare function authorizeProtagonistAnchor(sessionId: string, anchorId: string): Promise<unknown>;
export declare function recheckProtagonistAnchor(sessionId: string, anchorId: string): Promise<unknown>;
export declare function revokeProtagonistAnchor(sessionId: string, anchorId: string): Promise<unknown>;
export declare function loadRuntimeStatus(sessionId: string, signal?: AbortSignal): Promise<ViralRuntimeStatus>;
export declare function quoteProduction(sessionId: string, jobId: string, input: {
    readonly protagonistAnchorId: string;
    readonly engine: ProductionEngine;
    readonly scriptRevision: number;
    readonly shotPlanRevision: number;
    readonly reviewRevision: number;
    readonly targetDurationSeconds?: number;
}): Promise<ViralProductionQuote>;
export declare function approveProduction(sessionId: string, jobId: string, input: {
    readonly quoteId: string;
    readonly quoteHash: string;
    readonly maxCost: number;
}): Promise<ViralProductionApproval>;
export declare function startProduction(sessionId: string, jobId: string, input: {
    readonly approvalToken: string;
}): Promise<ViralProductionRun>;
export declare function loadProductionStatus(sessionId: string, jobId: string, signal?: AbortSignal): Promise<{
    readonly quote?: ViralProductionQuote;
    readonly approval?: ViralProductionApproval;
    readonly run?: ViralProductionRun;
}>;
export declare function cancelProduction(sessionId: string, jobId: string): Promise<unknown>;
export declare function retryProductionStep(sessionId: string, jobId: string, step: string): Promise<unknown>;
export declare function exportProduction(sessionId: string, jobId: string, input: {
    readonly finalReviewRevision: number;
    readonly finalApprovalToken: string;
}): Promise<unknown>;
export declare function protectedViralMediaUrl(sessionId: string, path: string): string;
export {};
