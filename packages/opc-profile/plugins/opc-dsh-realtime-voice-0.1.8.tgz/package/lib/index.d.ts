import { Context } from "@deepseek-ai/cordis";

//#region node_modules/.pnpm/@deepseek-ai+cosmokit@1.8.3/node_modules/@deepseek-ai/cosmokit/lib/types/types.d.ts
declare function isArrayBufferLike(value: any): value is ArrayBufferLike;
declare function isArrayBufferSource(value: any): value is Binary.Source;
/** Binary source detection and base64/hex conversion helpers. */
declare namespace Binary {
  type Source<T extends ArrayBufferLike = ArrayBufferLike> = T | ArrayBufferView<T>;
  const is: typeof isArrayBufferLike;
  const isSource: typeof isArrayBufferSource;
  function fromSource<T extends ArrayBufferLike>(source: Source<T>): T;
  function toBase64(source: Source): string;
  function fromBase64(source: string): ArrayBuffer | Uint8Array<ArrayBuffer>;
  function toHex(source: Source): string;
  function fromHex(source: string): ArrayBuffer;
}
//#endregion
//#region node_modules/.pnpm/@deepseek-ai+cosmokit@1.8.3/node_modules/@deepseek-ai/cosmokit/lib/types/misc.d.ts
/** String/symbol keyed dictionary type. */
type Dict<T = any, K extends string | symbol = string> = { [key in K]: T };
//#endregion
//#region node_modules/.pnpm/@standard-schema+spec@1.1.0/node_modules/@standard-schema/spec/dist/index.d.ts
/** The Standard Typed interface. This is a base type extended by other specs. */
interface StandardTypedV1<Input = unknown, Output = Input> {
  /** The Standard properties. */
  readonly "~standard": StandardTypedV1.Props<Input, Output>;
}
declare namespace StandardTypedV1 {
  /** The Standard Typed properties interface. */
  interface Props<Input = unknown, Output = Input> {
    /** The version number of the standard. */
    readonly version: 1;
    /** The vendor name of the schema library. */
    readonly vendor: string;
    /** Inferred types associated with the schema. */
    readonly types?: Types<Input, Output> | undefined;
  }
  /** The Standard Typed types interface. */
  interface Types<Input = unknown, Output = Input> {
    /** The input type of the schema. */
    readonly input: Input;
    /** The output type of the schema. */
    readonly output: Output;
  }
  /** Infers the input type of a Standard Typed. */
  type InferInput<Schema extends StandardTypedV1> = NonNullable<Schema["~standard"]["types"]>["input"];
  /** Infers the output type of a Standard Typed. */
  type InferOutput<Schema extends StandardTypedV1> = NonNullable<Schema["~standard"]["types"]>["output"];
}
/** The Standard Schema interface. */
interface StandardSchemaV1<Input = unknown, Output = Input> {
  /** The Standard Schema properties. */
  readonly "~standard": StandardSchemaV1.Props<Input, Output>;
}
declare namespace StandardSchemaV1 {
  /** The Standard Schema properties interface. */
  interface Props<Input = unknown, Output = Input> extends StandardTypedV1.Props<Input, Output> {
    /** Validates unknown input values. */
    readonly validate: (value: unknown, options?: StandardSchemaV1.Options | undefined) => Result<Output> | Promise<Result<Output>>;
  }
  /** The result interface of the validate function. */
  type Result<Output> = SuccessResult<Output> | FailureResult;
  /** The result interface if validation succeeds. */
  interface SuccessResult<Output> {
    /** The typed output value. */
    readonly value: Output;
    /** A falsy value for `issues` indicates success. */
    readonly issues?: undefined;
  }
  interface Options {
    /** Explicit support for additional vendor-specific parameters, if needed. */
    readonly libraryOptions?: Record<string, unknown> | undefined;
  }
  /** The result interface if validation fails. */
  interface FailureResult {
    /** The issues of failed validation. */
    readonly issues: ReadonlyArray<Issue>;
  }
  /** The issue interface of the failure output. */
  interface Issue {
    /** The error message of the issue. */
    readonly message: string;
    /** The path of the issue, if any. */
    readonly path?: ReadonlyArray<PropertyKey | PathSegment> | undefined;
  }
  /** The path segment interface of the issue. */
  interface PathSegment {
    /** The key representing a path segment. */
    readonly key: PropertyKey;
  }
  /** The Standard types interface. */
  interface Types<Input = unknown, Output = Input> extends StandardTypedV1.Types<Input, Output> {}
  /** Infers the input type of a Standard. */
  type InferInput<Schema extends StandardTypedV1> = StandardTypedV1.InferInput<Schema>;
  /** Infers the output type of a Standard. */
  type InferOutput<Schema extends StandardTypedV1> = StandardTypedV1.InferOutput<Schema>;
}
/** The Standard JSON Schema interface. */
//#endregion
//#region node_modules/.pnpm/@deepseek-ai+schemastery@3.18.2/node_modules/@deepseek-ai/schemastery/lib/types/index.d.ts
declare const kSchema: unique symbol;
declare global {
  namespace Schemastery {
    /** Convert primitive constructors, constants, and existing schemas into a schema type. */
    type From<X> = X extends string | number | boolean ? Schema<X> : X extends Schema ? X : X extends typeof String ? Schema<string> : X extends typeof Number ? Schema<number> : X extends typeof Boolean ? Schema<boolean> : X extends typeof Function ? Schema<Function, (...args: any[]) => any> : X extends Constructor<infer S> ? Schema<S> : never;
    type TypeS1<X> = X extends Schema<infer S, unknown> ? S : never;
    type Inverse<X> = X extends Schema<any, infer Y> ? (arg: Y) => void : never;
    /** Input type accepted by a schema-like value. */
    type TypeS<X> = TypeS1<From<X>>;
    /** Output type returned by a schema-like value after validation. */
    type TypeT<X> = ReturnType<From<X>>;
    /** Resolver callback used by custom schema types registered with `Schema.extend()`. */
    type Resolve = (data: any, schema: Schema, options: Options, strict?: boolean) => [any, any?];
    /** Input type accepted by one schema in an intersection. */
    type IntersectS<X> = From<X> extends Schema<infer S, unknown> ? S : never;
    /** Output type returned by one schema in an intersection. */
    type IntersectT<X> = Inverse<From<X>> extends ((arg: infer T) => void) ? T : never;
    type TupleS<X extends readonly any[]> = X extends readonly [infer L, ...infer R] ? [TypeS<L>?, ...TupleS<R>] : any[];
    type TupleT<X extends readonly any[]> = X extends readonly [infer L, ...infer R] ? [TypeT<L>?, ...TupleT<R>] : any[];
    type ObjectS<X extends Dict> = { [K in keyof X]?: TypeS<X[K]> | null } & Dict;
    type ObjectT<X extends Dict> = { [K in keyof X]: TypeT<X[K]> } & Dict;
    type Constructor<T = any> = new (...args: any[]) => T;
    /** Static constructor and factory methods exposed by the default `Schema` export. */
    interface Static {
      <T = any>(options: Partial<Schema<T>>): Schema<T>;
      new <T = any>(options: Partial<Schema<T>>): Schema<T>;
      prototype: Schema;
      /** Validate a value against a schema node and return `[output, adaptedInput?]`. */
      resolve: Resolve;
      /** Infer a schema from a primitive value, constructor, or existing schema. */
      from<X = any>(source?: X): From<X>;
      /** Register a resolver for a custom schema `type`. */
      extend(type: string, resolve: Resolve): void;
      /** Accept any value without validation. */
      any<T = any>(): Schema<T>;
      /** Accept only nullable input. */
      never(): Schema<never>;
      /** Accept exactly one constant value. */
      const<const T>(value: T): Schema<T>;
      /** Accept strings, with optional metadata constraints added by instance methods. */
      string(): Schema<string>;
      /** Accept numbers, with optional range and step constraints. */
      number(): Schema<number>;
      /** Accept non-negative integer numbers. */
      natural(): Schema<number>;
      /** Accept a number between 0 and 1 and mark it as a slider. */
      percent(): Schema<number>;
      /** Accept booleans. */
      boolean(): Schema<boolean>;
      /** Accept `Date` instances or parse datetime strings into `Date` objects. */
      date(): Schema<string | Date, Date>;
      /** Accept `RegExp` instances or parse strings into regular expressions. */
      regExp(flag?: string): Schema<string | RegExp, RegExp>;
      /** Accept binary sources and normalize them to `ArrayBufferLike`. */
      arrayBuffer(): Schema<Binary.Source, ArrayBufferLike>;
      arrayBuffer(encoding: 'hex' | 'base64'): Schema<Binary.Source | string, ArrayBufferLike>;
      /** Accept a numeric bitset or string keys and normalize to a number. */
      bitset<K extends string>(bits: Partial<Record<K, number>>): Schema<number | readonly K[], number>;
      /** Accept functions. */
      function(): Schema<Function, (...args: any[]) => any>;
      /** Accept instances of a constructor or objects whose constructor name matches. */
      is(constructor: string): Schema;
      is<T>(constructor: Constructor<T>): Schema<T>;
      /** Accept arrays whose elements match `inner`. */
      array<X>(inner: X): Schema<TypeS<X>[], TypeT<X>[]>;
      /** Accept plain objects with values matching `inner` and optional key schema. */
      dict<X, Y extends Schema<any, string> = Schema<string>>(inner: X, sKey?: Y): Schema<Dict<TypeS<X>, TypeS<Y>>, Dict<TypeT<X>, TypeT<Y>>>;
      /** Accept tuple arrays where each index matches the corresponding schema. */
      tuple<const X extends readonly any[]>(list: X): Schema<TupleS<X>, TupleT<X>>;
      /** Accept plain objects whose declared properties match the schema dictionary. */
      object<X extends Dict>(dict: X): Schema<ObjectS<X>, ObjectT<X>>;
      /** Accept values matching at least one schema in `list`. */
      union<const X>(list: readonly X[]): Schema<TypeS<X>, TypeT<X>>;
      /** Accept values matching every schema in `list`, merging object outputs. */
      intersect<const X>(list: readonly X[]): Schema<IntersectS<X>, IntersectT<X>>;
      /** Validate with `inner`, then convert the result with `callback`. */
      transform<X, T>(inner: X, callback: (value: TypeS<X>, options: Schemastery.Options) => T, preserve?: boolean): Schema<TypeS<X>, T>;
      /** Defer construction of a recursive schema until validation or serialization. */
      lazy<X extends Schema>(callback: () => X): X;
      ValidationError: typeof ValidationError;
    }
    /** Runtime validation options shared by all schema calls. */
    interface Options {
      /** Remove invalid object properties instead of throwing when possible. */
      autofix?: boolean;
      /** Skip validation for selected values and schema nodes. */
      ignore?(data: any, schema: Schema): boolean;
      /** Path used to format nested validation errors. */
      path?: (keyof any)[];
    }
    /** UI and validation metadata attached by schema builder methods. */
    interface Meta<T = any> {
      default?: T extends {} ? Partial<T> : T;
      required?: boolean;
      disabled?: boolean;
      collapse?: boolean;
      badges?: {
        text: string;
        type: string;
      }[];
      hidden?: boolean;
      loose?: boolean;
      role?: string;
      extra?: any;
      link?: string;
      description?: string | Dict<string>;
      comment?: string;
      pattern?: {
        source: string;
        flags?: string;
      };
      max?: number;
      min?: number;
      step?: number;
    }
  }
  /** Callable schema instance that validates input and returns normalized output. */
  interface Schemastery<S = any, T = S> {
    (data?: S | null, options?: Schemastery.Options): T;
    new (data?: S | null, options?: Schemastery.Options): T;
    [kSchema]: true;
    uid: number;
    meta: Schemastery.Meta<T>;
    type: string;
    sKey?: Schema;
    inner?: Schema;
    list?: Schema[];
    dict?: Dict<Schema>;
    bits?: Dict<number>;
    callback?: Function;
    constructor?: string | Function;
    builder?: Function;
    value?: T;
    refs?: Dict<Schema>;
    preserve?: boolean;
    '~standard': StandardSchemaV1.Props;
    /** Format this schema as a compact TypeScript-like type string. */
    toString(inline?: boolean): string;
    /** Serialize this schema, preserving shared and recursive references. */
    toJSON(): Schema<S, T>;
    /** Mark nullable input as invalid unless a default supplies a fallback. */
    required(value?: boolean): Schema<S, T>;
    /** Hide this schema node from UI renderers. */
    hidden(value?: boolean): Schema<S, T>;
    /** Return the default value instead of throwing when validation fails. */
    loose(value?: boolean): Schema<S, T>;
    /** Attach a renderer role and optional role-specific metadata. */
    role(text: string, extra?: any): Schema<S, T>;
    /** Attach an external documentation link. */
    link(link: string): Schema<S, T>;
    /** Set the fallback value used for nullable input. */
    default(value: T): Schema<S, T>;
    /** Attach an auxiliary comment for documentation or form UIs. */
    comment(text: string): Schema<S, T>;
    /** Attach a localized or plain description for documentation or form UIs. */
    description(text: string): Schema<S, T>;
    /** Mark this schema node as disabled for form UIs. */
    disabled(value?: boolean): Schema<S, T>;
    /** Request collapsed rendering for nested form UIs. */
    collapse(value?: boolean): Schema<S, T>;
    /** Add a deprecated badge to this schema node. */
    deprecated(): Schema<S, T>;
    /** Add an experimental badge to this schema node. */
    experimental(): Schema<S, T>;
    /** Require strings to match a regular expression. */
    pattern(regexp: RegExp): Schema<S, T>;
    /** Set an inclusive maximum for numbers or collection lengths. */
    max(value: number): Schema<S, T>;
    /** Set an inclusive minimum for numbers or collection lengths. */
    min(value: number): Schema<S, T>;
    /** Set the numeric increment constraint. */
    step(value: number): Schema<S, T>;
    /** Add or replace an object property schema. */
    set(key: string, value: Schema): Schema<S, T>;
    /** Append a tuple, union, or intersection member schema. */
    push(value: Schema): Schema<S, T>;
    /** Remove values equal to schema defaults from normalized output. */
    simplify(value?: any): any;
    /** Return a schema clone with descriptions merged from locale messages. */
    i18n(messages: Dict): Schema<S, T>;
    /** Attach arbitrary metadata consumed by form renderers and downstream tools. */
    extra<K extends keyof Schemastery.Meta>(key: K, value: Schemastery.Meta[K]): Schema<S, T>;
  }
}
declare class ValidationError extends TypeError {
  options: Schemastery.Options;
  name: string;
  constructor(message: string, options: Schemastery.Options);
  static is(error: any): error is ValidationError;
}
type Schema<S = any, T = S> = Schemastery<S, T>;
declare const Schema: Schemastery.Static;
//#endregion
//#region src/session-router.d.ts
interface TargetSession {
  readonly sessionId: string;
  readonly taskId?: string;
}
declare class SessionRouter {
  #private;
  select(sessionId: string, taskId?: string): TargetSession;
  current(): TargetSession | undefined;
  clear(): void;
}
//#endregion
//#region src/protocol.d.ts
type BriefingImportance = 'low' | 'normal' | 'high';
interface VoiceObservedEvent {
  readonly eventId: string;
  readonly sessionId: string;
  readonly taskId?: string;
  readonly agentId?: string;
  readonly type: 'task_started' | 'agent_joined' | 'tool_started' | 'tool_completed' | 'approval_required' | 'artifact_created' | 'task_completed' | 'task_failed' | 'assistant_message';
  readonly payload: unknown;
  readonly timestamp: number;
}
interface VoiceBriefing {
  readonly briefingId: string;
  readonly sessionId: string;
  readonly voiceSessionId: string;
  readonly taskId?: string;
  readonly spokenText: string;
  readonly importance: BriefingImportance;
  readonly needsUserAction: boolean;
  readonly sourceEventIds: readonly string[];
  readonly createdAt: number;
}
//#endregion
//#region src/onboarding-voice-bridge.d.ts
interface OnboardingIdentity {
  readonly tenantId: string;
  readonly userId: string;
}
interface OnboardingQuestion {
  readonly key: string;
  readonly label: string;
  readonly prompt: string;
}
interface OnboardingInterview {
  readonly status: 'pending' | 'active' | 'completed' | 'skipped';
  readonly conversationId: string | null;
  readonly currentField: string | null;
  readonly nextQuestion: OnboardingQuestion | null;
}
interface OnboardingBridgeOptions {
  readonly baseUrl?: string;
  readonly secret?: string;
  /** Desktop-only, capability-bound route to the platform API. */
  readonly brokerEndpoint?: string;
  readonly brokerToken?: string;
  readonly fetcher?: typeof fetch;
  readonly now?: () => number;
}
interface OnboardingTranscriptResult {
  readonly handled: boolean;
  readonly interview?: OnboardingInterview;
  readonly spokenText?: string;
  readonly error?: 'unavailable' | 'not_onboarding';
}
/** Server-side bridge for the dedicated "访谈引导" conversation. */
declare class OnboardingVoiceBridge {
  #private;
  constructor(options?: OnboardingBridgeOptions);
  status(identity: OnboardingIdentity): Promise<OnboardingInterview | undefined>;
  /** A safe, local-only category for the renderer; never expose upstream details. */
  get failure(): 'authentication_required' | 'unavailable' | undefined;
  /** Create or resume the tenant's one durable interview after an explicit UI action. */
  start(identity: OnboardingIdentity): Promise<OnboardingInterview | undefined>;
  answer(identity: OnboardingIdentity, field: string, value: string): Promise<OnboardingInterview | undefined>;
  skip(identity: OnboardingIdentity, field: string): Promise<OnboardingInterview | undefined>;
  handleTranscript(identity: OnboardingIdentity, text: string, transcriptId: string, isOnboarding: boolean): Promise<OnboardingTranscriptResult>;
  clear(transcriptId?: string): void;
}
//#endregion
//#region src/client-state.d.ts
interface VoiceErrorSnapshot {
  readonly active: true;
  readonly phase: 'error';
  readonly sessionId?: string;
  readonly status: string;
}
interface VoiceMinimizableSnapshot {
  readonly active: boolean;
  readonly minimized?: boolean;
}
/** Keep the full-screen voice surface mounted so a failed connection is recoverable. */
declare function createVoiceErrorSnapshot(status: string, sessionId?: string): VoiceErrorSnapshot;
/** Transport status changes must not override the user's overlay choice. */
declare function preserveVoiceMinimized<T extends VoiceMinimizableSnapshot>(next: T, current: VoiceMinimizableSnapshot): T & {
  readonly minimized?: boolean;
};
//#endregion
//#region src/briefing-engine.d.ts
declare function summarizeEvents(events: readonly VoiceObservedEvent[], sessionId: string, voiceSessionId: string, now?: number): VoiceBriefing | undefined;
//#endregion
//#region src/speech-policy.d.ts
declare function shouldSpeak(briefing: VoiceBriefing, mode: 'concise' | 'normal' | 'detailed'): boolean;
/**
 * The browser owns ordinary turn replies because it can associate them with
 * one voice command.  The host only interrupts for urgent state changes.
 */
declare function shouldUseHostSpeech(briefing: Pick<VoiceBriefing, 'importance' | 'needsUserAction'>): boolean;
//#endregion
//#region src/session-context-snapshot.d.ts
interface SessionMessage {
  readonly role?: unknown;
  readonly content?: unknown;
}
declare function buildSessionVoiceSnapshot(messages: readonly SessionMessage[], status: 'idle' | 'running' | undefined): string;
//#endregion
//#region src/session-turn-tracker.d.ts
interface SessionEvent {
  readonly type: string;
  readonly data?: unknown;
}
interface TurnResult {
  readonly ok: boolean;
  readonly text?: string;
  readonly cancelled?: boolean;
  readonly error?: string;
}
interface SessionTurnCallbacks {
  readonly onTurnStart?: (turn: string) => void;
  readonly onTool?: (turn: string) => void;
  readonly onTextDelta?: (turn: string, text: string) => void;
  readonly onTurnEnd?: (turn: string, result: TurnResult) => void;
}
interface SessionTurnTrackerOptions {
  readonly trackAllUserTurns?: boolean;
}
declare class SessionTurnTracker {
  #private;
  readonly callbacks: SessionTurnCallbacks;
  constructor(callbacks: SessionTurnCallbacks, options?: SessionTurnTrackerOptions);
  expectRpc(rpcId: string): void;
  expectMessageId(messageId: string): void;
  handle(event: SessionEvent): void;
}
declare class SpokenSummaryStream {
  #private;
  constructor(emit: (text: string) => void);
  push(delta: string): void;
  finish(finalText: string): void;
}
//#endregion
//#region src/provider-speech-state.d.ts
declare class ProviderSpeechState {
  #private;
  get active(): boolean;
  get hostActive(): boolean;
  /** Native realtime-agent audio is the primary path and is always forwarded. */
  get shouldForwardAudio(): boolean;
  start(): void;
  interrupt(): void;
  startContext(): boolean;
  /** Returns true only for the first PCM frame of a native provider reply. */
  beginNativeAudio(): boolean;
  completeNative(event: number): boolean;
  completeContext(event: number): boolean;
  /** Event 350 acknowledges a ChatTTS request; PCM can still follow it. */
  acknowledge(payload: unknown): boolean;
  /** Event 359 is the provider's actual TTS-complete boundary. */
  complete(event: number): boolean;
}
declare function shouldForwardProviderAudio(audio: Buffer | undefined, speech: ProviderSpeechState, _userSpeaking: boolean): boolean;
//#endregion
//#region src/quiet-window-scheduler.d.ts
declare class QuietWindowScheduler {
  #private;
  readonly delayMs: number;
  constructor(delayMs: number);
  schedule(callback: () => void): void;
  cancel(): void;
}
//#endregion
//#region src/speech-echo.d.ts
declare function isLikelySpeechEcho(transcript: string, spoken: string): boolean;
declare class SpeechEchoHistory {
  #private;
  constructor(ttlMs?: number);
  record(text: string, now?: number): void;
  isEcho(transcript: string, now?: number): boolean;
  clear(): void;
}
//#endregion
//#region src/playback-input-gate.d.ts
/**
 * Prevent speaker output from re-entering the realtime provider as microphone
 * audio. Browser echo cancellation is only best-effort, so this is the final
 * client-side isolation boundary for speakerphone use.
 */
declare class PlaybackInputGate {
  #private;
  readonly cooldownMs: number;
  constructor(cooldownMs?: number);
  startPlayback(_now?: number): void;
  finishPlayback(now?: number): void;
  release(): void;
  acceptsMicrophone(now?: number): boolean;
}
//#endregion
//#region src/session-event-bridge.d.ts
interface MuxFrame {
  readonly type?: string;
  readonly sessionId?: string;
  readonly event?: SessionEvent;
}
interface EventsApi {
  mux(input: Record<string, never>, signal: AbortSignal): AsyncIterable<{
    readonly payload: MuxFrame;
  }>;
}
interface SessionObservation {
  readonly ready: Promise<void>;
  readonly expectRpc: (rpcId: string) => void;
  readonly expectMessageId: (messageId: string) => void;
  readonly dispose: () => void;
}
interface SessionObservationOptions {
  readonly trackAllUserTurns?: boolean;
}
interface SessionEventBridgeOptions {
  readonly subscriptionTimeoutMs?: number;
}
declare class SessionEventBridge {
  #private;
  readonly events: EventsApi;
  constructor(events: EventsApi, options?: SessionEventBridgeOptions);
  observe(sessionId: string, callbacks: SessionTurnCallbacks, options?: SessionObservationOptions): SessionObservation;
  dispose(): void;
}
//#endregion
//#region src/volcengine-proxy.d.ts
declare class SessionSpeechRegistry {
  #private;
  bind(sessionId: string, target: (text: string) => void): () => void;
  speak(sessionId: string, text: string): boolean;
  clear(sessionId?: string): void;
}
declare function readTranscriptPayload(payload: unknown): string;
//#endregion
//#region src/pcm-frame-buffer.d.ts
/** Splits browser AudioContext chunks into the provider's 20ms PCM frames. */
declare class PcmFrameBuffer {
  #private;
  push(chunk: ArrayBuffer): Uint8Array[];
  clear(): void;
}
//#endregion
//#region src/audio-resampler.d.ts
/**
 * Streaming microphone resampler to the provider's fixed 16 kHz input rate.
 *
 * The Volcengine realtime dialogue expects 16 kHz / mono / signed 16-bit PCM
 * frames of 20 ms. Desktop browsers honor the AudioContext({ sampleRate:
 * 16000 }) hint, but iOS Safari and several Android browsers ignore it and
 * always run capture at the device rate (44.1/48 kHz). Sending those samples
 * unmodified makes the assistant hear slowed, unusable audio.
 *
 * This class keeps a continuous input-sample timeline across audio callback
 * chunks and linearly interpolates between neighbouring samples, so chunk
 * boundaries neither pop nor lose signal. When the capture rate is already
 * 16 kHz callers can skip it entirely (pass-through).
 */
/** Fixed input rate the realtime provider expects. */
declare const VOICE_INPUT_RATE = 16000;
/** Bounded drop-in for a Float32Array-like chunk of mono samples. */
type SampleChunk = ArrayLike<number>;
declare class AudioRateResampler {
  #private;
  constructor(inputRate: number);
  get inputRate(): number;
  /** Resample one capture chunk to 16 kHz mono. */
  process(chunk: SampleChunk): Float32Array;
  reset(): void;
}
//#endregion
//#region src/transcript-command-queue.d.ts
declare class TranscriptCommandQueue<TReceipt = void> {
  #private;
  readonly submit: (text: string) => Promise<TReceipt>;
  constructor(submit: (text: string) => Promise<TReceipt>);
  enqueue(text: string): Promise<TReceipt>;
  close(): void;
}
//#endregion
//#region src/handoff-controller.d.ts
type VoiceAgentStatus = 'idle' | 'running' | undefined;
type VoiceHandoffAction = 'none' | 'followup' | 'steer';
interface VoiceHandoffDecision {
  readonly action: VoiceHandoffAction;
  readonly reason: string;
  readonly prompt?: string;
}
interface VoiceHandoffInput {
  readonly sessionId: string;
  readonly transcriptId: string;
  readonly text: string;
  readonly agentStatus: VoiceAgentStatus;
}
interface VoiceHandoffDelivery {
  readonly sessionId: string;
  readonly transcriptId: string;
  readonly text: string;
  readonly delivery: 'followup' | 'steer';
}
interface VoiceHandoffResult {
  readonly action: VoiceHandoffAction;
  readonly delivered: boolean;
  readonly delivery?: 'followup' | 'steer';
  readonly messageId?: string;
}
interface VoiceHandoffControllerOptions {
  readonly decide: (input: VoiceHandoffInput) => Promise<VoiceHandoffDecision>;
  readonly deliver: (input: VoiceHandoffDelivery) => Promise<{
    readonly accepted: true;
    readonly messageId: string;
    readonly delivery: 'followup' | 'steer';
  }>;
}
/**
 * Keeps realtime conversation independent from the DSH task loop. Only an
 * explicit handoff decision can create a message in the bound DSH session.
 */
declare class VoiceHandoffController {
  #private;
  constructor(options: VoiceHandoffControllerOptions);
  handle(input: VoiceHandoffInput): Promise<VoiceHandoffResult>;
}
declare function parseVoiceHandoffDecision(raw: string): VoiceHandoffDecision;
/**
 * Handles commands whose intent is unambiguous without competing with the
 * busy DSH model. Ambiguous speech remains in the realtime conversation and
 * may be classified by the auxiliary model.
 */
declare function classifyObviousVoiceHandoff(text: string, status: VoiceAgentStatus): VoiceHandoffDecision | undefined;
declare const VOICE_HANDOFF_SYSTEM_PROMPT: string;
//#endregion
//#region src/voice-command.d.ts
type VoiceDelivery = 'followup' | 'steer';
interface VoiceMessageSource {
  readonly kind: 'user';
  readonly input: 'voice';
  readonly transcriptId: string;
}
interface VoiceUserMessage {
  readonly id: string;
  readonly role: 'user';
  readonly content: readonly [{
    readonly type: 'text';
    readonly text: string;
  }];
  readonly source: VoiceMessageSource;
}
interface VoiceCommandReceipt {
  readonly accepted: true;
  readonly messageId: string;
  readonly delivery: VoiceDelivery;
}
interface AgentInbox {
  readonly status?: 'idle' | 'running';
  followup(message: VoiceUserMessage): void;
  steer(message: VoiceUserMessage): void;
}
/** Builds a normal DSH user message, with only a durable voice channel marker added. */
declare function createVoiceUserMessage(text: string, transcriptId: string): VoiceUserMessage;
/** Interruptions and corrections enter at the nearest safe step; other speech queues another turn. */
declare function chooseVoiceDelivery(text: string, agentStatus?: AgentInbox['status']): VoiceDelivery;
declare function submitVoiceCommand(agent: AgentInbox, input: {
  readonly text: string;
  readonly transcriptId: string;
  readonly delivery?: VoiceDelivery;
}): VoiceCommandReceipt;
//#endregion
//#region src/voice-project-query.d.ts
/**
 * Identifies voice questions whose answer must come from the local Codex task
 * board. These are read-only project queries, not work-dispatch requests.
 */
declare function isVoiceProjectStatusQuery(text: string): boolean;
//#endregion
//#region src/volcengine-protocol.d.ts
interface VolcengineFrame {
  readonly messageType: number;
  readonly flags: number;
  readonly event?: number;
  readonly sessionId?: string;
  readonly payload: unknown;
  readonly audio?: Buffer;
  readonly errorCode?: number;
}
/**
 * Keep provider diagnostics on the server and never include credential-like
 * fields. This is intentionally bounded because a provider payload is remote
 * input and may be unexpectedly large.
 */
declare function describeProviderError(errorCode: number, payload: unknown): string;
declare function createStartConnectionFrame(): Buffer;
declare function createStartSessionFrame(sessionId: string, config: Record<string, unknown>): Buffer;
declare function createAudioFrame(sessionId: string, audio: Uint8Array): Buffer;
declare function createTextFrame(sessionId: string, text: string): Buffer;
declare function createChatRagTextFrame(sessionId: string, externalRag: string): Buffer;
declare function createChatTtsTextFrames(sessionId: string, content: string): readonly [Buffer, Buffer];
declare function parseVolcengineFrame(input: Uint8Array): VolcengineFrame;
declare function defaultSessionConfig(initialContext?: string): Record<string, unknown>;
//#endregion
//#region src/client-base.d.ts
interface VoiceClientLocation {
  readonly href?: string;
  readonly origin?: string;
  readonly pathname?: string;
}
interface VoiceBrowserReadiness {
  readonly ready: boolean;
  readonly reason?: 'insecure_context' | 'microphone_unsupported' | 'audio_unsupported';
}
/**
 * Browser capabilities that must be known before asking for microphone access.
 * localhost is treated as a secure development origin by modern browsers.
 */
declare function getVoiceBrowserReadiness(input?: {
  readonly isSecureContext?: boolean;
  readonly hostname?: string;
  readonly hasGetUserMedia?: boolean;
  readonly hasAudioContext?: boolean;
}): VoiceBrowserReadiness;
declare function resolveVoiceBasePath(input?: {
  readonly baseHref?: string;
  readonly location?: VoiceClientLocation;
}): string;
declare function resolveVoiceHttpUrl(path: string, input?: {
  readonly baseHref?: string;
  readonly location?: VoiceClientLocation;
}): string;
declare function resolveVoiceWebSocketUrl(path: string, input?: {
  readonly baseHref?: string;
  readonly location?: VoiceClientLocation;
}): string;
//#endregion
//#region src/voice-supervisor.d.ts
interface VoiceAgentProfile {
  name: string;
  displayName: string;
  soul: string;
  speakingStyle: 'concise' | 'warm' | 'professional';
  briefingMode: 'concise' | 'normal' | 'detailed';
  wakeName?: string;
  version: number;
  updatedAt: string;
}
interface SessionSummary {
  sessionId: string;
  workspace?: string;
  title?: string;
  status: string;
  recentContext: string;
  updatedAt: number;
}
type RouteDecision = {
  action: 'direct';
  sessionId: string;
  reason: string;
} | {
  action: 'confirm';
  candidates: SessionSummary[];
  reason: string;
} | {
  action: 'none';
  reason: string;
};
interface AgentMessage {
  role: 'user';
  content: readonly {
    type: 'text';
    text: string;
  }[];
  source: {
    kind: string;
    plugin: string;
  };
}
interface AgentLike {
  id?: string;
  status?: string;
  session?: {
    deriveMessages?: () => readonly {
      role?: unknown;
      content?: unknown;
    }[];
    header?: {
      cwd?: string;
      createdAt?: number;
      parentSession?: string;
      origin?: string;
    };
  };
  followup?: (message: AgentMessage) => void;
}
interface Agents {
  list?: () => readonly AgentLike[];
  get?: (id: string) => AgentLike | undefined;
}
interface Persistence {
  list?: () => Promise<readonly {
    id: string;
    cwd?: string;
    createdAt?: number;
    parentSession?: string;
    origin?: string;
  }[]>;
  load?: (id: string) => Promise<{
    events?: readonly unknown[];
  }>;
  inspect?: (id: string) => Promise<{
    events?: readonly unknown[];
  }>;
}
interface WorkspaceRegistry {
  list?: () => readonly {
    title?: string;
    path?: string;
    sessionIds?: readonly string[];
  }[];
  archivedSessionIds?: readonly string[];
}
interface Identity {
  resolve?: (sessionId: string, request?: unknown) => Promise<{
    tenantId: string;
    userId?: string;
  } | undefined>;
}
declare class VoiceSupervisor {
  #private;
  constructor(options: {
    agents?: Agents;
    persistence?: Persistence;
    workspaces?: WorkspaceRegistry;
    identity?: Identity;
    root?: string;
  });
  getProfile(tenantId: string): Promise<VoiceAgentProfile>;
  updateProfile(tenantId: string, patch: Partial<Pick<VoiceAgentProfile, 'name' | 'displayName' | 'soul' | 'speakingStyle' | 'briefingMode' | 'wakeName'>>): Promise<VoiceAgentProfile>;
  listSessions(tenantId: string): Promise<SessionSummary[]>;
  inspectSession(tenantId: string, sessionId: string): Promise<SessionSummary | undefined>;
  routeCommand(tenantId: string, text: string): Promise<RouteDecision>;
  sendToSession(tenantId: string, sessionId: string, text: string, source?: string): Promise<{
    sessionId: string;
    accepted: boolean;
  }>;
  authorize(sessionId: string, request?: unknown): Promise<{
    tenantId: string;
    userId?: string;
  } | undefined>;
  private profilePath;
}
/**
 * Give the realtime provider a compact tenant-wide index, not raw transcripts.
 * The provider limits system context, so each conversation gets one short line
 * and only the newest work includes its most useful recent progress.
 */
declare function buildGlobalSessionVoiceSnapshot(sessions: readonly SessionSummary[], currentSessionId?: string): string;
//#endregion
//#region src/voice-question-controller.d.ts
interface VoiceQuestionOption {
  readonly label: string;
}
interface VoiceQuestion {
  readonly id: string;
  readonly question: string;
  readonly options: readonly VoiceQuestionOption[];
}
interface PendingVoiceQuestion {
  readonly key: string;
  readonly sessionId: string;
  readonly questions: readonly VoiceQuestion[];
  readonly answer: (value: {
    readonly answers: readonly {
      readonly id: string;
      readonly selected: readonly string[];
    }[];
  }) => Promise<void>;
}
interface VoiceQuestionResult {
  readonly handled: boolean;
  readonly submitted: boolean;
  readonly spokenText?: string;
}
/** Holds one pending structured question flow for spoken option selection. */
declare class VoiceQuestionController {
  #private;
  attach(pending: PendingVoiceQuestion): string;
  handle(text: string): Promise<VoiceQuestionResult>;
}
//#endregion
//#region src/voice-session-command.d.ts
interface VoiceSessionCommand {
  readonly action: 'create-session';
}
/** Identifies an explicit request to open a new DSH conversation, not a work task. */
declare function classifyVoiceSessionCommand(text: string): VoiceSessionCommand | undefined;
//#endregion
//#region src/index.d.ts
declare const name = "opc-realtime-voice";
declare const inject: string[];
interface Config {
  readonly voiceProvider: 'volcengine';
  readonly briefingMode: 'concise' | 'normal' | 'detailed';
  readonly autoStart: boolean;
  readonly maxConcurrentVoiceSessions: number;
  readonly runtimeMode: 'production' | 'local';
  readonly apiBaseUrl?: string;
}
declare const Config: Schema<Config>;
/** Resolve the control-plane URL without ever silently using a local server in production. */
declare function resolveVoiceServerBaseUrl(config?: Partial<Pick<Config, 'runtimeMode' | 'apiBaseUrl'>>): string;
/** A Harness interview ID is not a desktop DSH session ID. Match it only after
 * resolving the signed desktop identity and checking the tenant's active interview. */
declare function isActiveOnboardingConversation(sessionId: string, interview: OnboardingInterview | undefined): boolean;
declare function macOsLoginKeychainArgs(username?: string, homeDirectory?: string): string[];
/**
 * Resolve the Volcengine API key on the host only. Order: DSH credentials
 * store (when present) -> process environment -> shared macOS Keychain.
 * Server deployments on Linux have no Keychain, so the platform injects the
 * key through the runtime environment; the env fallback must therefore also
 * apply when a credentials store exists but has no entry for the key.
 */
declare function resolveVolcengineApiKey(input: {
  readonly store?: () => Promise<{
    value: string;
  } | undefined>;
  readonly envValue?: string;
  readonly keychain: () => Promise<string | undefined>;
}): Promise<string | undefined>;
declare class RealtimeVoiceService {
  #private;
  readonly router: SessionRouter;
  constructor(ctx: Context, config: Config);
  start(): void;
  stop(): void;
  open(sessionId: string): {
    voiceSessionId: string;
    sessionId: string;
  };
  close(): void;
  observe(event: VoiceObservedEvent): VoiceBriefing | undefined;
  status(): Record<string, unknown>;
}
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { AudioRateResampler, Config, OnboardingVoiceBridge, PcmFrameBuffer, PlaybackInputGate, ProviderSpeechState, QuietWindowScheduler, RealtimeVoiceService, SessionEventBridge, SessionRouter, SessionSpeechRegistry, SessionTurnTracker, SpeechEchoHistory, SpokenSummaryStream, TranscriptCommandQueue, VOICE_HANDOFF_SYSTEM_PROMPT, VOICE_INPUT_RATE, VoiceHandoffController, VoiceQuestionController, VoiceSupervisor, apply, buildGlobalSessionVoiceSnapshot, buildSessionVoiceSnapshot, chooseVoiceDelivery, classifyObviousVoiceHandoff, classifyVoiceSessionCommand, createAudioFrame, createChatRagTextFrame, createChatTtsTextFrames, createStartConnectionFrame, createStartSessionFrame, createTextFrame, createVoiceErrorSnapshot, createVoiceUserMessage, defaultSessionConfig, describeProviderError, getVoiceBrowserReadiness, inject, isActiveOnboardingConversation, isLikelySpeechEcho, isVoiceProjectStatusQuery, macOsLoginKeychainArgs, name, parseVoiceHandoffDecision, parseVolcengineFrame, preserveVoiceMinimized, readTranscriptPayload, resolveVoiceBasePath, resolveVoiceHttpUrl, resolveVoiceServerBaseUrl, resolveVoiceWebSocketUrl, resolveVolcengineApiKey, shouldForwardProviderAudio, shouldSpeak, shouldUseHostSpeech, submitVoiceCommand, summarizeEvents };
//# sourceMappingURL=index.d.ts.map