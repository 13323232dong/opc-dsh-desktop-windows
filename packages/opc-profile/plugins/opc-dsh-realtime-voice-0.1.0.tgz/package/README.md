# @opc/dsh-realtime-voice

DSH 原生 Cordis 全双工语音插件。

安装插件并配置火山引擎凭证后，DSH 会提供：

- 当前对话的麦克风按钮。
- Siri 风格语音球。
- 独立实时语音 Agent 与当前 Session 的受控任务交接。
- Session 事件口头摘要。
- 语音转写和摘要历史扩展点。

插件卸载时会移除前端按钮、语音球、路由、事件监听和服务连接；普通 DSH 文字对话不受影响。

## 使用

在运行 DSH 的环境中提供以下任一组凭证（凭证只在主机侧读取）：

```bash
export VOLCENGINE_API_KEY='...'
# 或旧版鉴权：
export VOLCENGINE_APP_ID='...'
export VOLCENGINE_ACCESS_KEY='...'
```

启用插件后，打开任意 DSH 对话，点击输入框旁的麦克风即可进入语音模式；语音球只负责显示状态和入口提示。浏览器采集 16kHz/16-bit/单声道 PCM，每 20ms 发送一帧，服务端把豆包返回的 24kHz PCM 播放到当前页面的输出设备。

语音 Agent 始终独立运行，普通聊天和进度询问不会进入 DSH Agent Loop。只有明确的工作请求、纠正或停止指令才会交接给打开语音模式时绑定的当前 Session；后台繁忙不会阻塞语音 Agent 继续听和说。

DSH 的进度和最终结果通过豆包 `external_rag` 上下文回到语音 Agent，由语音 Agent 组织成自然口语。插件不会把代码、JSON 或每条工具日志逐句朗读，也不会向 DSH Session 写入 `voice/item` 等未知事件。最近 200 条语音侧记录暂存在插件自己的内存日志中，DSH 的任务指令仍以标准用户消息进入原 Session。

当前实现包含豆包二进制协议 adapter、WebSocket 主机代理、浏览器收音/播放、独立语音回复、任务 handoff、Session 事件摘要和卸载清理。火山引擎全双工接口不提供 Codex Realtime 的原生 `background_agent` 工具调用，因此插件对明显工作指令使用本地快速策略，对含糊表达使用带超时的辅助分类；两者都不会暂停实时语音连接。
