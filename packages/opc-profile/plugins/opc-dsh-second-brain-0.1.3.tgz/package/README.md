# @opc/dsh-second-brain

伟东 OPC 桌面端的本地第二大脑插件。它在系统 Documents 目录创建用户拥有的 Markdown 知识库，并提供幂等初始化、本地资料导入、SQLite 正文索引、搜索及 Obsidian 打开能力。

默认关闭写盘能力。仅当桌面 profile 设置 `OPC_DESKTOP_MODE=true` 时启用；网页或服务端 profile 的状态接口返回 `supported: false`，其他本地操作拒绝执行。

客户端调用 POST 本地路由时必须携带 `x-opc-local-action: true`，避免外部网页触发本机写盘操作。

知识正文和索引均保存在本机，不上传 OPC 服务端。索引只是发现层，回答前仍需读取来源文件。
