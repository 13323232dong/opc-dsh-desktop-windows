import { type SecondBrainSearchResponse, type SecondBrainStatus } from './types.js';
export interface ResolvePathOptions {
    readonly platform?: NodeJS.Platform;
    readonly homeDir?: string;
    readonly localAppData?: string;
}
export interface SecondBrainServiceOptions extends ResolvePathOptions {
    readonly desktopMode: boolean;
    readonly documentsDir?: string;
    readonly stateDir?: string;
    readonly runCommand?: (command: string, args: readonly string[]) => Promise<void>;
    readonly obsidianAvailable?: () => Promise<boolean>;
    readonly obsidianConfigPath?: string;
}
export declare function resolveSecondBrainPaths(options?: ResolvePathOptions): {
    rootPath: string;
    statePath: string;
};
export declare class SecondBrainService {
    readonly rootPath: string;
    readonly statePath: string;
    readonly documentsDir: string;
    readonly platform: NodeJS.Platform;
    private readonly desktopMode;
    private readonly runCommand;
    private readonly checkObsidianAvailable;
    private readonly obsidianConfigPath;
    constructor(options: SecondBrainServiceOptions);
    private requireDesktop;
    private manifestValid;
    private storedState;
    private writeState;
    private detectObsidian;
    status(): Promise<SecondBrainStatus>;
    create(): Promise<SecondBrainStatus & {
        readonly result: 'created' | 'already_exists';
    }>;
    linkExisting(input: {
        readonly rootPath: string;
    }): Promise<SecondBrainStatus>;
    private requireVault;
    rebuildIndex(): Promise<SecondBrainStatus>;
    search(input: {
        readonly query: string;
        readonly limit?: number;
    }): Promise<SecondBrainSearchResponse>;
    ingest(input: {
        readonly filePath: string;
    }): Promise<SecondBrainStatus & {
        readonly importedPath: string;
    }>;
    captureCandidate(input: {
        readonly title: string;
        readonly content: string;
        readonly candidateType?: 'wiki' | 'skill';
        readonly confirmed?: boolean;
    }): Promise<SecondBrainStatus & {
        readonly candidatePath: string;
    }>;
    open(): Promise<SecondBrainStatus & {
        readonly openedWith: 'file-manager';
    }>;
    openObsidian(): Promise<SecondBrainStatus & {
        readonly openedWith: 'obsidian';
    }>;
    private registerObsidianVault;
}
