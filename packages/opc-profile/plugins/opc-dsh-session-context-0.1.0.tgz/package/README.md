# @opc/dsh-session-context

Independent DeepSeek Harness plugin for copying the current native Session ID and reading a bounded, redacted snapshot of another Session in the same workspace.

The model tool `session_context_read` is read-only. It does not grant messaging, continuation, task mutation, or Agent Teams access to the target Session.

## Tool input

- `session_id`: target native DSH Session ID.
- `cursor`: optional opaque continuation cursor.
- `limit`: optional message count, default 12 and maximum 50.

The returned surface uses live Session data when available and persisted history otherwise. Authorization fails closed unless both caller and target expose the same normalized workspace path.
