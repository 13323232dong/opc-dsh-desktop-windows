export interface SessionContextMessage {
    readonly role: 'user' | 'assistant' | 'tool';
    readonly content: string;
}
export interface SessionContextTask {
    readonly kind: 'current' | 'last';
    readonly content: string;
}
export interface SessionContextSnapshot {
    readonly sessionId: string;
    readonly availability: 'live' | 'historical';
    readonly running: boolean;
    readonly latestTask: SessionContextTask | null;
    readonly messages: readonly SessionContextMessage[];
    readonly nextCursor?: string;
    readonly truncated: boolean;
}
export interface SessionContextReadRequest {
    readonly session_id: string;
    readonly cursor?: string;
    readonly limit?: number;
}
