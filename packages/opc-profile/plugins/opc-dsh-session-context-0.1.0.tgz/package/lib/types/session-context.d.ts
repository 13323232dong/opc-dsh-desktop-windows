import type { SessionContextReadRequest, SessionContextSnapshot } from './types.ts';
interface SurfaceHeaderLike {
    readonly id: unknown;
    readonly cwd?: string;
}
interface SurfaceEventLike {
    readonly type: string;
    readonly seq: number;
    readonly data: unknown;
}
interface SurfaceSnapshotLike {
    readonly session: SurfaceHeaderLike;
    readonly capturedThroughSeq: number | null;
    readonly events: readonly SurfaceEventLike[];
}
export interface SessionContextDependencies {
    readonly readSurface: (sessionId: string) => Promise<SurfaceSnapshotLike>;
    readonly isLive: (sessionId: string) => boolean;
    readonly isRunning: (sessionId: string) => boolean;
    readonly maxChars?: number;
}
export interface SessionContextCaller {
    readonly callerSessionId: string;
    readonly callerCwd?: string;
}
export interface NormalizedSessionContextRequest {
    readonly sessionId: string;
    readonly cursor?: string;
    readonly limit: number;
}
export interface SessionContextCursor {
    readonly sessionId: string;
    readonly beforeSeq: number;
    readonly beforeChar?: number;
}
export declare function normalizeSessionContextRequest(request: SessionContextReadRequest): NormalizedSessionContextRequest;
export declare function encodeSessionContextCursor(cursor: SessionContextCursor): string;
export declare function decodeSessionContextCursor(value: string, sessionId: string): SessionContextCursor;
export declare function redactSensitiveText(value: string): string;
export declare function readSessionContext(dependencies: SessionContextDependencies, caller: SessionContextCaller, rawRequest: SessionContextReadRequest): Promise<SessionContextSnapshot>;
export {};
