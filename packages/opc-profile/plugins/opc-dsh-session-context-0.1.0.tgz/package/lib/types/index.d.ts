import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "opc-session-context";
export declare const inject: string[];
export interface Config {
    readonly maxChars?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export type { SessionContextSnapshot } from './types.ts';
