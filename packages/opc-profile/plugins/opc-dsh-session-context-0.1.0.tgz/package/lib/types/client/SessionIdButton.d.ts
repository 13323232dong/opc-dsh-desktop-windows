export interface SessionIdButtonProps {
    readonly sessionId?: string;
}
export declare function SessionIdButton({ sessionId }: SessionIdButtonProps): import("react").JSX.Element;
