import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { CustomerService } from '../src/core.mjs';

const wait = async (predicate) => { for(let n=0;n<100;n++){ if(predicate()) return; await new Promise(r=>setTimeout(r,5)); } assert.fail('worker timeout'); };
function fixture(t, options={}) {
 const stateDir=mkdtempSync(join(tmpdir(),'customer-test-')); t.after(()=>rmSync(stateDir,{recursive:true,force:true}));
 let messages=[], conversations=[]; const sends=[],drafts=[];
 const adapter={status:async()=>({accountId:'account-a',ready:true}),findContact:async name=>({id:name,name}),readChat:async c=>({accountId:'account-a',contactId:c.id,title:c.name,messages}),listChats:async()=>({accountId:'account-a',chats:conversations}),draft:async(c,text)=>{drafts.push({contact:c,text});return {status:'drafted',evidence:{kind:'input_draft'}}},send:async(c,text,{onStage})=>{sends.push(text); await onStage('sending'); return {status:'sent',evidence:{messageId:String(sends.length)}}},...options.adapter};
 const service=new CustomerService({stateDir,replyGenerator:async()=> '自动回复',debounceMs:0,...options,adapter}); t.after(()=>service.stop());
 return {service,stateDir,adapter,sends,drafts,setMessages:m=>{messages=m;},setChats:c=>{conversations=c;}};
}
const contact={id:'contact-1',name:'测试联系人'};
test('learned relationship reaches preview generation and deletion invalidates pending draft',async t=>{
 let release,input;
 const f=fixture(t,{replyGenerator:async args=>{input=args;return new Promise(resolve=>{release=resolve;});},adapter:{readHistory:async c=>({accountId:'account-a',contactId:c.id,messages:[{id:'mine',direction:'outgoing',text:'好呀哈哈'}],coverage:{pagesRead:1,complete:false}})}});
 await f.service.learnStyle({contact:'甲',relationship:'friend',pages:1});
 f.setChats([{id:'甲',title:'甲',preview:'你好',hasUnread:true,signature:'1'}]);f.setMessages([{id:'new',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});const working=f.service.tick();await wait(()=>!!release);
 assert.equal(input.contactStyle.relationship,'friend');assert.equal(input.contactStyle.examples[0].text,'好呀哈哈');
 await f.service.styleAction('delete',{contactId:'甲'});release('好呀');await working;
 assert.equal(f.drafts.length,0);assert.equal(f.service.state.globalPreview.events[0].failureCode,'CONTACT_STYLE_CHANGED');
});
test('style read APIs require current verified account and cannot accept caller account',async t=>{
 const f=fixture(t,{adapter:{status:async()=>({ready:false,failureCode:'WECHAT_ACCOUNT_UNVERIFIED'})}});
 await assert.rejects(()=>f.service.styleAction('list',{}),/WECHAT_ACCOUNT_UNVERIFIED/);
});
test('style list verifies fresh identity rather than trusting passive account cache',async t=>{
 let verified=false;
 const f=fixture(t,{adapter:{peekStatus:async()=>({ready:true,accountId:'old'}),status:async options=>{assert.equal(options.fresh,true);verified=true;return {ready:true,accountId:'new'};}}});
 f.service.styles.learn({accountId:'old',contact,messages:[]});
 assert.deepEqual(await f.service.styleAction('list',{accountId:'old'}),[]);assert.equal(verified,true);
});
test('a queued generated reply cannot send after its learned style is deleted',async t=>{
 const f=fixture(t);const profile=f.service.styles.learn({accountId:'account-a',contact,messages:[]});
 f.service.stopped=true;
 const task=await f.service.send({contact,text:'old style',requestId:'style-old',styleRevision:profile.revision});
 await f.service.styleAction('delete',{contactId:contact.id});f.service.stopped=false;f.service.kick();
 await wait(()=>f.service.tasks().find(t=>t.id===task.id)?.status==='failed');
 assert.equal(f.service.tasks()[0].failureCode,'CONTACT_STYLE_CHANGED');assert.equal(f.sends.length,0);
});
test('global monitor excludes system and official chats without matching message text',async t=>{
 const f=fixture(t);const row=title=>({id:title,title,preview:'hello',hasUnread:true,signature:'1'});
 f.setChats(['公众号','服务号','订阅号消息','文件传输助手','File Transfer','filehelper','普通朋友'].map(row).concat([{...row('品牌服务'),chatType:'service_account'},{...row('每日资讯'),chatType:'official_account'},{...row('小王'),preview:'文件传输助手在哪里'}]));
 const state=await f.service.globalPreview({enabled:true});
 assert.deepEqual(state.events.map(e=>e.title),['普通朋友','小王']);
});
test('persisted excluded chat is skipped before opening or generating a reply',async t=>{
 const f=fixture(t,{adapter:{readChat:async()=>assert.fail('excluded chat opened')}});
 await f.service.globalPreview({enabled:true});
 f.service.save({...f.service.state,globalPreview:{...f.service.state.globalPreview,events:[{id:'old',chatId:'file',title:'文件传输助手',status:'queued',key:'old'}]}});
 await f.service.tick();assert.equal(f.service.state.globalPreview.events[0].status,'skipped');assert.equal(f.drafts.length,0);
});
test('new unread is captured while an earlier reply model is still pending',async t=>{
 let release;let calls=0;
 const f=fixture(t,{replyGenerator:async()=>++calls===1?new Promise(resolve=>{release=resolve;}):'reply'});
 f.setMessages([{id:'m1',direction:'incoming',text:'hello'}]);
 f.setChats([{id:'a',title:'A',preview:'one',hasUnread:true,signature:'1'}]);
 await f.service.globalPreview({enabled:true});
 const working=f.service.tick();await wait(()=>!!release);
 f.setChats([{id:'b',title:'B',preview:'two',hasUnread:true,signature:'2'}]);
 try {
  await f.service.tick();
  assert.equal(f.service.state.globalPreview.events.some(e=>e.chatId==='b'&&e.status==='queued'),true);
  assert.equal(f.service.state.globalPreview.events.find(e=>e.chatId==='a').status,'generating');
 } finally {release('reply');await working;}
 assert.deepEqual(f.drafts.map(d=>d.contact.id),['a','b']);assert.equal(f.sends.length,0);
});
test('passive dashboard status does not queue behind a UI operation',async t=>{
 const f=fixture(t,{adapter:{peekStatus:async()=>({ready:true,accountId:'account-a'})}});
 let release;const operation=f.service.locked(()=>new Promise(resolve=>{release=resolve;}));await wait(()=>!!release);
 try {await Promise.race([f.service.status(),new Promise((_,reject)=>setTimeout(()=>reject(new Error('status blocked')),80))]);}
 finally {release();await operation;}
});
test('queued unread records are never evicted by the history limit',t=>{
 const f=fixture(t);const chats=Array.from({length:105},(_,i)=>({id:String(i),title:String(i),preview:'hello',hasUnread:true,signature:'1'}));
 const result=f.service.enqueueUnread({events:[],completed:{}},chats);
 assert.equal(result.events.length,105);assert.equal(result.events[0].chatId,'0');
});
test('newer unread for the same queued chat replaces the old snapshot',t=>{
 const f=fixture(t);
 const row={id:'a',title:'A',preview:'first',hasUnread:true,signature:'1'};
 const first=f.service.enqueueUnread({events:[],completed:{}},[row]);
 const second=f.service.enqueueUnread(first,[{...row,signature:'2',preview:'latest'}]);
 assert.equal(second.events.length,1);assert.equal(second.events[0].preview,'latest');
 assert.equal(second.events[0].id,first.events[0].id);
});
test('global pending events only keep the latest unread snapshot per chat',t=>{
 const f=fixture(t);
 const first=f.service.enqueueUnread({events:[],completed:{}},[{id:'a',title:'A',preview:'旧消息',hasUnread:true,signature:'old'}]);
 const processed={...first,events:first.events.map(event=>({...event,status:'failed',failureCode:'WECHAT_KNOWLEDGE_UNAVAILABLE'}))};
 const second=f.service.enqueueUnread(processed,[{id:'a',title:'A',preview:'新消息',hasUnread:true,signature:'new'}]);
 assert.deepEqual(second.events.filter(event=>event.status!=='superseded').map(event=>[event.chatId,event.preview,event.signature]),[['a','新消息','new']]);
 assert.equal(second.events.find(event=>event.signature==='old').status,'superseded');
});
test('stop cancels an in-flight initial enable scan',async t=>{
 let release;const f=fixture(t,{adapter:{listChats:()=>new Promise(resolve=>{release=resolve;})}});
 const enabling=f.service.globalPreview({enabled:true});await wait(()=>!!release);
 await f.service.globalPreview({enabled:false});release({accountId:'account-a',chats:[]});await enabling;
 assert.equal(f.service.state.globalPreview.enabled,false);
});
test('account change during draft preparation halts remaining unread chats',async t=>{
 let reads=0;const f=fixture(t,{adapter:{readChat:async()=>{reads++;throw new Error('WECHAT_ACCOUNT_CHANGED');}}});
 f.setChats(['a','b'].map(id=>({id,title:id,preview:'hello',hasUnread:true,signature:id})));
 await f.service.globalPreview({enabled:true});await f.service.tick();
 assert.equal(reads,1);assert.equal(f.service.state.globalPreview.enabled,false);assert.deepEqual(f.service.state.globalPreview.events.map(e=>e.status),['failed','cancelled']);
});
test('dashboard refresh is fully passive and never probes or performs account UI actions',async t=>{
 let probes=0;const f=fixture(t,{adapter:{status:async()=>assert.fail('interactive status'),peekStatus:async()=>{probes++;return {ready:false,failureCode:'WECHAT_ACCOUNT_UNVERIFIED'};}}});
 await f.service.status();await f.service.status();assert.equal(probes,0);
});
test('startup pauses restored monitoring without scanning, focusing, or opening WeChat chats',async t=>{
 let listCalls=0,readCalls=0;
 const f=fixture(t,{adapter:{listChats:async()=>{listCalls+=1;return {accountId:'account-a',chats:[]};},readChat:async c=>{readCalls+=1;return {accountId:'account-a',contactId:c.id,title:c.name,messages:[]};}}});
 f.service.stop();
 f.service.save({...f.service.state,
  globalPreview:{...f.service.state.globalPreview,enabled:true,stage:'scanning',accountId:'account-a',events:[{id:'queued',status:'queued'}]},
  watches:[{id:'restored-watch',accountId:'account-a',contact,enabled:true,seen:[],observedIds:[],pending:[]}],
 });
 f.service.start();
 await new Promise(resolve=>setTimeout(resolve,25));
 assert.equal(f.service.state.globalPreview.enabled,false);
 assert.equal(f.service.state.globalPreview.stage,'paused');
 assert.equal(f.service.state.globalPreview.resumeRequired,true);
 assert.equal(f.service.state.watches[0].enabled,false);
 assert.equal(f.service.state.watches[0].resumeRequired,true);
 assert.equal(listCalls,0);
 assert.equal(readCalls,0);
});
test('stopping during a successful scan cannot reenable monitoring or open chats',async t=>{
 let release,calls=0;const f=fixture(t,{adapter:{listChats:async()=>++calls===1?{accountId:'account-a',chats:[]}:new Promise(resolve=>{release=resolve;})}});
 await f.service.globalPreview({enabled:true});const tick=f.service.tick();await wait(()=>!!release);
 await f.service.globalPreview({enabled:false});release({accountId:'account-a',chats:[{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'new'}]});await tick;
 assert.equal(f.service.state.globalPreview.enabled,false);assert.deepEqual(f.drafts,[]);assert.deepEqual(f.service.state.globalPreview.events,[]);
});
test('knowledge reply persists source references on the queued task',async t=>{
 const sources=[{title:'营业',relativePath:'商户/营业.md'}];
 const f=fixture(t,{replyGenerator:async()=>({text:'9点营业',knowledgeSources:sources})});
 await f.service.watch({contact});f.setMessages([{id:'kb-new',direction:'incoming',text:'几点营业'}]);
 await f.service.tick();await f.service.tick();
 await wait(()=>f.service.tasks()[0]?.status==='sent');
 assert.deepEqual(f.service.tasks()[0].knowledgeSources,sources);
 assert.deepEqual(f.sends,['9点营业']);
});
test('Jev failure never blocks a global draft or watch reply, and successful assessments persist with the result',async t=>{
 const assessment={model:'jev-1.13.0',intent:{choice:'咨询',probabilities:{咨询:1},confidence:1},purchaseIntent:0.7,urgency:{choice:'近期',probabilities:{近期:1},confidence:1},recommendedAction:{choice:'追问需求',probabilities:{追问需求:1},confidence:1},risk:{choice:'低',probabilities:{低:1},confidence:1},analyzedAt:1};
 const f=fixture(t,{jevAnalyzer:async()=>assessment});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});await f.service.tick();
 assert.deepEqual(f.service.state.globalPreview.events[0].jevAssessment,assessment);
 const watched=fixture(t,{jevAnalyzer:async()=>assessment});await watched.service.watch({contact});watched.setMessages([{id:'watch',direction:'incoming',text:'请问价格'}]);await watched.service.tick();await watched.service.tick();
 await wait(()=>watched.service.tasks()[0]?.status==='sent');assert.deepEqual(watched.service.tasks()[0].jevAssessment,assessment);
 const unavailable=fixture(t,{jevAnalyzer:async()=>{throw Object.assign(new Error('down'),{code:'JEV_API_UNAVAILABLE'});}});
 unavailable.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'s'}]);unavailable.setMessages([{id:'m',direction:'incoming',text:'你好'}]);
 await unavailable.service.globalPreview({enabled:true});await unavailable.service.tick();
 assert.equal(unavailable.drafts.length,1);assert.equal(unavailable.service.state.globalPreview.events[0].analysisUnavailable,'JEV_API_UNAVAILABLE');
});
test('send queue is ordered, durable and idempotent',async t=>{
 const f=fixture(t); const a=await f.service.send({contact,text:'a',requestId:'a'}); await f.service.send({contact,text:'b',requestId:'b'});
 assert.equal((await f.service.send({contact,text:'a',requestId:'a'})).id,a.id);
 await wait(()=>f.service.tasks().every(x=>x.status==='sent')); assert.deepEqual(f.sends,['a','b']);
 const restored=new CustomerService({stateDir:f.stateDir,adapter:f.adapter}); assert.equal(restored.tasks().length,2); assert.equal(restored.tasks()[0].status,'sent');
 await assert.rejects(()=>f.service.send({contact,text:'changed',requestId:'a'}),/IDEMPOTENCY_CONFLICT/);
});
test('clearing failed task history preserves sent and active tasks',async t=>{
 const f=fixture(t);f.service.stop();
 await f.service.send({contact,text:'failed',requestId:'failed'});
 await f.service.send({contact,text:'sent',requestId:'sent'});
 await f.service.send({contact,text:'queued',requestId:'queued'});
 const [failed,sent]=f.service.tasks();
 f.service.updateTask(failed.id,{status:'failed',failureCode:'WECHAT_CONTACT_NOT_FOUND'});
 f.service.updateTask(sent.id,{status:'sent',failureCode:null,evidence:{messageId:'sent'}});
 const result=f.service.clearFailedTasks();
 assert.deepEqual(result,{removed:1,remaining:2});
 assert.deepEqual(f.service.tasks().map(task=>task.status),['sent','queued']);
});
test('stopping global preview clears stale monitor failure',async t=>{
 const f=fixture(t);
 f.service.save({...f.service.state,globalPreview:{...f.service.state.globalPreview,enabled:true,failureCode:'WECHAT_ACCOUNT_UNAVAILABLE'}});
 const stopped=await f.service.globalPreview({enabled:false});
 assert.equal(stopped.enabled,false);assert.equal(stopped.failureCode,null);
});
test('ambiguous outcome is not retried and queue continues',async t=>{
 const f=fixture(t,{adapter:{send:async()=>({status:'unknown'})}});
 await f.service.send({contact,text:'a',requestId:'a'}); await wait(()=>f.service.tasks()[0].status==='unknown');
 await f.service.send({contact,text:'a',requestId:'a'}); assert.equal(f.service.tasks().length,1);
});
test('watch ignores history and own messages; new incoming generates one response',async t=>{
 const f=fixture(t); f.setMessages([{id:'old',text:'旧消息',direction:'incoming'}]); await f.service.watch({contact,enabled:true}); await f.service.tick(); assert.equal(f.sends.length,0);
 f.setMessages([{id:'old',text:'旧消息',direction:'incoming'},{id:'new',text:'你好',direction:'incoming'}]); await f.service.tick(); await f.service.tick(); await wait(()=>f.service.tasks().length===1&&f.service.tasks()[0].status==='sent'); assert.deepEqual(f.sends,['自动回复']);
 f.setMessages([{id:'old',text:'旧消息',direction:'incoming'},{id:'new',text:'你好',direction:'incoming'},{id:'manual',text:'人工接管',direction:'outgoing'}]); await f.service.tick(); assert.equal((await f.service.status()).watches[0].enabled,false);
});
test('global preview queues existing unread immediately and never sends',async t=>{
 const f=fixture(t);f.setChats([{id:'a',title:'甲',preview:'旧消息',unreadCount:1,signature:'old'}]);
 const enabled=await f.service.globalPreview({enabled:true});assert.equal(enabled.enabled,true);assert.equal(enabled.events.length,1);assert.equal(enabled.events[0].status,'queued');
 f.setMessages([{id:'m1',direction:'incoming',text:'请问营业时间'}]);f.setChats([{id:'a',title:'甲',preview:'新消息',unreadCount:2,signature:'new'},{id:'b',title:'乙',preview:'第一条',unreadCount:1,signature:'first'}]);await f.service.tick();
 const status=await f.service.status();assert.deepEqual(status.globalPreview.events.map(event=>[event.title,event.preview]),[['甲','新消息'],['乙','第一条']]);assert.deepEqual(f.sends,[]);
 assert.equal(f.drafts.length,2);assert.equal(status.globalPreview.events.filter(event=>event.status==='drafted').length,2);
 await f.service.globalPreview({enabled:false});assert.equal((await f.service.status()).globalPreview.enabled,false);
});
test('tag scope rejects an empty selection',async t=>{
 const f=fixture(t,{adapter:{listTags:async()=>({accountId:'account-a',tags:[]}),listTagContacts:async()=>({accountId:'account-a',contacts:[]})}});
 await assert.rejects(f.service.tagScope({enabled:true,tagIds:[]}),{code:'WECHAT_TAG_SCOPE_EMPTY'});
});
test('tag scope deduplicates contacts and generates candidates without drafting',async t=>{
 const f=fixture(t,{adapter:{
  listTags:async()=>({accountId:'account-a',tags:[{id:'lead',name:'意向客户',contactCount:2},{id:'support',name:'售后客户',contactCount:2}]}),
  listTagContacts:async()=>({accountId:'account-a',contacts:[{id:'account-a:甲',name:'甲',tagIds:['lead']},{id:'account-a:甲',name:'甲',tagIds:['support']},{id:'account-a:乙',name:'乙',tagIds:['support']}]})
 }});
 f.setChats([{id:'account-a:甲',title:'甲',preview:'请问价格',hasUnread:true,signature:'a'},{id:'account-a:乙',title:'乙',preview:'设备坏了',hasUnread:true,signature:'b'},{id:'account-a:丙',title:'丙',preview:'不应处理',hasUnread:true,signature:'c'}]);
 f.setMessages([{id:'m',direction:'incoming',text:'请问价格'}]);
 await f.service.tagScope({enabled:true,tagIds:['lead','support']});
 await f.service.tick();
 const monitor=f.service.state.globalPreview;
 assert.deepEqual(monitor.resolvedContacts.map(item=>item.id),['account-a:甲','account-a:乙']);
 assert.equal(monitor.events.length,2);
 assert.equal(monitor.events.every(item=>Array.isArray(item.candidates)&&item.candidates.length>=1),true);
 assert.deepEqual(f.drafts,[]);
});
test('global draft supports unread dots, preserves completed history and explicitly replaces drafts',async t=>{
 let options;const f=fixture(t,{adapter:{draft:async(c,text,o)=>{options=o;return {status:'drafted',evidence:{kind:'input_draft'}};}}});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,unreadCount:0,signature:'dot'}]);f.setMessages([{id:'old',direction:'incoming',text:'历史'},{id:'new',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});await f.service.tick();assert.deepEqual(options,{replaceExisting:true});
 assert.deepEqual(f.service.state.globalPreview.events[0].incomingMessageIds,['new']);
 await f.service.tick();assert.equal(f.service.state.globalPreview.events.length,1);assert.equal(f.service.tasks().length,0);
 await f.service.globalPreview({enabled:false});await f.service.globalPreview({enabled:true});await f.service.tick();assert.equal(f.service.state.globalPreview.events.length,1);
});
test('global model wait allows stop, and stale reply cannot overwrite after reenable',async t=>{
 let finish,calls=0;const f=fixture(t,{replyGenerator:()=>++calls===1?new Promise(r=>{finish=r;}):'新回复'});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});const tick=f.service.tick();await wait(()=>!!finish);
 await f.service.globalPreview({enabled:false});finish('旧回复');await tick;assert.equal(f.drafts.length,0);
 await f.service.globalPreview({enabled:true});await f.service.tick();assert.deepEqual(f.drafts.map(item=>item.text),['新回复']);
});
test('stopping during native draft keeps the event cancelled',async t=>{
 let release;const f=fixture(t,{adapter:{draft:()=>new Promise(resolve=>{release=()=>resolve({status:'drafted',evidence:{kind:'input_draft'}});})}});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});const tick=f.service.tick();await wait(()=>!!release);
 await f.service.globalPreview({enabled:false});release();await tick;
 assert.equal(f.service.state.globalPreview.events[0].status,'cancelled');
});
test('restart keeps queued unread records paused until this process receives an explicit monitoring command',async t=>{
 const f=fixture(t);f.setChats([{id:'a',title:'甲',preview:'你好',unreadCount:1,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);await f.service.globalPreview({enabled:true});f.service.stop();f.setChats([]);
 const restored=new CustomerService({stateDir:f.stateDir,adapter:f.adapter,replyGenerator:async()=> '回复'});t.after(()=>restored.stop());restored.start();await restored.tick();assert.equal(restored.state.globalPreview.enabled,false);assert.equal(restored.state.globalPreview.resumeRequired,true);assert.equal(restored.state.globalPreview.events[0].status,'cancelled');assert.equal(f.drafts.length,0);
});
test('account switch prevents sending',async t=>{
 let count=0; const f=fixture(t,{adapter:{status:async()=>({accountId:++count===1?'account-a':'account-b',ready:true})}});
 await f.service.send({contact,text:'a',requestId:'a'}); await wait(()=>f.service.state.tasks[0].status==='failed'); assert.equal(f.service.state.tasks[0].failureCode,'WECHAT_ACCOUNT_CHANGED'); assert.equal(f.sends.length,0);assert.equal(f.service.tasks().length,0);
});
test('invalid input rejected before work',async t=>{const f=fixture(t); await assert.rejects(()=>f.service.send({contact,text:'',requestId:'x'}),/INVALID_TEXT/);});
test('cold start quarantines all unfinished sends and never opens WeChat',async t=>{
 const f=fixture(t); f.service.stop(); await f.service.send({contact,text:'uncertain',requestId:'1'});await f.service.send({contact,text:'pending',requestId:'2'});
 f.service.updateTask(f.service.tasks()[0].id,{status:'sending'});
 const restored=new CustomerService({stateDir:f.stateDir,adapter:f.adapter});t.after(()=>restored.stop());restored.start();
 await new Promise(resolve=>setTimeout(resolve,25));
 assert.deepEqual(restored.tasks().map(task=>task.status),['unknown','unknown']);
 assert.deepEqual(restored.tasks().map(task=>task.failureCode),['WECHAT_SEND_INTERRUPTED','WECHAT_SEND_RESUME_REQUIRED']);
 assert.deepEqual(f.sends,[]);
});
test('definite pre-send failure continues later queue items',async t=>{
 let count=0;const f=fixture(t,{adapter:{send:async()=>{if(++count===1)throw new Error('WECHAT_CONTACT_NOT_FOUND');return {status:'sent',evidence:{messageId:'2'}};}}});
 await f.service.send({contact,text:'a',requestId:'a'});await f.service.send({contact,text:'b',requestId:'b'});await wait(()=>f.service.tasks()[1].status==='sent');assert.equal(f.service.tasks()[0].status,'failed');
});
test('watch respects debounce and preserves pending messages on model failure',async t=>{
 let modelReady=false;const f=fixture(t,{debounceMs:20,replyGenerator:async()=>{if(!modelReady)throw new Error('MODEL_UNAVAILABLE');return 'reply';}});
 await f.service.watch({contact}); f.setMessages([{id:'1',direction:'incoming',text:'new'}]); await f.service.tick();assert.equal(f.sends.length,0);
 await new Promise(r=>setTimeout(r,25));await f.service.tick();assert.equal((await f.service.status()).watches[0].pending.length,1);
 modelReady=true;await f.service.tick();await wait(()=>f.service.tasks()[0]?.status==='sent');assert.deepEqual(f.sends,['reply']);
});
test('own verified outgoing does not pause watcher',async t=>{
 const f=fixture(t);await f.service.watch({contact});await f.service.send({contact,text:'hello',requestId:'hello'});await wait(()=>f.service.tasks()[0].status==='sent');
 f.setMessages([{id:'1',text:'hello',direction:'outgoing'}]);await f.service.tick();assert.equal((await f.service.status()).watches[0].enabled,true);
});
test('missing send evidence never counts as success',async t=>{
 const f=fixture(t,{adapter:{send:async()=>({status:'sent'})}});await f.service.send({contact,text:'a',requestId:'a'});await wait(()=>f.service.tasks()[0].status==='unknown');
});
test('structured send pipeline verifies a new outgoing bubble before marking sent',async t=>{
 let messages=[];const calls=[];
 const f=fixture(t,{adapter:{
  openChat:async c=>{calls.push('openChat');return {accountId:'account-a',contactId:c.id}},
  readChat:async c=>{calls.push('readChat');return {accountId:'account-a',contactId:c.id,messages:[...messages]}},
  readComposer:async()=>({value:'hello'}),
  draft:async()=>{calls.push('draft');return {status:'drafted',evidence:{kind:'input_draft'}}},
  sendAction:async()=>{calls.push('sendAction');messages=[{id:'out-1',direction:'outgoing',text:'hello'}];return {status:'action_performed'}},
  readSendEvidence:async()=>({messages:[...messages],composer:'',failure:false}),
 }});
 await f.service.send({contact,text:'hello',requestId:'structured'});
 await wait(()=>f.service.tasks()[0]?.status==='sent');
 assert.deepEqual(calls,['openChat','readChat','draft','sendAction']);
 assert.equal(f.service.tasks()[0].evidence.afterMessageId,'out-1');
 assert.equal('messages' in f.service.tasks()[0].evidence,false);
});
test('structured send evidence is recognized as service-owned by the watcher',async t=>{
 const f=fixture(t);await f.service.watch({contact});
 f.service.save({...f.service.state,tasks:[{id:'task',accountId:'account-a',contact,status:'sent',evidence:{afterMessageId:'owned'}}]});
 f.setMessages([{id:'owned',direction:'outgoing',text:'reply'}]);
 await f.service.tick();
 assert.equal((await f.service.status()).watches[0].enabled,true);
});
test('pause during model generation prevents automatic sending',async t=>{
 let resolve;const f=fixture(t,{replyGenerator:()=>new Promise(r=>{resolve=r;})});await f.service.watch({contact});f.setMessages([{id:'1',direction:'incoming',text:'new'}]);
 const ticking=f.service.tick();await wait(()=>!!resolve);await f.service.pause(contact);resolve('reply');await ticking;assert.equal(f.service.tasks().length,0);
});
test('second runtime is read-only and cannot duplicate queued sends',async t=>{
 const f=fixture(t);const second=new CustomerService({stateDir:f.stateDir,adapter:f.adapter});t.after(()=>second.stop());
 assert.equal(second.readOnly,true);await assert.rejects(()=>second.send({contact,text:'a',requestId:'a'}),/WORKER_ALREADY_RUNNING/);
});
test('status remains responsive during long sends',async t=>{
 let finish;const f=fixture(t,{adapter:{send:async()=>new Promise(r=>{finish=r;})}});await f.service.send({contact,text:'a',requestId:'a'});await wait(()=>!!finish);
 const status=await Promise.race([f.service.status(),new Promise((_,reject)=>setTimeout(()=>reject(new Error('blocked')),50))]);assert.equal(status.running,true);
 finish({status:'unknown'});await wait(()=>!f.service.running);
});
test('manual outgoing while model runs prevents subsequent send',async t=>{
 let resolve;const f=fixture(t,{replyGenerator:()=>new Promise(r=>{resolve=r;})});await f.service.watch({contact});f.setMessages([{id:'1',direction:'incoming',text:'new'}]);
 const ticking=f.service.tick();await wait(()=>!!resolve);f.setMessages([{id:'1',direction:'incoming',text:'new'},{id:'2',direction:'outgoing',text:'human'}]);resolve('reply');await ticking;await wait(()=>f.service.tasks()[0]?.status==='skipped');assert.equal(f.sends.length,0);
});
test('persisted pending batch with existing task is not regenerated after interrupted cursor update',async t=>{
 let generations=0;const f=fixture(t,{replyGenerator:async()=>{generations++;return 'reply';}});
 const watch=await f.service.watch({contact});const message={id:'new',direction:'incoming',text:'hi'};f.setMessages([message]);
 await f.service.send({contact,text:'already owned',requestId:`watch:${watch.id}:new`});await wait(()=>f.service.tasks()[0].status==='sent');
 f.service.updateWatch(watch.id,{seen:['new'],pending:[message],changedAt:0});await f.service.tick();assert.equal(generations,0);assert.equal(f.service.tasks().length,1);
});
test('native send receives frozen account identity and rejects stale contact account',async t=>{
 let received;const f=fixture(t,{adapter:{send:async(c)=>{received=c;return {status:'sent',evidence:{messageId:'1'}};}}});
 await f.service.send({contact,text:'hello',requestId:'bound'});await wait(()=>f.service.tasks()[0].status==='sent');assert.equal(received.accountId,'account-a');
 await assert.rejects(()=>f.service.send({contact:{...contact,accountId:'other'},text:'hello',requestId:'wrong'}),/ACCOUNT_CHANGED/);
});
test('native accessibility failure halts remaining queue and reports permission responsibility',async t=>{
 const f=fixture(t,{adapter:{send:async()=>{throw new Error('WECHAT_ACCESSIBILITY_REQUIRED');}}});f.service.stop();
 await f.service.send({contact,text:'one',requestId:'1'});await f.service.send({contact,text:'two',requestId:'2'});f.service.start();
 await wait(()=>f.service.tasks()[1].status==='skipped');assert.equal(f.service.tasks()[0].responsibility,'桌面权限');
});
test('replaced synthetic message ids pause watcher instead of replaying history',async t=>{
 const f=fixture(t);f.setMessages([{id:'old-id',direction:'incoming',text:'old'}]);await f.service.watch({contact});
 f.setMessages([{id:'new-id',direction:'incoming',text:'old'}]);await f.service.tick();
 const watch=(await f.service.status()).watches[0];assert.equal(watch.enabled,false);assert.equal(watch.failureCode,'WECHAT_HISTORY_RESYNC_REQUIRED');assert.equal(f.service.tasks().length,0);
});
test('older prefix appearing on scroll does not trigger replies',async t=>{
 const f=fixture(t);const current={id:'current',direction:'incoming',text:'current'};f.setMessages([current]);await f.service.watch({contact});
 f.setMessages([{id:'older',direction:'incoming',text:'old'},current]);await f.service.tick();assert.equal(f.service.tasks().length,0);
 f.setMessages([{id:'older',direction:'incoming',text:'old'},current,{id:'new',direction:'incoming',text:'new'}]);await f.service.tick();await wait(()=>f.service.tasks()[0]?.status==='sent');assert.deepEqual(f.sends,['自动回复']);
});
test('missing last observed anchor pauses shifted history and reenable resets baseline',async t=>{
 const f=fixture(t);f.setMessages([{id:'1',direction:'incoming',text:'one'},{id:'2',direction:'incoming',text:'two'}]);await f.service.watch({contact});
 f.setMessages([{id:'older',direction:'incoming',text:'old'},{id:'1',direction:'incoming',text:'one'}]);await f.service.tick();assert.equal((await f.service.status()).watches[0].enabled,false);
 await f.service.watch({contact});await f.service.tick();assert.equal((await f.service.status()).watches[0].enabled,true);assert.equal(f.sends.length,0);
});
test('stopping global preview during a failed scan stays stopped',async t=>{
 let rejectScan,calls=0;
 const f=fixture(t,{adapter:{listChats:async()=>{calls+=1;if(calls===1)return {accountId:'account-a',chats:[]};return new Promise((_,reject)=>{rejectScan=reject;});}}});
 await f.service.globalPreview({enabled:true});
 const ticking=f.service.tick();await wait(()=>!!rejectScan);
 await f.service.globalPreview({enabled:false});rejectScan(Object.assign(new Error('timeout'),{code:'WECHAT_HELPER_TIMEOUT'}));await ticking;
 assert.equal((await f.service.status()).globalPreview.enabled,false);
});
