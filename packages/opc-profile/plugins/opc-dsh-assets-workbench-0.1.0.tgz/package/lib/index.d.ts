import type { Context } from '@deepseek-ai/cordis';
export declare const name = "opc-assets-workbench";
export declare const inject: never[];
export declare function apply(_ctx: Context): void;
