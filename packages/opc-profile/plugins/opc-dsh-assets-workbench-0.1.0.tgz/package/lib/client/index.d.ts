/**
 * Compatibility bundle. The standalone asset department is owned by
 * @opc/dsh-assets; keeping this module as a no-op prevents duplicate tabs
 * when an older profile still contains the package.
 */
export declare function apply(): void;
