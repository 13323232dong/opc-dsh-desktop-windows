import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
export declare function AssetWorkbench(_props: ConvViewProps): JSX.Element;
