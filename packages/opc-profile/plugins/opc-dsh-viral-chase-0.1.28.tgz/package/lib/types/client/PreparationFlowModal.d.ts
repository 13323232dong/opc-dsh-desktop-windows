export type PreparationStepKey = 'extract' | 'rewrite';
interface PreparationFlowModalProps {
    readonly step: PreparationStepKey;
    readonly status: string;
    readonly progress: number;
    readonly needsApproval: boolean;
    readonly message: string;
    readonly error?: string | null;
    readonly sourceNote?: string;
    readonly onApprove: () => void;
    readonly onCancel: () => void;
    readonly onRetry: () => void;
    readonly onClose: () => void;
}
export declare function PreparationFlowModal(props: PreparationFlowModalProps): JSX.Element;
export {};
