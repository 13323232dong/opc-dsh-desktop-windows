import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
type Props = PropsRuntime<'conversation.chat.node', 'viral-protagonist-auth'>;
export declare function ProtagonistAuthCard({ node, sessionId }: Props): import("react").JSX.Element;
export {};
