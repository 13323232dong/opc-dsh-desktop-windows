import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
export interface ProtagonistAuthCardData {
    readonly anchorId: string;
    readonly anchorName: string;
    readonly authorizationStatus: string;
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ChatNodeDataMap {
        'viral-protagonist-auth': ProtagonistAuthCardData;
    }
}
export interface ProtagonistAuthCardState extends ProtagonistAuthCardData {
    readonly callId: string;
}
export declare const protagonistAuthCardDefinition: ConversationNodeDefinition<ProtagonistAuthCardState>;
