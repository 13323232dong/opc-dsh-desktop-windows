import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { CustomerService } from '../src/core.mjs';

const wait = async (predicate) => { for(let n=0;n<100;n++){ if(predicate()) return; await new Promise(r=>setTimeout(r,5)); } assert.fail('worker timeout'); };
function fixture(t, options={}) {
 const stateDir=mkdtempSync(join(tmpdir(),'customer-test-')); t.after(()=>rmSync(stateDir,{recursive:true,force:true}));
 let messages=[], conversations=[]; const sends=[],drafts=[];
 const adapter={status:async()=>({accountId:'account-a',ready:true}),findContact:async name=>({id:name,name}),readChat:async c=>({accountId:'account-a',contactId:c.id,title:c.name,messages}),listChats:async()=>({accountId:'account-a',chats:conversations}),draft:async(c,text)=>{drafts.push({contact:c,text});return {status:'drafted',evidence:{kind:'input_draft'}}},send:async(c,text,{onStage})=>{sends.push(text); await onStage('sending'); return {status:'sent',evidence:{messageId:String(sends.length)}}},...options.adapter};
 const service=new CustomerService({stateDir,replyGenerator:async()=> '自动回复',debounceMs:0,...options,adapter}); t.after(()=>service.stop());
 return {service,stateDir,adapter,sends,drafts,setMessages:m=>{messages=m;},setChats:c=>{conversations=c;}};
}
const contact={id:'contact-1',name:'测试联系人'};
test('knowledge reply persists source references on the queued task',async t=>{
 const sources=[{title:'营业',relativePath:'商户/营业.md'}];
 const f=fixture(t,{replyGenerator:async()=>({text:'9点营业',knowledgeSources:sources})});
 await f.service.watch({contact});f.setMessages([{id:'kb-new',direction:'incoming',text:'几点营业'}]);
 await f.service.tick();await f.service.tick();
 await wait(()=>f.service.tasks()[0]?.status==='sent');
 assert.deepEqual(f.service.tasks()[0].knowledgeSources,sources);
 assert.deepEqual(f.sends,['9点营业']);
});
test('send queue is ordered, durable and idempotent',async t=>{
 const f=fixture(t); const a=await f.service.send({contact,text:'a',requestId:'a'}); await f.service.send({contact,text:'b',requestId:'b'});
 assert.equal((await f.service.send({contact,text:'a',requestId:'a'})).id,a.id);
 await wait(()=>f.service.tasks().every(x=>x.status==='sent')); assert.deepEqual(f.sends,['a','b']);
 const restored=new CustomerService({stateDir:f.stateDir,adapter:f.adapter}); assert.equal(restored.tasks().length,2); assert.equal(restored.tasks()[0].status,'sent');
 await assert.rejects(()=>f.service.send({contact,text:'changed',requestId:'a'}),/IDEMPOTENCY_CONFLICT/);
});
test('ambiguous outcome is not retried and queue continues',async t=>{
 const f=fixture(t,{adapter:{send:async()=>({status:'unknown'})}});
 await f.service.send({contact,text:'a',requestId:'a'}); await wait(()=>f.service.tasks()[0].status==='unknown');
 await f.service.send({contact,text:'a',requestId:'a'}); assert.equal(f.service.tasks().length,1);
});
test('watch ignores history and own messages; new incoming generates one response',async t=>{
 const f=fixture(t); f.setMessages([{id:'old',text:'旧消息',direction:'incoming'}]); await f.service.watch({contact,enabled:true}); await f.service.tick(); assert.equal(f.sends.length,0);
 f.setMessages([{id:'old',text:'旧消息',direction:'incoming'},{id:'new',text:'你好',direction:'incoming'}]); await f.service.tick(); await f.service.tick(); await wait(()=>f.service.tasks().length===1&&f.service.tasks()[0].status==='sent'); assert.deepEqual(f.sends,['自动回复']);
 f.setMessages([{id:'old',text:'旧消息',direction:'incoming'},{id:'new',text:'你好',direction:'incoming'},{id:'manual',text:'人工接管',direction:'outgoing'}]); await f.service.tick(); assert.equal((await f.service.status()).watches[0].enabled,false);
});
test('global preview queues existing unread immediately and never sends',async t=>{
 const f=fixture(t);f.setChats([{id:'a',title:'甲',preview:'旧消息',unreadCount:1,signature:'old'}]);
 const enabled=await f.service.globalPreview({enabled:true});assert.equal(enabled.enabled,true);assert.equal(enabled.events.length,1);assert.equal(enabled.events[0].status,'queued');
 f.setMessages([{id:'m1',direction:'incoming',text:'请问营业时间'}]);f.setChats([{id:'a',title:'甲',preview:'新消息',unreadCount:2,signature:'new'},{id:'b',title:'乙',preview:'第一条',unreadCount:1,signature:'first'}]);await f.service.tick();
 const status=await f.service.status();assert.deepEqual(status.globalPreview.events.map(event=>[event.title,event.preview]),[['甲','旧消息'],['甲','新消息'],['乙','第一条']]);assert.deepEqual(f.sends,[]);
 assert.equal(f.drafts.length,3);assert.equal(status.globalPreview.events.filter(event=>event.status==='drafted').length,3);
 await f.service.globalPreview({enabled:false});assert.equal((await f.service.status()).globalPreview.enabled,false);
});
test('global draft supports unread dots, preserves completed history and explicitly replaces drafts',async t=>{
 let options;const f=fixture(t,{adapter:{draft:async(c,text,o)=>{options=o;return {status:'drafted',evidence:{kind:'input_draft'}};}}});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,unreadCount:0,signature:'dot'}]);f.setMessages([{id:'old',direction:'incoming',text:'历史'},{id:'new',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});await f.service.tick();assert.deepEqual(options,{replaceExisting:true});
 assert.deepEqual(f.service.state.globalPreview.events[0].incomingMessageIds,['new']);
 await f.service.tick();assert.equal(f.service.state.globalPreview.events.length,1);assert.equal(f.service.tasks().length,0);
 await f.service.globalPreview({enabled:false});await f.service.globalPreview({enabled:true});await f.service.tick();assert.equal(f.service.state.globalPreview.events.length,1);
});
test('global model wait allows stop, and stale reply cannot overwrite after reenable',async t=>{
 let finish,calls=0;const f=fixture(t,{replyGenerator:()=>++calls===1?new Promise(r=>{finish=r;}):'新回复'});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});const tick=f.service.tick();await wait(()=>!!finish);
 await f.service.globalPreview({enabled:false});finish('旧回复');await tick;assert.equal(f.drafts.length,0);
 await f.service.globalPreview({enabled:true});await f.service.tick();assert.deepEqual(f.drafts.map(item=>item.text),['新回复']);
});
test('stopping during native draft keeps the event cancelled',async t=>{
 let release;const f=fixture(t,{adapter:{draft:()=>new Promise(resolve=>{release=()=>resolve({status:'drafted',evidence:{kind:'input_draft'}});})}});
 f.setChats([{id:'a',title:'甲',preview:'你好',hasUnread:true,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);
 await f.service.globalPreview({enabled:true});const tick=f.service.tick();await wait(()=>!!release);
 await f.service.globalPreview({enabled:false});release();await tick;
 assert.equal(f.service.state.globalPreview.events[0].status,'cancelled');
});
test('global queued record survives unread being cleared and restart',async t=>{
 const f=fixture(t);f.setChats([{id:'a',title:'甲',preview:'你好',unreadCount:1,signature:'s'}]);f.setMessages([{id:'m',direction:'incoming',text:'你好'}]);await f.service.globalPreview({enabled:true});f.service.stop();f.setChats([]);
 const restored=new CustomerService({stateDir:f.stateDir,adapter:f.adapter,replyGenerator:async()=> '回复'});t.after(()=>restored.stop());await restored.tick();assert.equal(restored.state.globalPreview.events[0].status,'drafted');assert.equal(f.drafts.length,1);
});
test('account switch prevents sending',async t=>{
 let count=0; const f=fixture(t,{adapter:{status:async()=>({accountId:++count===1?'account-a':'account-b',ready:true})}});
 await f.service.send({contact,text:'a',requestId:'a'}); await wait(()=>f.service.state.tasks[0].status==='failed'); assert.equal(f.service.state.tasks[0].failureCode,'WECHAT_ACCOUNT_CHANGED'); assert.equal(f.sends.length,0);assert.equal(f.service.tasks().length,0);
});
test('invalid input rejected before work',async t=>{const f=fixture(t); await assert.rejects(()=>f.service.send({contact,text:'',requestId:'x'}),/INVALID_TEXT/);});
test('crash recovery quarantines in-flight tasks and resumes queued tasks only',async t=>{
 const f=fixture(t); f.service.stop(); await f.service.send({contact,text:'uncertain',requestId:'1'});await f.service.send({contact,text:'pending',requestId:'2'});
 f.service.updateTask(f.service.tasks()[0].id,{status:'sending'});
 const restored=new CustomerService({stateDir:f.stateDir,adapter:f.adapter});t.after(()=>restored.stop());restored.start();
 await wait(()=>restored.tasks()[1].status==='sent');assert.equal(restored.tasks()[0].status,'unknown');assert.deepEqual(f.sends,['pending']);
});
test('definite pre-send failure continues later queue items',async t=>{
 let count=0;const f=fixture(t,{adapter:{send:async()=>{if(++count===1)throw new Error('WECHAT_CONTACT_NOT_FOUND');return {status:'sent',evidence:{messageId:'2'}};}}});
 await f.service.send({contact,text:'a',requestId:'a'});await f.service.send({contact,text:'b',requestId:'b'});await wait(()=>f.service.tasks()[1].status==='sent');assert.equal(f.service.tasks()[0].status,'failed');
});
test('watch respects debounce and preserves pending messages on model failure',async t=>{
 let modelReady=false;const f=fixture(t,{debounceMs:20,replyGenerator:async()=>{if(!modelReady)throw new Error('MODEL_UNAVAILABLE');return 'reply';}});
 await f.service.watch({contact}); f.setMessages([{id:'1',direction:'incoming',text:'new'}]); await f.service.tick();assert.equal(f.sends.length,0);
 await new Promise(r=>setTimeout(r,25));await f.service.tick();assert.equal((await f.service.status()).watches[0].pending.length,1);
 modelReady=true;await f.service.tick();await wait(()=>f.service.tasks()[0]?.status==='sent');assert.deepEqual(f.sends,['reply']);
});
test('own verified outgoing does not pause watcher',async t=>{
 const f=fixture(t);await f.service.watch({contact});await f.service.send({contact,text:'hello',requestId:'hello'});await wait(()=>f.service.tasks()[0].status==='sent');
 f.setMessages([{id:'1',text:'hello',direction:'outgoing'}]);await f.service.tick();assert.equal((await f.service.status()).watches[0].enabled,true);
});
test('missing send evidence never counts as success',async t=>{
 const f=fixture(t,{adapter:{send:async()=>({status:'sent'})}});await f.service.send({contact,text:'a',requestId:'a'});await wait(()=>f.service.tasks()[0].status==='unknown');
});
test('pause during model generation prevents automatic sending',async t=>{
 let resolve;const f=fixture(t,{replyGenerator:()=>new Promise(r=>{resolve=r;})});await f.service.watch({contact});f.setMessages([{id:'1',direction:'incoming',text:'new'}]);
 const ticking=f.service.tick();await wait(()=>!!resolve);await f.service.pause(contact);resolve('reply');await ticking;assert.equal(f.service.tasks().length,0);
});
test('second runtime is read-only and cannot duplicate queued sends',async t=>{
 const f=fixture(t);const second=new CustomerService({stateDir:f.stateDir,adapter:f.adapter});t.after(()=>second.stop());
 assert.equal(second.readOnly,true);await assert.rejects(()=>second.send({contact,text:'a',requestId:'a'}),/WORKER_ALREADY_RUNNING/);
});
test('status remains responsive during long sends',async t=>{
 let finish;const f=fixture(t,{adapter:{send:async()=>new Promise(r=>{finish=r;})}});await f.service.send({contact,text:'a',requestId:'a'});await wait(()=>!!finish);
 const status=await Promise.race([f.service.status(),new Promise((_,reject)=>setTimeout(()=>reject(new Error('blocked')),50))]);assert.equal(status.running,true);
 finish({status:'unknown'});await wait(()=>!f.service.running);
});
test('manual outgoing while model runs prevents subsequent send',async t=>{
 let resolve;const f=fixture(t,{replyGenerator:()=>new Promise(r=>{resolve=r;})});await f.service.watch({contact});f.setMessages([{id:'1',direction:'incoming',text:'new'}]);
 const ticking=f.service.tick();await wait(()=>!!resolve);f.setMessages([{id:'1',direction:'incoming',text:'new'},{id:'2',direction:'outgoing',text:'human'}]);resolve('reply');await ticking;await wait(()=>f.service.tasks()[0]?.status==='skipped');assert.equal(f.sends.length,0);
});
test('persisted pending batch with existing task is not regenerated after interrupted cursor update',async t=>{
 let generations=0;const f=fixture(t,{replyGenerator:async()=>{generations++;return 'reply';}});
 const watch=await f.service.watch({contact});const message={id:'new',direction:'incoming',text:'hi'};f.setMessages([message]);
 await f.service.send({contact,text:'already owned',requestId:`watch:${watch.id}:new`});await wait(()=>f.service.tasks()[0].status==='sent');
 f.service.updateWatch(watch.id,{seen:['new'],pending:[message],changedAt:0});await f.service.tick();assert.equal(generations,0);assert.equal(f.service.tasks().length,1);
});
test('native send receives frozen account identity and rejects stale contact account',async t=>{
 let received;const f=fixture(t,{adapter:{send:async(c)=>{received=c;return {status:'sent',evidence:{messageId:'1'}};}}});
 await f.service.send({contact,text:'hello',requestId:'bound'});await wait(()=>f.service.tasks()[0].status==='sent');assert.equal(received.accountId,'account-a');
 await assert.rejects(()=>f.service.send({contact:{...contact,accountId:'other'},text:'hello',requestId:'wrong'}),/ACCOUNT_CHANGED/);
});
test('native accessibility failure halts remaining queue and reports permission responsibility',async t=>{
 const f=fixture(t,{adapter:{send:async()=>{throw new Error('WECHAT_ACCESSIBILITY_REQUIRED');}}});f.service.stop();
 await f.service.send({contact,text:'one',requestId:'1'});await f.service.send({contact,text:'two',requestId:'2'});f.service.start();
 await wait(()=>f.service.tasks()[1].status==='skipped');assert.equal(f.service.tasks()[0].responsibility,'桌面权限');
});
test('replaced synthetic message ids pause watcher instead of replaying history',async t=>{
 const f=fixture(t);f.setMessages([{id:'old-id',direction:'incoming',text:'old'}]);await f.service.watch({contact});
 f.setMessages([{id:'new-id',direction:'incoming',text:'old'}]);await f.service.tick();
 const watch=(await f.service.status()).watches[0];assert.equal(watch.enabled,false);assert.equal(watch.failureCode,'WECHAT_HISTORY_RESYNC_REQUIRED');assert.equal(f.service.tasks().length,0);
});
test('older prefix appearing on scroll does not trigger replies',async t=>{
 const f=fixture(t);const current={id:'current',direction:'incoming',text:'current'};f.setMessages([current]);await f.service.watch({contact});
 f.setMessages([{id:'older',direction:'incoming',text:'old'},current]);await f.service.tick();assert.equal(f.service.tasks().length,0);
 f.setMessages([{id:'older',direction:'incoming',text:'old'},current,{id:'new',direction:'incoming',text:'new'}]);await f.service.tick();await wait(()=>f.service.tasks()[0]?.status==='sent');assert.deepEqual(f.sends,['自动回复']);
});
test('missing last observed anchor pauses shifted history and reenable resets baseline',async t=>{
 const f=fixture(t);f.setMessages([{id:'1',direction:'incoming',text:'one'},{id:'2',direction:'incoming',text:'two'}]);await f.service.watch({contact});
 f.setMessages([{id:'older',direction:'incoming',text:'old'},{id:'1',direction:'incoming',text:'one'}]);await f.service.tick();assert.equal((await f.service.status()).watches[0].enabled,false);
 await f.service.watch({contact});await f.service.tick();assert.equal((await f.service.status()).watches[0].enabled,true);assert.equal(f.sends.length,0);
});
