# dsh-file-picker

DeepSeek Harness 插件：在会话输入区增加一个「选择文件」按钮，点击后弹出**操作系统原生文件对话框**，把选中的文件**绝对路径**注入当前对话草稿，让对话把这个本地路径作为上下文（对齐 Codex 的「选文件进来当上下文」体验）。

> 浏览器拖拽拿不到原始本地绝对路径（安全限制）。拖入 PDF 时，插件会将文件保存到 DSH 的受控临时目录，再把该临时路径附加到草稿；不会向模型暴露浏览器或系统凭证。

## 能力

- **宿主半**：注册一条回环 HTTP 路由 `POST /dsh-file-picker/pick`，触发宿主显示上的原生「选文件」对话框并返回绝对路径（取消返回 `null`）。
- **浏览器半**：在 `conversation.input.left` 槽位渲染「选择文件」按钮，把返回路径追加进草稿。
- **PDF 拖放**：可将单个 PDF 直接拖到输入区的「选择文件」按钮，最大 50 MB。松开后写入受控临时路径，随后由对话中的 Agent 按你的指令处理或上传。
- 平台：macOS（`osascript choose file`）、Linux（`zenity` / `kdialog` 兜底）。Windows 暂不支持（本插件直接给出可行动的失败信息，可粘贴路径代替）。

## 结构

```
src/
  index.ts                 # 宿主半：注册 HTTP 路由 + 调用 pickNativeFile
  native-picker.ts         # 原生选择器（无 DSH 依赖，可独立单测）
  client/
    index.ts               # 浏览器半：注册 conversation.input.left 按钮槽位
    FilePickerButton.tsx   # 按钮组件：fetch 路由 → setDraft(path)
tests/native-picker.spec.ts  # 原生选择器单元测试（node:test，无依赖）
cordis.patch.yml           # bundle patch（挂载进 profile 的 host 组合）
tsdown.config.ts           # client bundle（__ModuleLoader__ 闭包工厂协议）
```

## 构建与安装

前置：已安装 DeepSeek Harness，且本包能解析到 `@deepseek-ai/*` peer 依赖。

```sh
cd dsh-file-picker
pnpm install
pnpm build           # tsc(host) + tsc(client) + tsdown(client bundle)
pnpm test            # node --test tests/*.spec.ts
```

安装进目标 profile（`dsh plugin` 会把包 pnpm 装进 profile 并对账 bundle 列表）：

```sh
dsh plugin --profile web add .
```

本地源码迭代用 `dsh plugin --profile web add .` 后运行 `pnpm build` 再刷新页面；若改动了 package manifest / 插件集合 / profile bundles，需要重启对应 profile。

## 使用

1. 重启目标 profile 后刷新 Web GUI。
2. 在会话输入区左端点击「📎 选择文件」。
3. 系统弹出文件对话框，选一个文件。
4. 该文件的绝对路径自动追加到输入草稿，随消息发送后即成为对话上下文。

也可以将单个 PDF 直接拖到「📎 选择文件」按钮上。文件不会自动发送或自动上传资产；路径进入草稿后，发送诸如“把这个 PDF 导入知识库”或“上传为素材”的消息即可。

## 验证

- `pnpm test`：原生选择器的平台分支、取消、缺命令、Windows 明确失败均覆盖。
- 真实 GUI 冒烟：`dsh plugin --profile web add .` → 重启 → 刷新 → 点击按钮 → 选文件 → 断言路径进入草稿。
