import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-file-picker";
export declare const inject: string[];
/** 插件配置：选择器路由路径（默认 `/dsh-file-picker/pick`）。 */
export interface Config {
    routePath: string;
}
export declare const Config: z<Schemastery.ObjectS<{
    routePath: z<string, string>;
}>, Schemastery.ObjectT<{
    routePath: z<string, string>;
}>>;
export declare function apply(ctx: Context, config: Config): void;
