/** 一次原生命令的运行结果（stdout/stderr）。 */
export interface NativeRunResult {
    stdout: string;
    stderr: string;
}
/** 可注入的命令运行器；默认用 `execFile`（不经过 shell，支持 signal 中止）。 */
export type NativeRunner = (command: string, args: string[], signal: AbortSignal) => Promise<NativeRunResult>;
/** 默认运行器：`execFile` 无 shell 执行，`signal` 中止时终止子进程。 */
export declare function defaultNativeRunner(command: string, args: string[], signal: AbortSignal): Promise<NativeRunResult>;
/** 可注入的平台事实与运行器，供确定性测试。 */
export interface FilePickerInternals {
    platform?: NodeJS.Platform;
    run?: NativeRunner;
}
/**
 * 打开平台原生「选择文件」对话框。
 * @param signal - 调用方/连接生命周期；中止会终止原生命令。
 * @param internals - 平台与运行器钩子，供确定性测试。
 * @returns 选中的绝对路径，取消时为 null。
 */
export declare function pickNativeFile(signal: AbortSignal, internals?: FilePickerInternals): Promise<string | null>;
