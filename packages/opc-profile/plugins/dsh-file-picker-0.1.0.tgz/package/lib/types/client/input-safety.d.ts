export interface ConversationInput {
    readonly draft: string;
}
export interface ConversationInputActions {
    readonly setDraft: (text: string) => void;
}
export declare function canWriteConversationDraft(input: ConversationInput | undefined, inputActions: ConversationInputActions | undefined): input is ConversationInput;
export declare function appendPathToDraft(draft: string, path: string): string;
