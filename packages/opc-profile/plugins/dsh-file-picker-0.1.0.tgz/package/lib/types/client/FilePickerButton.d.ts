import { type ConversationInput, type ConversationInputActions } from './input-safety.js';
/** 组件所需的输入面（结构化子集：槽位运行时注入的完整 props 是它的超集）。 */
export interface FilePickerButtonProps {
    /** 当前草稿快照（InputZone owner 提供）。 */
    input?: ConversationInput;
    /** 标准 provide 的公开写入动作。 */
    inputActions?: ConversationInputActions;
}
export declare function FilePickerButton({ input, inputActions }: FilePickerButtonProps): import("react").JSX.Element;
