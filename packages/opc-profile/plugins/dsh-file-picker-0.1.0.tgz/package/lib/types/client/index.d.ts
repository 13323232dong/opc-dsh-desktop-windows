/**
 * dsh-file-picker 浏览器半：向会话输入区左端（`conversation.input.left`）注册
 * 一个「选择文件」按钮。点击按钮 → 请求宿主半的原生选择器路由 → 把返回的
 * 绝对路径追加进草稿。type-only import 拉入 ui-conversation 的 SlotMap 合并，
 * 使 `conversation.input.left` 槽位可被声明。
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
