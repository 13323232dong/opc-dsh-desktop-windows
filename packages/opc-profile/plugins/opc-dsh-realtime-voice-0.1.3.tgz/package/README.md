# @opc/dsh-realtime-voice

DSH 原生 Cordis 全双工语音插件。

安装插件并配置火山引擎凭证后，DSH 会提供：

- 当前对话的麦克风按钮。
- Siri 风格语音球。
- 独立实时语音 Agent 与当前 Session 的受控任务交接。
- Session 事件口头摘要。
- 语音转写和摘要历史扩展点。

插件卸载时会移除前端按钮、语音球、路由、事件监听和服务连接；普通 DSH 文字对话不受影响。

## 使用

在运行 DSH 的环境中提供以下任一组凭证（凭证只在主机侧读取）：

```bash
export VOLCENGINE_API_KEY='...'
# 或旧版鉴权：
export VOLCENGINE_APP_ID='...'
export VOLCENGINE_ACCESS_KEY='...'
```

启用插件后，打开任意 DSH 对话，点击输入框旁的麦克风即可进入语音模式；语音球只负责显示状态和入口提示。浏览器采集 16kHz/16-bit/单声道 PCM，每 20ms 发送一帧，服务端把豆包返回的 24kHz PCM 播放到当前页面的输出设备。

语音 Agent 始终独立运行，普通聊天和进度询问不会进入 DSH Agent Loop。只有明确的工作请求、纠正或停止指令才会交接给打开语音模式时绑定的当前 Session；后台繁忙不会阻塞语音 Agent 继续听和说。

DSH 的进度和最终结果通过豆包 `external_rag` 上下文回到语音 Agent，由语音 Agent 组织成自然口语。插件不会把代码、JSON 或每条工具日志逐句朗读，也不会向 DSH Session 写入 `voice/item` 等未知事件。最近 200 条语音侧记录暂存在插件自己的内存日志中，DSH 的任务指令仍以标准用户消息进入原 Session。

当前实现包含豆包二进制协议 adapter、WebSocket 主机代理、浏览器收音/播放、独立语音回复、任务 handoff、Session 事件摘要和卸载清理。火山引擎全双工接口不提供 Codex Realtime 的原生 `background_agent` 工具调用，因此插件对明显工作指令使用本地快速策略，对含糊表达使用带超时的辅助分类；两者都不会暂停实时语音连接。

## 移动端与手机扫码版支持

手机扫码登录后进入 DSH 对话页（含每租户独立的 DSH web Runtime）与桌面端共用同一个客户端：

- 麦克风按钮与全屏/收起语音球自动适配窄屏与安全区；小屏下球体缩至 `min(52vw, 240px)`，按钮满足 44px 触控标准。
- 浏览器采集声道固定为单声道；**iOS Safari 与部分 Android 浏览器会忽略 `AudioContext({ sampleRate: 16000 })` 提示**，客户端会按设备真实采样率自动线性重采样到豆包要求的 16 kHz 后再分帧（每 20ms 一帧不变），否则助手会听到变调语音。
- 麦克风监听走零增益监视节点：不再把本机麦克风实时回放，避免手机外放啸叫；回复播报期间仍按原有输入门控不把合成音误当指令。
- 切后台/锁屏自动暂停收音与播报；回到前台自动恢复；若移动浏览器已掐断 WebSocket，会自动重连一次（带节流），失败后进入错误态并显示"重试连接"。
- 来电、控制中心等导致麦克风轨道被系统回收时，客户端尝试静默重新获取一次麦克风，成功后恢复聆听；失败提示"麦克风已中断，请点击重试"。

服务端凭证说明：语音插件服务端代理只在主机侧读取火山引擎凭证，读取顺序为 DSH
credentials 服务 → 环境变量 `VOLCENGINE_API_KEY` → macOS 钥匙串（服务名
`DoubaoRealtimeDemo.VOLCENGINE_API_KEY`）；旧版鉴权 `VOLCENGINE_APP_ID` /
`VOLCENGINE_ACCESS_KEY` 始终从环境变量读取。Linux 生产源站没有钥匙串：把密钥配置到
启动 opc-api 的环境（模板见仓库 `deploy/production/opc-api-multitenant.env.example`），
opc-api 拉起商户 DSH Runtime 时子进程会完整继承该环境；生产部署时必须保证该变量已
注入，否则手机上会提示"语音暂时不可用，已切换文字输入"。
