# SightFlow 适配声明

本插件参考 [sightflow-dev/sightflow-desktop-agent](https://github.com/sightflow-dev/sightflow-desktop-agent)
公开仓库中关于视觉定位、红点像素扫描、局部截图和串行输入的实现思路。

该项目采用 Apache-2.0 许可证。Evan 超级管家没有打包 SightFlow 的 Electron 应用、品牌、
Provider Hub、默认远程服务或其运行时凭据；本插件按 DSH 接口重新实现所需的算法边界。
如发行包包含第三方源码或改编代码，必须同时随包保留 Apache-2.0 LICENSE 和 NOTICE。

本适配的边界：

- Accessibility 是首选，视觉通道只在结构化读取超时或未读字段不可信时兜底。
- 视觉定位结果必须通过账号、窗口、联系人和当前 Session 上下文校验。
- 全局监听只生成草稿并写入微信输入框，不自动按发送。
- 发送成功必须回读当前联系人会话中的新增出站气泡；仅按键成功属于 `unknown`。
- 截图只使用最小必要裁剪区域，不保存完整聊天截图或凭据。
