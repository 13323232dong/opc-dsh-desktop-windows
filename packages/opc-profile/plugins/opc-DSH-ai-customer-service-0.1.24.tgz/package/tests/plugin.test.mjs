import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {apply,jsonSafe} from '../src/index.mjs';
test('normalizes optional and non-finite values for lossless DSH tool results',()=>{
 const value=jsonSafe({watchId:undefined,score:Number.NaN,nested:[undefined,Infinity,1n]});
 assert.deepEqual(value,{watchId:null,score:null,nested:[null,null,'1']});
});
test('returns the declared output object directly instead of wrapping it',()=>{
 const source=readFileSync(new URL('../src/index.mjs',import.meta.url),'utf8');
 assert.match(source,/execute:async\(a,e\)=>jsonSafe\(await execute\(a,e\)\)/);
 assert.doesNotMatch(source,/execute:async\(a,e\)=>\(\{result:/);
});
test('declares the second brain runtime dependency used by automatic replies',()=>{
 const manifest=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8'));
 assert.equal(manifest.peerDependencies['@opc/dsh-second-brain'],'^0.1.3');
 assert.equal(manifest.exports['./client'],'./lib/client.js');
 assert.equal(manifest.exports['./package.json'],'./package.json');
});
test('registers global preview tools once and restricts HTTP operations to local desktop',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'wechat-plugin-test-'));
 const tools=[],handlers=[],disposes=[];
 const ctx={root:{},tools:{register:t=>tools.push(t)},webServer:{register:r=>handlers.push(r)},systemPrompt:{section:()=>{}},on:(e,fn)=>disposes.push(fn)};
 try{
  apply(ctx,{stateDir:dir});apply(ctx,{stateDir:dir});
  assert.equal(tools.length,18);assert.equal(handlers.length,1);
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_style_learn'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_send'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_request_accessibility'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_global_preview'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_tags'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_tag_scope'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_candidate_draft'));
  assert.ok(tools.some(t=>t.name==='wechat_customer_service_analyze'));
  let code,body;const res={setHeader(){},writeHead:c=>code=c,end:x=>body=x};
  await handlers[0].handler({headers:{host:'evil.example'},method:'GET',url:'/plugins/ai-customer-service/status'},res);
  assert.equal(code,403);assert.match(body,/LOCAL_DESKTOP_REQUIRED/);
  await handlers[0].handler({headers:{host:'localhost:3080',origin:'https://evil.example'},method:'POST',url:'/plugins/ai-customer-service/send'},res);
  assert.equal(code,403);
 }finally{for(const fn of disposes)fn();rmSync(dir,{recursive:true,force:true});}
});
test('client registers a callable tab label and permission action',()=>{
 const source=readFileSync(new URL('../src/client.jsx',import.meta.url),'utf8');
 assert.match(source,/label:\(\)=>'AI 客服'/);
  assert.match(source,/request-accessibility/);
  assert.match(source,/监听范围：微信标签/);
  assert.match(source,/管理标签/);
  assert.match(source,/保存并开启监听/);
  assert.match(source,/填入微信/);
  assert.match(source,/替换为 AI 回复/);
});
test('built client registers with the DSH browser module loader',()=>{
 const client=readFileSync(new URL('../lib/client.js',import.meta.url),'utf8');
 assert.ok(client.startsWith('window.__ModuleLoader__.load({ id: "@opc/DSH-ai-customer-service"'));
 assert.match(client,/factory: \(require\) => \{/);
 assert.match(client,/return module\.exports;/);
});
test('dashboard exposes tag status and native failure states',()=>{
 const client=readFileSync(new URL('../src/client.jsx',import.meta.url),'utf8');
 const runtime=readFileSync(new URL('../src/index.mjs',import.meta.url),'utf8');
  assert.match(client,/WECHAT_TAGS_UNAVAILABLE/);
  assert.match(runtime,/tag-scope/);
  assert.match(runtime,/candidates\/draft/);
});
