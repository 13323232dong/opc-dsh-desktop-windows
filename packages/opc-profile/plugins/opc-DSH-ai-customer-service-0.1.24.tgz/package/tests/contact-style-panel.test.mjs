import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../src/contact-style-panel.jsx', import.meta.url), 'utf8');
// Exercise the actual request function without needing a browser JSX runtime.
function requestWith(fetch) {
  const functionSource = source.slice(source.indexOf('export async function requestStyle'), source.indexOf('\nfunction RelationshipSelect')).replace('export ', '');
  return vm.runInNewContext(`const base='/plugins/ai-customer-service'; ${functionSource}; requestStyle`, { fetch });
}

test('style requests use the guarded POST API and preserve user-selected relationship', async () => {
  let sent;
  const request = requestWith(async (url, options) => {
    sent = { url, options };
    return { ok: true, json: async () => ({ result: { contactId: 'alice' } }) };
  });
  const profile = await request('learn', { contact: 'Alice', relationship: 'unknown', pages: 1 });
  assert.equal(profile.contactId, 'alice');
  assert.equal(sent.url, '/plugins/ai-customer-service/style/learn');
  assert.equal(sent.options.method, 'POST');
  assert.equal(sent.options.headers['x-dsh-customer-service'], '1');
  assert.deepEqual(JSON.parse(sent.options.body), { contact: 'Alice', relationship: 'unknown', pages: 1 });
});

test('failed saves reject with the server error instead of reporting success', async () => {
  const request = requestWith(async () => ({ ok: false, json: async () => ({ error: { code: 'ACCOUNT_REQUIRED' } }) }));
  await assert.rejects(request('update', { contactId: 'alice' }), /ACCOUNT_REQUIRED/);
});

test('export endpoint supports unwrapped exports and empty list bodies', async () => {
  let sent;
  const request = requestWith(async (_url, options) => {
    sent = options;
    return { ok: true, json: async () => ({ samples: [] }) };
  });
  assert.deepEqual(await request('list'), { samples: [] });
  assert.equal(sent.body, '{}');
});

test('panel retains limited local previews, explicit delete confirmation and export cleanup', () => {
  assert.match(source, /samples\.slice\(0, 20\)/);
  assert.match(source, /window\.confirm/);
  assert.match(source, /URL\.revokeObjectURL\(url\)/);
  assert.match(source, /useState\('unknown'\)/);
  assert.match(source, /const pages = 1/);
  assert.match(source, /不代表完整聊天历史/);
});

test('account change ignores an old deferred response while the new account can load', async () => {
  const helper = source.slice(source.indexOf('export function createRequestScope'), source.indexOf('\nfunction useRequestScope')).replace('export ', '');
  const createScope = vm.runInNewContext(`${helper}; createRequestScope`);
  const oldAccount = createScope();
  let finishOld;
  let displayed = [];
  const oldRequest = new Promise(resolve => { finishOld = resolve; }).then(result => {
    if (oldAccount.isCurrent()) displayed = result;
  });
  oldAccount.invalidate();
  const newAccount = createScope();
  if (newAccount.isCurrent()) displayed = ['new account profile'];
  finishOld(['private old account profile']);
  await oldRequest;
  assert.deepEqual(displayed, ['new account profile']);
  newAccount.invalidate();
  assert.equal(newAccount.isCurrent(), false);
  assert.match(source, /key=\{accountId \|\| 'unconfirmed-account'\}/);
  assert.match(source, /if \(!requestScope\?\.isCurrent\(\)\) return/);
  assert.match(source, /loaded && profiles\.map/);
  assert.doesNotMatch(source, /accountId && profiles\.map/);
});

test('verified empty result is shown even when passive status has no account id', () => {
  assert.match(source, /loaded && !loading && !error && profiles\.length === 0/);
  assert.doesNotMatch(source, /accountId && loaded/);
  assert.match(source, /已学习联系人：\{profiles\.length\} 位/);
});

test('mounting does not verify WeChat or load records without an explicit click', () => {
  const panel = source.slice(source.indexOf('function AccountContactStylePanel'));
  assert.doesNotMatch(panel, /useEffect\(/);
  assert.match(panel, /onClick=\{loadProfiles\}/);
  assert.match(panel, /加载已学习联系人/);
  assert.match(panel, /const pages = 1/);
  assert.doesNotMatch(panel, /type="number"/);
  assert.match(panel, /不会自动翻页/);
});
