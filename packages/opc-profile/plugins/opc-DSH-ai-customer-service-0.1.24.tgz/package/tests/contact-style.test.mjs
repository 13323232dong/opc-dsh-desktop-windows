import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ContactStyleStore } from '../src/contact-style.mjs';

function fixture(t) {
 const directory=mkdtempSync(join(tmpdir(),'contact-style-'));
 t.after(()=>rmSync(directory,{recursive:true,force:true}));
 return {directory,store:new ContactStyleStore(directory)};
}
const contact={id:'contact-a',name:'测试联系人'};
const outgoing=(id,text)=>({id,text,direction:'outgoing'});
test('persists isolated accounts with private permissions and bounded list',t=>{
 const {store,directory}=fixture(t);
 const profile=store.learn({accountId:'a',contact,messages:[outgoing('1','好的')]});
 assert.equal(profile.relationship,'unknown');
 assert.equal(new ContactStyleStore(directory).get('a',contact.id).messages.length,1);
 assert.equal(store.get('b',contact.id),null);
 assert.deepEqual(store.list('b'),[]);
 assert.equal('messages' in store.list('a')[0],false);
 assert.equal(store.list('a')[0].examples.length,1);
 assert.equal(statSync(join(directory,'styles.json')).mode&0o777,0o600);
});
test('only own non-AI outgoing samples affect style and recapture deduplicates',t=>{
 const {store}=fixture(t);
 const messages=[outgoing('1','好的😊'),outgoing('2','好的😊'),outgoing('ai','AI文案'),{id:'3',text:'对方的长篇消息',direction:'incoming',timestampLabel:'昨天'}];
 const first=store.learn({accountId:'a',contact,messages,excludedMessageIds:['ai'],coverage:{fullHistory:true,complete:true,pagesRead:2,requestedPages:3,source:'wechat',timeLabels:['昨天']}});
 const second=store.learn({accountId:'a',contact,messages,excludedMessageIds:['ai']});
 assert.equal(second.messages.length,3);
 assert.equal(second.messages[2].direction,'incoming');
 assert.equal(second.messages[2].timestampLabel,'昨天');
 assert.equal(second.summary.totalMessageCount,3);
 assert.equal(second.summary.outgoingCount,2);
 assert.equal(second.summary.sampleCount,2);
 assert.equal(second.summary.emojiCount,2);
 assert.deepEqual(second.summary.frequentPhrases,[{text:'好的😊',count:2}]);
 assert.equal(first.coverage.fullHistory,false);
 assert.equal(first.coverage.complete,false);
 assert.equal(second.coverage.pagesRead,2);
 assert.equal(second.coverage.requestedPages,3);
 assert.equal(second.coverage.source,'wechat');
 assert.deepEqual(second.coverage.timeLabels,['昨天']);
 assert.equal(second.coverage.retainedMessageCount,3);
 assert.equal(second.coverage.retainedOutgoingCount,2);
 assert.notEqual(first.revision,second.revision);
 assert.ok(second.examples.every(m=>m.direction==='outgoing'));
});
test('explicit edits, exports and removal require same account and existing profile',t=>{
 const {store}=fixture(t);
 store.learn({accountId:'a',contact,messages:[]});
 assert.throws(()=>store.update('b',contact.id,{relationship:'work'}),/NOT_FOUND/);
 assert.throws(()=>store.remove('b',contact.id),/NOT_FOUND/);
 store.update('a',contact.id,{relationship:'family',styleNotes:'简短自然'});
 const exported=store.export('a',contact.id);
 assert.equal(exported.relationship,'family');
 exported.styleNotes='changed';
 assert.equal(store.get('a',contact.id).styleNotes,'简短自然');
 store.learn({accountId:'a',contact,messages:[]});
 assert.equal(store.get('a',contact.id).relationship,'family');
 store.remove('a',contact.id);
 assert.equal(store.get('a',contact.id),null);
 assert.throws(()=>store.export('a',contact.id),/NOT_FOUND/);
});
test('invalid boundaries are rejected without saving',t=>{
 const {store}=fixture(t);
 for(const accountId of ['',null,'../escape','a\n']) assert.throws(()=>store.get(accountId,'c'),/INVALID/);
 assert.throws(()=>store.learn({accountId:'a',contact,messages:[outgoing('1','x'.repeat(20001))]}),/INVALID/);
 assert.throws(()=>store.learn({accountId:'a',contact,messages:[],relationship:'boss'}),/INVALID/);
 assert.throws(()=>store.learn({accountId:'a',contact,messages:[{text:'missing id',direction:'outgoing'}]}),/INVALID/);
 assert.deepEqual(store.list('a'),[]);
});
test('sample limits and retroactive exclusions apply to retained history',t=>{
 const {store}=fixture(t);
 store.learn({accountId:'a',contact,messages:Array.from({length:2100},(_,i)=>outgoing(String(i),'hello'))});
 assert.equal(store.get('a',contact.id).messages.length,2000);
 assert.equal(store.get('a',contact.id).examples.length,8);
 const result=store.learn({accountId:'a',contact,messages:[],excludedMessageIds:['2099']});
 assert.equal(result.messages.length,1999);
});
