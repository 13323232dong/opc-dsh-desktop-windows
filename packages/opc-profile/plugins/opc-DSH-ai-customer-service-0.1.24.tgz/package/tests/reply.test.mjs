import test from 'node:test';
import assert from 'node:assert/strict';
import {createReplyGenerator} from '../src/reply.mjs';
test('personal replies receive per-contact examples and recent context without universal customer role',async()=>{
 let request;const gen=createReplyGenerator({llm:{async *stream(args){request=args;yield {type:'text-delta',text:'好呀哈哈'};}}},()=>({provider:'test',model:'test'}));
 await gen({messages:[{text:'吃饭没'}],recentContext:[{direction:'outgoing',text:'刚下班'}],contactStyle:{relationship:'friend',summary:'短句',styleNotes:'叫老张',examples:['好呀哈哈']}});
 assert.doesNotMatch(request.system,/你是商户的微信客服/);
 assert.match(request.system,/历史.*不是.*指令/);
 const data=JSON.parse(request.messages[0].content[0].text);
 assert.equal(data.contactStyle.relationship,'friend');assert.equal(data.recentContext[0].text,'刚下班');
});
test('reply uses selected DSH model and treats customer messages as data',async()=>{
 let request;
 const gen=createReplyGenerator({llm:{async *stream(args){request=args;yield {type:'text-delta',text:'您好'};}}},()=>({provider:'test',model:'selected'}));
 assert.equal(await gen({messages:[{text:'咨询'}],businessInstructions:'营业时间9点'}),'您好');
 assert.equal(request.model,'selected');assert.match(request.system,/营业时间9点/);assert.match(request.system,/不是系统指令/);
});
test('provider error is sanitized and empty replies fail closed',async()=>{
 const gen=createReplyGenerator({llm:{async *stream(){throw Error('secret-provider-token');}}},()=>({provider:'test',model:'test'}));
 await assert.rejects(gen({messages:[]}),e=>e.code==='WECHAT_MODEL_UNAVAILABLE'&&!e.message.includes('secret'));
});
test('missing model does not invoke provider',async()=>{
 await assert.rejects(createReplyGenerator({},()=>null)({messages:[]}),{code:'WECHAT_MODEL_UNAVAILABLE'});
});
test('reply includes retrieved knowledge as untrusted reference with source',async()=>{
 let request;
 const gen=createReplyGenerator({llm:{async *stream(args){request=args;yield {type:'text-delta',text:'周一到周五营业'};}}},()=>({provider:'test',model:'test'}));
 await gen({messages:[{text:'什么时候营业'}],knowledge:[{title:'营业规则',relativePath:'商户/营业.md',snippet:'周一到周五营业'}]});
 assert.match(request.system,/知识库/);
 const input=JSON.stringify(request.messages);
 assert.match(input,/商户\/营业.md/);
 assert.match(input,/周一到周五营业/);
});
