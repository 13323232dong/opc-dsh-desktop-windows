import test from 'node:test';
import assert from 'node:assert/strict';
import { createJevAnalyzer, JEV_MODEL } from '../src/jev.mjs';

const assessmentResponse={
  model:JEV_MODEL,
  answers:{
    intent:{type:'choice',choice:'报价',probabilities:{咨询:0.12,报价:0.78,预约:0.04,售后:0.02,投诉:0.01,闲聊:0.01,其他:0.02},confidence:0.67},
    purchase_intent:{type:'noul',noul:0.72},
    urgency:{type:'choice',choice:'近期',probabilities:{不紧急:0.15,近期:0.72,紧急:0.13},confidence:0.51},
    recommended_action:{type:'choice',choice:'提供报价范围',probabilities:{直接回答:0.1,追问需求:0.1,提供报价范围:0.7,转人工:0.04,安抚投诉:0.03,无需跟进:0.03},confidence:0.58},
    risk:{type:'choice',choice:'低',probabilities:{低:0.84,中:0.13,高:0.03},confidence:0.72},
  },
  usage:{input_tokens:123,output_tokens:45},
};
function response({status=200,body=assessmentResponse}={}) { return {status,ok:status>=200&&status<300,text:async()=>typeof body==='string'?body:JSON.stringify(body)}; }

test('maps typed Jev answers into a UI-safe customer assessment and sends only bounded context',async()=>{
 let requested;
 const analyze=createJevAnalyzer({getKey:async()=> 'secret-not-to-leak',fetch:async(_url,options)=>{requested=options;return response();}});
 const result=await analyze({message:'能今天上门吗？',recentContext:Array.from({length:12},(_,i)=>({direction:'incoming',text:`历史${i}:${'x'.repeat(800)}`})),contact:{name:'张三'},businessInstructions:'维修服务'});
 assert.equal(result.intent.choice,'报价');
 assert.equal(result.purchaseIntent,0.72);
 assert.equal(result.urgency.choice,'近期');
 assert.equal(result.recommendedAction.choice,'提供报价范围');
 assert.equal(result.risk.choice,'低');
 assert.equal(result.model,JEV_MODEL);
 const request=JSON.parse(requested.body);
 assert.equal(request.model,JEV_MODEL);
 assert.equal(request.state.message,'能今天上门吗？');
 assert.equal(request.state.recentContext.length,8);
 assert.ok(request.state.recentContext.every(item=>item.text.length<=500));
 assert.equal(JSON.stringify(request).includes('secret-not-to-leak'),false);
 assert.equal(requested.headers.Authorization,'Bearer secret-not-to-leak');
});

test('returns stable, secret-free codes for unavailable key, rejected API, invalid JSON and invalid answers',async()=>{
 const unavailable=createJevAnalyzer({getKey:async()=>''});
 await assert.rejects(()=>unavailable({message:'hello'}),error=>error.code==='JEV_KEY_UNAVAILABLE'&&!error.message.includes('secret'));
 const rejected=createJevAnalyzer({getKey:async()=> 'secret',fetch:async()=>response({status:401,body:{error:'bad key secret'}})});
 await assert.rejects(()=>rejected({message:'hello'}),error=>error.code==='JEV_API_REJECTED'&&!error.message.includes('secret'));
 const invalidJson=createJevAnalyzer({getKey:async()=> 'secret',fetch:async()=>response({body:'not json'})});
 await assert.rejects(()=>invalidJson({message:'hello'}),error=>error.code==='JEV_RESPONSE_INVALID');
 const invalidAnswers=createJevAnalyzer({getKey:async()=> 'secret',fetch:async()=>response({body:{model:JEV_MODEL,answers:{}}})});
 await assert.rejects(()=>invalidAnswers({message:'hello'}),error=>error.code==='JEV_RESPONSE_INVALID');
});

test('maps network failures and aborts to a stable unavailable code',async()=>{
 const analyzer=createJevAnalyzer({getKey:async()=> 'secret',fetch:async()=>{throw new Error('network down');}});
 await assert.rejects(()=>analyzer({message:'hello'}),error=>error.code==='JEV_API_UNAVAILABLE');
});
