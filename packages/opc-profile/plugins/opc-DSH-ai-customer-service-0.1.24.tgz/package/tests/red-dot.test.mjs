import test from 'node:test';
import assert from 'node:assert/strict';
import { scanRedDot } from '../src/adapters/vision/red-dot.mjs';

const image = (width, height, points = []) => {
  const data = new Uint8Array(width * height * 4);
  data.fill(255);
  for (const [x, y] of points) {
    const offset = (y * width + x) * 4;
    data[offset] = 240; data[offset + 1] = 20; data[offset + 2] = 20; data[offset + 3] = 255;
  }
  return { width, height, data };
};

test('red dot scanner distinguishes no unread and unread', () => {
  assert.equal(scanRedDot(image(10, 10)).hasUnread, false);
  assert.equal(scanRedDot(image(10, 10, Array.from({ length: 3 }, (_, n) => [n + 3, 4]))).hasUnread, true);
});

test('red dot touching crop edge requests retry', () => {
  const result = scanRedDot(image(10, 10, Array.from({ length: 10 }, (_, n) => [0, n])));
  assert.equal(result.edgeTouch, true);
  assert.equal(result.retryRecommended, true);
});

test('invalid image has a stable error code', () => {
  assert.throws(() => scanRedDot(Buffer.from('not-an-image')), error => error.code === 'VISION_IMAGE_INVALID');
});
