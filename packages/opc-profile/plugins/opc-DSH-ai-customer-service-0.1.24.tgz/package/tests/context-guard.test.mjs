import test from 'node:test';
import assert from 'node:assert/strict';
import { assertContext, contextFromContact } from '../src/context-guard.mjs';

test('context guard accepts the same account, window, contact and session', () => {
  const expected = contextFromContact({ accountId: 'a', name: '邹敏' }, 's');
  assert.equal(assertContext(expected, { ...expected }), true);
});

test('context guard rejects account or contact drift', () => {
  assert.throws(() => assertContext({ accountId: 'a', contactName: '邹敏' }, { accountId: 'b', contactName: '邹敏' }), /WECHAT_ACCOUNT_CHANGED/);
  assert.throws(() => assertContext({ accountId: 'a', contactName: '邹敏' }, { accountId: 'a', contactName: '文件传输助手' }), /WECHAT_CHAT_CONTEXT_CHANGED/);
});
