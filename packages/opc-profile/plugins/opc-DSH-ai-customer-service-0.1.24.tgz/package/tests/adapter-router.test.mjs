import test from 'node:test';
import assert from 'node:assert/strict';
import { adapterMethods } from '../src/adapters/adapter-contract.mjs';
import { AdapterRouter } from '../src/adapters/adapter-router.mjs';

const make = (fn) => Object.fromEntries(adapterMethods.map(method => [method, fn || (async () => ({ accountId: 'a' }))]));

test('accessibility is preferred and successful calls reset failures', async () => {
  let visionCalls = 0;
  const router = new AdapterRouter({ accessibility: make(), vision: make(async () => { visionCalls += 1; return { accountId: 'a' }; }) });
  const result = await router.listChats();
  assert.equal(result.adapterKind, 'accessibility');
  assert.equal(visionCalls, 0);
});

test('accessibility timeout falls back to vision and three failures pause', async () => {
  let calls = 0;
  const ax = make(async () => { throw Object.assign(new Error('timeout'), { code: 'WECHAT_HELPER_TIMEOUT' }); });
  const vision = make(async () => { calls += 1; throw Object.assign(new Error('bad image'), { code: 'VISION_TARGET_UNCERTAIN' }); });
  const router = new AdapterRouter({ accessibility: ax, vision });
  await assert.rejects(router.listChats(), /bad image/);
  await assert.rejects(router.listChats(), /bad image/);
  await assert.rejects(router.listChats(), error => error.code === 'VISION_ADAPTER_PAUSED');
  assert.equal(calls, 3);
});

test('successful status calls do not reset list scan failures', async () => {
  const ax = make(async () => ({ accountId: 'a' }));
  ax.listChats = async () => { throw Object.assign(new Error('timeout'), { code: 'WECHAT_HELPER_TIMEOUT' }); };
  const vision = make(async () => { throw Object.assign(new Error('unavailable'), { code: 'VISION_PROVIDER_UNAVAILABLE' }); });
  const router = new AdapterRouter({ accessibility: ax, vision });
  for (let attempt = 0; attempt < 2; attempt += 1) {
    await router.status();
    await assert.rejects(router.listChats(), /unavailable/);
  }
  await router.status();
  await assert.rejects(router.listChats(), error => error.code === 'VISION_ADAPTER_PAUSED');
});
