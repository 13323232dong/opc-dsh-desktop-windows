import test from 'node:test';
import assert from 'node:assert/strict';
import { MacWechatAdapter } from '../src/macos.mjs';
test('history forwards exact contact and bounded page request without send', async () => {
  const calls = [], result = { messages: [], coverage: { pagesRead: 1, complete: false } };
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return result;
  } });
  const contact = { accountId: 'account', title: '甲' };
  assert.equal(await adapter.readHistory(contact), result);
  assert.equal(await adapter.readHistory(contact, { pages: 5 }), result);
  assert.deepEqual(calls, [
    { method: 'readHistory', payload: { contact, pages: 1 } },
    { method: 'readHistory', payload: { contact, pages: 5 } },
  ]);
  for (const pages of [0, 6, 1.5, '2', NaN]) {
    await assert.rejects(adapter.readHistory(contact, { pages }), { code: 'WECHAT_HISTORY_PAGES_INVALID' });
  }
  assert.equal(calls.length, 2);
});
test('reject unsupported platform before transport', async () => {
  const adapter = new MacWechatAdapter({ platform: 'win32', transport: () => assert.fail('must not run') });
  await assert.rejects(adapter.status(), { code: 'WECHAT_PLATFORM_UNSUPPORTED' });
});
test('adapter preserves exact contact and text and stage callback', async () => {
  const calls = [], stages = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload, stage) => {
    calls.push({ method, payload }); stage?.('verifying'); return { status: 'unknown' };
  } });
  const contact = { contactId: 'account:邹敏', title: '邹敏', accountId: 'account' };
  assert.deepEqual(await adapter.send(contact, 'AI发送测试', { onStage: stage => stages.push(stage) }), { status: 'unknown' });
  assert.deepEqual(calls, [{ method: 'send', payload: { contact, text: 'AI发送测试' } }]);
  assert.deepEqual(stages, ['verifying']);
});
test('adapter exposes an explicit accessibility permission request', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return { ready: false, permissionRequested: true };
  } });
  assert.deepEqual(await adapter.requestAccessibility(), { ready: false, permissionRequested: true });
  assert.deepEqual(calls, [{ method: 'requestAccessibility', payload: {} }]);
});
test('missing helper produces stable error without raw process output', async () => {
  const adapter = new MacWechatAdapter({ platform: 'darwin', binaryPath: '/nonexistent/wechat-helper' });
  await assert.rejects(adapter.status(), { code: 'WECHAT_HELPER_UNAVAILABLE' });
});
test('status cache avoids repeatedly opening account popup but send remains fresh', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async method => {
    calls.push(method); return { ready: true, accountId: 'example' };
  } });
  await adapter.status(); await adapter.status(); await adapter.send('contact', 'text');
  assert.deepEqual(calls, ['status', 'send']);
});
test('adapter exposes read-only visible conversation previews', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({method,payload}); return { ready:true, processId:123, accountId: 'example', chats: [{ id: 'example:甲', title: '甲', preview: '你好' }] };
  } });
  await adapter.status();calls.length=0;
  await adapter.listChats();
  assert.deepEqual(calls, [{method:'probe',payload:{}},{method:'listChats',payload:{accountId:'example',processId:123}}]);
});
test('tag reads send the verified account and process identity to the helper', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload });
    if (method === 'probe' || method === 'status') return { ready: true, accountId: 'example', processId: 123 };
    return method === 'listTags' ? { accountId: 'example', tags: [] } : { accountId: 'example', contacts: [] };
  } });
  await adapter.status();
  await adapter.listTags();
  await adapter.listTagContacts(['lead', 'support']);
  assert.deepEqual(calls, [
    { method: 'status', payload: {} },
    { method: 'probe', payload: {} },
    { method: 'listTags', payload: { accountId: 'example', processId: 123 } },
    { method: 'listTagContacts', payload: { accountId: 'example', processId: 123, tagIds: ['lead', 'support'] } },
  ]);
});
test('tag contact reads reject invalid tag identifiers locally', async () => {
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async () => ({}) });
  await assert.rejects(adapter.listTagContacts([]), { code: 'WECHAT_TAG_SCOPE_EMPTY' });
  await assert.rejects(adapter.listTagContacts(['lead', 'lead']), { code: 'WECHAT_TAG_ID_INVALID' });
});
test('passive status never initializes account and detects a restarted WeChat process', async () => {
  let pid=123;const calls=[];
  const adapter=new MacWechatAdapter({platform:'darwin',transport:async method=>{calls.push(method);return {ready:true,processId:pid,...(method==='status'?{accountId:'a'}:{})};}});
  assert.equal((await adapter.peekStatus()).failureCode,'WECHAT_ACCOUNT_UNVERIFIED');
  assert.deepEqual(calls,['probe']);
  await adapter.status();pid=456;
  await assert.rejects(adapter.listChats(),{code:'WECHAT_ACCOUNT_UNVERIFIED'});
  assert.equal(adapter.statusCache,null);
  assert.equal(calls.filter(m=>m==='status').length,1);
});
test('adapter drafts into WeChat without invoking the send operation', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return { status: 'drafted', evidence: { kind: 'input_draft' } };
  } });
  await adapter.draft({ title: '甲' }, '您好');
  assert.deepEqual(calls, [{ method: 'draft', payload: { contact: { title: '甲' }, text: '您好' } }]);
});
test('adapter forwards draft replacement only when explicitly requested', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return { status: 'drafted', evidence: { kind: 'input_draft' } };
  } });
  await adapter.draft({ title: '甲' }, '您好', { replaceExisting: true });
  assert.deepEqual(calls, [{ method: 'draft', payload: { contact: { title: '甲' }, text: '您好', replaceExisting: true } }]);
});
