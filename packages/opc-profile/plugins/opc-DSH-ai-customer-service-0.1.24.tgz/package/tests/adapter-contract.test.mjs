import test from 'node:test';
import assert from 'node:assert/strict';
import { adapterMethods, assertAdapterContract } from '../src/adapters/adapter-contract.mjs';

const adapter = Object.fromEntries(adapterMethods.map(method => [method, async () => ({})]));

test('adapter contract requires the complete stable surface', () => {
  assert.equal(assertAdapterContract(adapter), adapter);
  assert.throws(() => assertAdapterContract({ status() {} }), error => error.code === 'WECHAT_ADAPTER_CONTRACT_INVALID' && error.missing.includes('sendAction'));
});
