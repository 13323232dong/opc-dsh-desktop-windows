import test from 'node:test';
import assert from 'node:assert/strict';
import { verifySendEvidence } from '../src/send-verifier.mjs';

test('new outgoing bubble and cleared composer are sent', () => {
  assert.equal(verifySendEvidence({
    before: [], after: [{ id: '1', direction: 'outgoing', text: '你好', createdAt: 10 }],
    expectedText: '你好', composer: '', sendStartedAt: 1,
  }), 'sent');
});

test('text left in composer is definite failure', () => {
  assert.equal(verifySendEvidence({ before: [], after: [], expectedText: '你好', composer: '你好' }), 'failed');
});

test('missing evidence is unknown and context drift is wrong_context', () => {
  assert.equal(verifySendEvidence({ before: [], after: [], expectedText: '你好', composer: '' }), 'unknown');
  assert.equal(verifySendEvidence({ contextChanged: true }), 'wrong_context');
});

test('id-less post-send bubbles cannot prove delivery', () => {
  assert.equal(verifySendEvidence({ before: [], after: [{ direction: 'outgoing', text: 'hello' }], expectedText: 'hello', composer: '' }), 'unknown');
});
