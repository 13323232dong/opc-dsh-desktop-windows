import { mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
if (process.platform !== 'darwin') {
  console.log('macOS helper build skipped on this platform');
} else {
  mkdirSync(`${root}native/bin`, { recursive: true });
  execFileSync('swiftc', ['-O', `${root}native/main.swift`, '-framework', 'AppKit', '-framework', 'ApplicationServices', '-o', `${root}native/bin/wechat-helper`], { stdio: 'inherit' });
}
