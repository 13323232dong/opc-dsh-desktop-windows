import { readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
for (const file of readdirSync('src').filter(x=>x.endsWith('.mjs'))) execFileSync(process.execPath,['--check',`src/${file}`],{stdio:'inherit'});
