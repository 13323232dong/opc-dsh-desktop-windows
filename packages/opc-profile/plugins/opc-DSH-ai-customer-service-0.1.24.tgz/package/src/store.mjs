import { mkdirSync, readFileSync, openSync, writeFileSync, fsyncSync, closeSync, renameSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { userInfo } from 'node:os';

export class Store {
 constructor(directory) {
  if(typeof directory!=='string'||!directory) throw new Error('STATE_DIRECTORY_REQUIRED');
  mkdirSync(directory,{recursive:true,mode:0o700});
  this.directory=directory; this.path=join(directory,'customer-service.json');
  this.owner=String(userInfo().uid);
  this.lockPath=join(directory,'worker.lock'); this.lockToken=randomUUID(); this.locked=false;
 }
 acquire() {
  if(this.locked)return true;
  try {mkdirSync(this.lockPath,{mode:0o700});}
  catch(error) {
   if(error.code!=='EEXIST')throw error;
   try {
    const owner=JSON.parse(readFileSync(join(this.lockPath,'owner.json'),'utf8'));
    try {process.kill(owner.pid,0);return false;}catch(probe){if(probe.code!=='ESRCH')return false;}
    rmSync(this.lockPath,{recursive:true});return this.acquire();
   } catch {return false;}
  }
  writeFileSync(join(this.lockPath,'owner.json'),JSON.stringify({pid:process.pid,token:this.lockToken}),{mode:0o600});
  this.locked=true;return true;
 }
 release() {
  if(!this.locked)return;
  try {
   const owner=JSON.parse(readFileSync(join(this.lockPath,'owner.json'),'utf8'));
   if(owner.token===this.lockToken)rmSync(this.lockPath,{recursive:true});
  } catch(error) {if(error.code!=='ENOENT')throw error;}
  this.locked=false;
 }
 read() {
  try {
   const state=JSON.parse(readFileSync(this.path,'utf8'));
   if(![1,2].includes(state.version)||state.owner!==this.owner||!Array.isArray(state.tasks)||!Array.isArray(state.watches)) throw new Error('STATE_INVALID');
    return {
      ...state,
      version: 2,
      globalPreview: state.globalPreview && typeof state.globalPreview === 'object'
        ? {
            adapterKind: 'router',
            stage: 'idle',
            baselineVersion: '',
            lastScanAt: null,
            consecutiveFailures: 0,
            ...state.globalPreview,
          }
        : {
            enabled: false,
            accountId: '',
            adapterKind: 'router',
            stage: 'idle',
            baselineVersion: '',
            baseline: {},
            events: [],
            lastScanAt: null,
            consecutiveFailures: 0,
            failureCode: null,
          },
    };
  } catch(error) {
   if(error.code==='ENOENT') return {
     version: 2,
     owner: this.owner,
     tasks: [],
     watches: [],
     globalPreview: {
       enabled: false,
       accountId: '',
       adapterKind: 'router',
       stage: 'idle',
       baselineVersion: '',
       baseline: {},
       events: [],
       lastScanAt: null,
       consecutiveFailures: 0,
       failureCode: null,
     },
   };
   throw error;
  }
 }
 write(state) {
  const temp=join(this.directory,`.state-${randomUUID()}.tmp`);
  const fd=openSync(temp,'wx',0o600);
  try { writeFileSync(fd,JSON.stringify(state)); fsyncSync(fd); } finally { closeSync(fd); }
  renameSync(temp,this.path);
  const dir=openSync(this.directory,'r');
  try { fsyncSync(dir); } finally { closeSync(dir); }
 }
}
