import { homedir } from 'node:os';
import { join } from 'node:path';
import { mkdirSync,readFileSync,writeFileSync,renameSync } from 'node:fs';
import { defineTool } from '@deepseek-ai/dsh-tools';
import z from '@deepseek-ai/schemastery';
import { CustomerService } from './core.mjs';
import { MacWechatAdapter } from './macos.mjs';
import { AdapterRouter } from './adapters/adapter-router.mjs';
import { createUnavailableVisionAdapter } from './adapters/vision/sightflow-vision.mjs';
import { createReplyGenerator } from './reply.mjs';
import { createKnowledgeReplyGenerator, createSecondBrainSearch } from './knowledge.mjs';
import { createJevAnalyzer } from './jev.mjs';
export const name='ai-customer-service';
export const inject=['tools','webServer','systemPrompt','llm'];
export const Config=z.object({stateDir:z.string().default('')});
const installed=new WeakSet();
// DSH validates tool results as lossless JSON. Persisted task records contain
// optional fields, so normalize undefined/non-finite values at the boundary.
export function jsonSafe(value) {
  if (value === undefined) return null;
  if (typeof value === 'number' && !Number.isFinite(value)) return null;
  if (typeof value === 'bigint') return value.toString();
  if (Array.isArray(value)) return value.map(jsonSafe);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, jsonSafe(item)]));
  }
  return value;
}
export function apply(ctx,config={}) {
  if(installed.has(ctx.root)) return;
  installed.add(ctx.root);
  const stateDir=config.stateDir||join(homedir(),'Library','Application Support','DSH-ai-customer-service');
  mkdirSync(stateDir,{recursive:true,mode:0o700});
  const routeFile=join(stateDir,'model-route.json');
  let modelRoute={};
  try { modelRoute=JSON.parse(readFileSync(routeFile,'utf8')); } catch{}
  const replyGenerator=createKnowledgeReplyGenerator({search:createSecondBrainSearch(),reply:createReplyGenerator(ctx,contact=>modelRoute[contact?.name]||modelRoute.__global_preview__)});
  const accessibility=new MacWechatAdapter();
  const adapter=new AdapterRouter({accessibility,vision:createUnavailableVisionAdapter()});
  const service=new CustomerService({stateDir,adapter,replyGenerator,jevAnalyzer:createJevAnalyzer()});
  const fields={contact:{type:'string',required:true,description:'微信联系人精确名称'}};
  const specs=[
    ['style_list','查看当前微信账号已学习的联系人回复习惯',{},()=>service.styleAction('list')],
    ['style_learn','读取指定联系人已加载的聊天并学习本人回复习惯，不发送；历史保存在本机，生成回复时参考片段会交给当前模型',{...fields,relationship:{type:'string',enum:['work','friend','family','unknown']},pages:{type:'integer',description:'请求读取页数1至5；当前适配器只保证已加载一页，返回实际范围'}},a=>service.learnStyle(a)],
    ['style_update','修改联系人关系和回复习惯说明',{contactId:{type:'string',required:true},relationship:{type:'string',enum:['work','friend','family','unknown']},styleNotes:{type:'string'}},a=>service.styleAction('update',a)],
    ['style_delete','按用户要求删除该联系人的本地学习数据',{contactId:{type:'string',required:true}},a=>service.styleAction('delete',a)],
    ['style_export','读取该联系人的本地聊天学习记录供导出；不发送',{contactId:{type:'string',required:true}},a=>service.styleAction('export',a)],
    ['status','查看微信连接、客服状态及错误',{},()=>service.status()],
    ['tags','读取微信原生标签及联系人数量；只读诊断，不修改微信',{},()=>service.tags()],
    ['tag_scope','按微信原生标签开启或停止监听；多标签联系人按稳定 ID 去重，只生成候选不写入微信',{enabled:{type:'boolean',required:true},tagIds:{type:'array',items:{type:'string'}},businessInstructions:{type:'string'},style:{type:'string'}},(a,e)=>{
      const agent=e?.agent;const header=agent?.session?.requestHeader?.()?.config;const provider=agent?.options?.provider||header?.provider;const model=agent?.options?.model||header?.model;
      if(a.enabled&&(!provider||!model))throw new Error('WECHAT_MODEL_UNAVAILABLE');
      if(provider&&model){modelRoute={...modelRoute,__global_preview__:{provider,model}};writeFileSync(`${routeFile}.tmp`,JSON.stringify(modelRoute),{mode:0o600});renameSync(`${routeFile}.tmp`,routeFile);}
      return service.tagScope(a);
    }],
    ['candidate_draft','将用户选中的候选回复填入核对后的微信输入框；已有草稿必须显式确认替换，不自动发送',{eventId:{type:'string',required:true},candidateId:{type:'string',required:true},replaceExisting:{type:'boolean'}},a=>service.draftCandidate(a)],
    ['request_accessibility','打开 macOS 辅助功能授权入口；用户需要在系统设置中手动允许',{},()=>service.adapter.requestAccessibility()],
    ['find_contact','搜索微信联系人，不发送',fields,a=>service.findContact(a.contact)],
    ['read_chat','读取指定微信会话',fields,a=>service.readChat(a.contact)],
    ['analyze','使用 Jev 仅分析当前来信的意图、购买/预约可能、紧急程度、建议动作和业务风险；不生成、不写入、不发送微信',{...fields,message:{type:'string',description:'可选；省略时仅读取当前会话最新一条来信'},businessInstructions:{type:'string',description:'可选的业务资料，仅用于本次判断'}},a=>service.analyze(a)],
    ['send','执行用户已明确要求的微信发送，后台校验后入队；不需要重复确认',{...fields,text:{type:'string',required:true},requestId:{type:'string',required:true,description:'同一次发送重试必须使用相同请求ID'}},(a,e)=>service.send({...a,sessionId:String(e?.agent?.session?.id??'desktop')})],
    ['watch','用户指定联系人并要求自动回复后开启托管；关闭可用 enabled=false',{...fields,enabled:{type:'boolean',required:true},businessInstructions:{type:'string'},style:{type:'string'}},(a,e)=>{
      const agent=e?.agent; const header=agent?.session?.requestHeader?.()?.config;
      const provider=agent?.options?.provider||header?.provider; const model=agent?.options?.model||header?.model;
      if(a.enabled && (!provider||!model)) throw new Error('WECHAT_MODEL_UNAVAILABLE');
      if(provider&&model) {modelRoute={...modelRoute,[a.contact]:{provider,model}};writeFileSync(`${routeFile}.tmp`,JSON.stringify(modelRoute),{mode:0o600});renameSync(`${routeFile}.tmp`,routeFile);}
      return service.watch(a);
    }],
    ['global_preview','开启或停止全局微信未读消息监听；新消息仅生成草稿并写入微信输入框，绝不发送',{enabled:{type:'boolean',required:true},businessInstructions:{type:'string'},style:{type:'string'}},(a,e)=>{
      const agent=e?.agent;const header=agent?.session?.requestHeader?.()?.config;
      const provider=agent?.options?.provider||header?.provider;const model=agent?.options?.model||header?.model;
      if(a.enabled&&(!provider||!model))throw new Error('WECHAT_MODEL_UNAVAILABLE');
      if(provider&&model){modelRoute={...modelRoute,__global_preview__:{provider,model}};writeFileSync(`${routeFile}.tmp`,JSON.stringify(modelRoute),{mode:0o600});renameSync(`${routeFile}.tmp`,routeFile);}
      return service.globalPreview(a);
    }],
    ['pause','暂停指定微信联系人的自动客服',fields,a=>service.pause(a.contact)],
    ['tasks','查询微信发送任务状态；sent仅表示客户端显示已发送',{},()=>service.tasks()],
  ];
  for(const [suffix,description,parameters,execute] of specs) ctx.tools.register(defineTool({name:`wechat_customer_service_${suffix}`,description:`【AI 客服】${description}`,parameters,
    output:{schema:['tasks','style_list'].includes(suffix)?{type:'array',items:{type:'object',additionalProperties:true}}:{type:'object',additionalProperties:true},render:(_a,result)=>[{type:'text',text:JSON.stringify(result)}]},
    execute:async(a,e)=>jsonSafe(await execute(a,e)),
  }));
  ctx.systemPrompt.section({name:'ai-customer-service:routing',order:125,text:'Mac 桌面微信及 AI 客服优先调用 wechat_customer_service_* 工具，无需 device_id。用户明确指定收件人和消息即为本次发送授权，不重复确认；开启指定联系人托管即授权该联系人的自动回复。用户要求全局监听但尚未授权发送时，调用 wechat_customer_service_global_preview：它只能将草稿写入微信输入框，绝不发送。WECHAT_ACCESSIBILITY_REQUIRED 时调用 wechat_customer_service_request_accessibility 打开系统授权入口，并明确等待用户在系统设置中允许。发送返回 queued 时继续查询 tasks，不得说已发送；只有 sent 才可说微信客户端显示已发送，unknown 不重试。不得调用旧 Android 微信工具代替本插件。'});
  ctx.webServer.register({kind:'prefix',path:'/plugins/ai-customer-service',handler:async(req,res)=>{
    res.setHeader('content-type','application/json; charset=utf-8');res.setHeader('cache-control','no-store');
    // Local desktop service only; reject browser requests from other origins.
    const host=req.headers.host??''; const origin=req.headers.origin;
    if(!/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host) || (origin && origin!==`http://${host}`)) {res.writeHead(403);res.end(JSON.stringify({error:'LOCAL_DESKTOP_REQUIRED'}));return;}
    try{
      const path=new URL(req.url,'http://localhost').pathname;
      if(req.method==='GET'&&path==='/plugins/ai-customer-service/status'){res.end(JSON.stringify(await service.status()));return;}
      if(req.method==='GET'&&path==='/plugins/ai-customer-service/tags'){res.end(JSON.stringify({result:await service.tags()}));return;}
      if(req.method!=='POST' || req.headers['x-dsh-customer-service']!=='1'){res.writeHead(405);res.end('{}');return;}
      let body='';for await(const part of req){body+=part;if(Buffer.byteLength(body)>16384)throw new Error('REQUEST_TOO_LARGE');}
      const args=JSON.parse(body||'{}'); let result;
      if(path==='/plugins/ai-customer-service/style/learn')result=await service.learnStyle(args);
      else if(/^\/plugins\/ai-customer-service\/style\/(list|update|delete|export)$/.test(path))result=await service.styleAction(path.split('/').at(-1),args);
      else if(path.endsWith('/tasks/clear-failed')) result=service.clearFailedTasks();
      else if(path.endsWith('/request-accessibility')) result=await service.adapter.requestAccessibility();
      else if(path.endsWith('/analyze')) result=await service.analyze(args);
      else if(path.endsWith('/send')) result=await service.send(args);
      else if(path.endsWith('/global-preview')) result=await service.globalPreview(args);
      else if(path.endsWith('/tag-scope')) result=await service.tagScope(args);
      else if(path.endsWith('/candidates/draft')) result=await service.draftCandidate(args);
      else if(path.endsWith('/pause')) result=await service.pause(args.contact);
      else if(path.endsWith('/watch')) {if(args.enabled&&!modelRoute[typeof args.contact==='string'?args.contact:args.contact?.name])throw new Error('WECHAT_MODEL_UNAVAILABLE: 请先在DSH对话为该联系人开启客服以选择模型');result=await service.watch(args);}
      else {res.writeHead(404);res.end('{}');return;}
      res.end(JSON.stringify({result}));
    }catch(error){res.writeHead(400);res.end(JSON.stringify({error:error.code||'CUSTOMER_SERVICE_ERROR',message:error.code?'请查看工具状态中的诊断信息':String(error.message).slice(0,180)}));}
  }});
  service.start();
  ctx.on('dispose',()=>{service.stop();installed.delete(ctx.root);});
}
