import { mkdirSync, readFileSync, openSync, writeFileSync, fsyncSync, closeSync, renameSync, unlinkSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';

const relationships=new Set(['work','friend','family','unknown']);
function text(value,max,empty=false) {
 if(typeof value!=='string'||value.length>max||(!empty&&!value.trim())||value.includes('\0')) throw new Error('CONTACT_STYLE_INVALID_TEXT');
 return value;
}
function key(value) {
 text(value,512);
 if(/[\x00-\x1f\x7f/\\]/.test(value)||value==='.'||value==='..') throw new Error('CONTACT_STYLE_INVALID_KEY');
 return value;
}
function relationship(value) {
 if(!relationships.has(value)) throw new Error('CONTACT_STYLE_INVALID_RELATIONSHIP');
 return value;
}
function summarize(messages) {
 const lengths=messages.map(m=>[...m.text].length);
 const counts=new Map();
 for(const {text:body} of messages) {
  const phrase=body.trim();
  if([...phrase].length<=40) counts.set(phrase,(counts.get(phrase)||0)+1);
 }
 return {
  sampleCount:messages.length,
  shortCount:lengths.filter(n=>n<=20).length,
  longCount:lengths.filter(n=>n>=80).length,
  averageLength:lengths.length?Math.round(lengths.reduce((a,b)=>a+b,0)/lengths.length):0,
  emojiCount:messages.reduce((n,m)=>n+(m.text.match(/\p{Extended_Pictographic}/gu)||[]).length,0),
  frequentPhrases:[...counts].filter(([,count])=>count>=2).sort((a,b)=>b[1]-a[1]||(a[0]<b[0]?-1:a[0]>b[0]?1:0)).slice(0,8).map(([text,count])=>({text,count})),
  basis:'统计已加载的本人出站消息，排除仍有记录可识别的 AI 文案；无法识别全部历史 AI 来源。短句 ≤20 字，长句 ≥80 字；常用语为重复出现的 ≤40 字完整消息，不代表完整历史。',
 };
}
function sample(message,contactId) {
 if(!message||typeof message!=='object') throw new Error('CONTACT_STYLE_INVALID_MESSAGE');
 key(message.id);
 if(!['incoming','outgoing'].includes(message.direction)) throw new Error('CONTACT_STYLE_INVALID_DIRECTION');
 text(message.text,20000,true);
 if(message.contactId!==undefined&&message.contactId!==contactId) throw new Error('CONTACT_STYLE_INVALID_CONTACT');
 return {id:message.id,direction:message.direction,text:message.text,...(message.timestampLabel!==undefined?{timestampLabel:text(message.timestampLabel,500,true)}:{})};
}
function coverageFor(coverage,count,outgoingCount) {
 if(coverage!==undefined&&(!coverage||typeof coverage!=='object'||Array.isArray(coverage))) throw new Error('CONTACT_STYLE_INVALID_COVERAGE');
 const result={scope:'loaded_messages',fullHistory:false,complete:false,retainedMessageCount:count,retainedOutgoingCount:outgoingCount};
 for(const field of ['start','end','from','to','loadedAt','description']) {
  if(coverage?.[field]!==undefined) result[field]=text(String(coverage[field]),1000,true);
 }
 for(const field of ['pagesRead','requestedPages']) {
  if(coverage?.[field]!==undefined) {
   if(!Number.isInteger(coverage[field])||coverage[field]<0||coverage[field]>10000) throw new Error('CONTACT_STYLE_INVALID_COVERAGE');
   result[field]=coverage[field];
  }
 }
 if(coverage?.source!==undefined) result.source=text(coverage.source,500,true);
 if(coverage?.timeLabels!==undefined) {
  if(!Array.isArray(coverage.timeLabels)||coverage.timeLabels.length>2000) throw new Error('CONTACT_STYLE_INVALID_COVERAGE');
  result.timeLabels=coverage.timeLabels.map(label=>text(label,500,true));
 }
 return result;
}

export class ContactStyleStore {
 constructor(directory) {
  text(directory,4096);
  mkdirSync(directory,{recursive:true,mode:0o700});
  this.directory=directory;
  this.path=join(directory,'styles.json');
 }
 read() {
  try {
   const state=JSON.parse(readFileSync(this.path,'utf8'));
   if(state.version!==1||!Array.isArray(state.profiles)) throw new Error('CONTACT_STYLE_STATE_INVALID');
   return state.profiles;
  } catch(error) {if(error.code==='ENOENT') return [];throw error;}
 }
 write(profiles) {
  const temporary=join(this.directory,`.styles-${randomUUID()}.tmp`);
  const fd=openSync(temporary,'wx',0o600);
  try {
   try {writeFileSync(fd,JSON.stringify({version:1,profiles}));fsyncSync(fd);} finally {closeSync(fd);}
   renameSync(temporary,this.path);
   const dir=openSync(this.directory,'r');
   try {fsyncSync(dir);} finally {closeSync(dir);}
  } catch(error) {try {unlinkSync(temporary);} catch {} throw error;}
 }
 get(accountId,contactId) {
  key(accountId);key(contactId);
  return this.read().find(p=>p.accountId===accountId&&p.contact.id===contactId)||null;
 }
 list(accountId) {
  key(accountId);
  return this.read().filter(p=>p.accountId===accountId).map(({messages,...profile})=>profile);
 }
 learn({accountId,contact,messages,coverage,relationship:chosenRelationship,excludedMessageIds=[]}={}) {
  key(accountId);key(contact?.id);text(contact?.name,500);
  if(!Array.isArray(messages)||messages.length>10000||!Array.isArray(excludedMessageIds)||excludedMessageIds.length>10000) throw new Error('CONTACT_STYLE_INVALID_MESSAGES');
  if(chosenRelationship!==undefined) relationship(chosenRelationship);
  const excluded=new Set(excludedMessageIds.map(key));
  const normalized=messages.map(m=>sample(m,contact.id));
  const profiles=this.read();
  const previous=profiles.find(p=>p.accountId===accountId&&p.contact.id===contact.id);
  const retained=new Map();
  for(const message of [...(previous?.messages||[]),...normalized]) {
   if(message.text.trim()&&!(message.direction==='outgoing'&&excluded.has(message.id))) retained.set(message.id,message);
  }
  const archive=[...retained.values()].slice(-2000);
  const own=archive.filter(message=>message.direction==='outgoing');
  const profile={accountId,contact:{id:contact.id,name:contact.name},relationship:chosenRelationship??previous?.relationship??'unknown',styleNotes:previous?.styleNotes||'',summary:{...summarize(own),totalMessageCount:archive.length,outgoingCount:own.length},examples:own.slice(-8),messages:archive,coverage:coverageFor(coverage??previous?.coverage,archive.length,own.length),updatedAt:new Date().toISOString(),revision:randomUUID()};
  this.write([...profiles.filter(p=>p.accountId!==accountId||p.contact.id!==contact.id),profile]);
  return structuredClone(profile);
 }
 update(accountId,contactId,patch) {
  key(accountId);key(contactId);
  if(!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(k=>!['relationship','styleNotes'].includes(k))) throw new Error('CONTACT_STYLE_INVALID_PATCH');
  const updates={};
  if(patch.relationship!==undefined) updates.relationship=relationship(patch.relationship);
  if(patch.styleNotes!==undefined) updates.styleNotes=text(patch.styleNotes,4000,true);
  const profiles=this.read();
  const previous=profiles.find(p=>p.accountId===accountId&&p.contact.id===contactId);
  if(!previous) throw new Error('CONTACT_STYLE_NOT_FOUND');
  const profile={...previous,...updates,updatedAt:new Date().toISOString(),revision:randomUUID()};
  this.write(profiles.map(p=>p===previous?profile:p));
  return structuredClone(profile);
 }
 remove(accountId,contactId) {
  key(accountId);key(contactId);
  const profiles=this.read();
  const remaining=profiles.filter(p=>p.accountId!==accountId||p.contact.id!==contactId);
  if(remaining.length===profiles.length) throw new Error('CONTACT_STYLE_NOT_FOUND');
  this.write(remaining);
  return {removed:true,accountId,contactId};
 }
 export(accountId,contactId) {
  const profile=this.get(accountId,contactId);
  if(!profile) throw new Error('CONTACT_STYLE_NOT_FOUND');
  return profile;
 }
}
