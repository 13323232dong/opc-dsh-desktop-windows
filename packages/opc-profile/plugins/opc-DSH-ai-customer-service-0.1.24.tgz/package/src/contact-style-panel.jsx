import React, { useEffect, useRef, useState } from 'react';

const base = '/plugins/ai-customer-service';
const relationships = { unknown: '尚未设置', work: '工作', friend: '朋友', family: '家人' };

export function createRequestScope() {
  let active = true;
  return { isCurrent: () => active, invalidate: () => { active = false; } };
}

function useRequestScope() {
  const scope = useRef(null);
  useEffect(() => {
    const current = createRequestScope();
    scope.current = current;
    return () => current.invalidate();
  }, []);
  return scope;
}

export async function requestStyle(action, args = {}) {
  const response = await fetch(`${base}/style/${action}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-dsh-customer-service': '1' },
    body: JSON.stringify(args),
  });
  const body = await response.json();
  if (!response.ok || body.error) {
    const detail = body.error?.message || body.error?.code || body.message || body.error;
    throw new Error(typeof detail === 'string' ? detail : '请求未完成，请稍后重试');
  }
  return body.result ?? body;
}

function RelationshipSelect({ value, onChange, disabled, label }) {
  return <select aria-label={label} value={value} disabled={disabled} onChange={event => onChange(event.target.value)}>
    {Object.entries(relationships).map(([key, text]) => <option key={key} value={key}>{text}</option>)}
  </select>;
}

function ContactProfile({ profile, disabled, onChanged }) {
  const scope = useRequestScope();
  const contactId = profile.contact?.id || profile.contactId || profile.id;
  const name = typeof profile.contact === 'string' ? profile.contact : profile.contact?.name || profile.contactName || profile.name || contactId;
  const [relationship, setRelationship] = useState(profile.relationship || 'unknown');
  const [styleNotes, setStyleNotes] = useState(profile.styleNotes || '');
  const [pending, setPending] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [preview, setPreview] = useState(null);
  useEffect(() => {
    setRelationship(profile.relationship || 'unknown');
    setStyleNotes(profile.styleNotes || '');
  }, [profile]);

  async function act(action) {
    if (action === 'delete' && !window.confirm(`删除「${name}」的本地回复习惯和学习记录？`)) return;
    setPending(action); setMessage(''); setError('');
    const requestScope = scope.current;
    try {
      const result = await requestStyle(action === 'preview' ? 'export' : action,
        action === 'update' ? { contactId, relationship, styleNotes } : { contactId });
      if (!requestScope?.isCurrent()) return;
      if (action === 'preview') setPreview(result);
      if (action === 'export') {
        const url = URL.createObjectURL(new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' }));
        const link = document.createElement('a');
        link.href = url; link.download = 'contact-reply-style.json';
        document.body.appendChild(link); link.click(); link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        setMessage('已生成本地 JSON 导出文件');
      }
      if (action === 'update' || action === 'delete') {
        await onChanged();
        if (!requestScope.isCurrent()) return;
        setMessage(action === 'update' ? '已保存' : '已删除');
      }
    } catch (failure) { if (requestScope?.isCurrent()) setError(`${action === 'update' ? '保存失败：' : '操作失败：'}${failure.message}`); }
    finally { if (requestScope?.isCurrent()) setPending(''); }
  }

  const samples = preview?.messages || preview?.samples || preview?.profile?.samples || preview?.records || [];
  const examples = profile.examples || profile.summary?.examples || [];
  const coverage = profile.coverage;
  const locked = disabled || Boolean(pending);
  return <article style={{ padding: 14, marginTop: 12, border: '1px solid #e5e7eb', borderRadius: 8 }}>
    <h4>{name}</h4>
    <p>样本：{profile.summary?.sampleCount ?? profile.sampleCount ?? profile.samples?.length ?? 0} 条 · 读取范围：{typeof coverage === 'string' ? coverage : coverage?.description || '仅微信已加载且可读取的记录'}</p>
    {coverage?.pagesRead !== undefined && <p>实际读取 {coverage.pagesRead} 页{coverage.requestedPages ? ` / 请求 ${coverage.requestedPages} 页` : ''}；未验证为完整历史。</p>}
    {coverage?.timeLabels?.length > 0 && <p>微信显示的时间标记：{coverage.timeLabels.join('、')}</p>}
    {(coverage?.start || coverage?.from || coverage?.end || coverage?.to) && <p>记录范围：{coverage.start || coverage.from || '起点未知'} — {coverage.end || coverage.to || '终点未知'}</p>}
    <label>关系 <RelationshipSelect label={`${name}的关系`} value={relationship} onChange={setRelationship} disabled={locked}/></label>
    <label style={{ display: 'block', marginTop: 8 }}>回复习惯备注
      <textarea aria-label={`${name}的回复习惯备注`} rows={3} maxLength={4000} style={{ display: 'block', width: '100%' }} value={styleNotes} disabled={locked} onChange={event => setStyleNotes(event.target.value)}/>
    </label>
    {typeof profile.summary === 'string' && <p>{profile.summary}</p>}
    {profile.summary && typeof profile.summary === 'object' && <div>
      <p>平均 {profile.summary.averageLength ?? 0} 字 · 短句 {profile.summary.shortCount ?? 0} 条 · 长句 {profile.summary.longCount ?? 0} 条 · 表情 {profile.summary.emojiCount ?? 0} 个</p>
      {profile.summary.frequentPhrases?.length > 0 && <p>常用表达：{profile.summary.frequentPhrases.map(phrase => `${phrase.text}（${phrase.count} 次）`).join('；')}</p>}
      <p>{profile.summary.basis}</p>
    </div>}
    {examples.length > 0 && <details><summary>回复示例</summary><ul>{examples.slice(0, 3).map((example, index) => <li key={index}>{typeof example === 'string' ? example : example.reply || example.text || ''}</li>)}</ul></details>}
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
      <button disabled={locked} onClick={() => act('update')}>{pending === 'update' ? '保存中…' : '保存修改'}</button>
      <button disabled={locked} onClick={() => act('preview')}>查看学习记录</button>
      <button disabled={locked} onClick={() => act('export')}>导出 JSON</button>
      <button disabled={locked} onClick={() => act('delete')}>删除学习数据</button>
    </div>
    {pending && <p role="status">正在处理…</p>}
    {message && <p role="status">{message}</p>}
    {error && <p role="alert">{error}</p>}
    {preview && <section aria-label={`${name}的学习记录预览`}>
      <p>本地学习记录共 {samples.length} 条，最多预览 20 条；此操作不会发送微信消息。</p>
      <button onClick={() => setPreview(null)}>关闭预览</button>
      <ol>{samples.slice(0, 20).map((sample, index) => <li key={index} style={{ whiteSpace: 'pre-wrap' }}>{typeof sample === 'string' ? sample : sample.reply || sample.text || sample.content || JSON.stringify(sample)}</li>)}</ol>
    </section>}
  </article>;
}

export function ContactStylePanel({ disabled = false, accountId = null }) {
  return <AccountContactStylePanel key={accountId || 'unconfirmed-account'} disabled={disabled} accountId={accountId}/>;
}

function AccountContactStylePanel({ disabled, accountId }) {
  const scope = useRequestScope();
  const [profiles, setProfiles] = useState([]);
  const [contact, setContact] = useState('');
  const [relationship, setRelationship] = useState('unknown');
  const pages = 1;
  const [pending, setPending] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  async function reload(requestScope = scope.current) {
    if (!requestScope?.isCurrent()) return;
    const result = await requestStyle('list');
    if (!requestScope.isCurrent()) return;
    setProfiles(Array.isArray(result) ? result : result.profiles || []);
    setLoaded(true);
  }
  async function loadProfiles() {
    const requestScope = scope.current;
    setLoading(true); setError(''); setMessage('');
    try { await reload(requestScope); }
    catch (failure) {
      if (requestScope.isCurrent()) setError(`无法读取回复习惯：${failure.message}。请确认已登录 DSH 账户并连接微信。`);
    } finally { if (requestScope.isCurrent()) setLoading(false); }
  }
  async function learn(event) {
    event.preventDefault(); setPending(true); setError(''); setMessage('');
    const requestScope = scope.current;
    try {
      await requestStyle('learn', { contact: contact.trim(), relationship, pages });
      if (!requestScope?.isCurrent()) return;
      await reload(requestScope);
      if (requestScope.isCurrent()) setMessage('学习完成，已保存本地回复习惯');
    } catch (failure) { if (requestScope?.isCurrent()) setError(`学习未完成：${failure.message}`); }
    finally { if (requestScope?.isCurrent()) setPending(false); }
  }
  return <section aria-label="联系人回复习惯" style={{ margin: '18px 0', padding: 14, border: '1px solid #e5e7eb', borderRadius: 8 }}>
    <h3>联系人回复习惯</h3>
    <p>按联系人学习你的表达方式。关系由你选择，不会自动推断。</p>
    <p>当前只读取微信已加载、可访问的 1 页记录，不会自动翻页，不代表完整聊天历史。记录保存在本机；生成回复时，仅选取相关片段交给当前 DSH 配置的模型。</p>
    <p>点击加载、学习或管理记录时会核验当前微信账号，可能切换到微信窗口。</p>
    <button type="button" disabled={disabled || pending || loading} onClick={loadProfiles}>{loading ? '正在核验账号并加载…' : '加载已学习联系人'}</button>
    <form onSubmit={learn} style={{ display: 'grid', gap: 8, maxWidth: 780 }}>
      <label>学习联系人<input aria-label="学习联系人" required maxLength={200} value={contact} disabled={disabled || pending || loading} onChange={event => setContact(event.target.value)} placeholder="微信联系人名称" style={{ display: 'block', width: '100%' }}/></label>
      <label>联系人关系 <RelationshipSelect label="学习联系人关系" value={relationship} onChange={setRelationship} disabled={disabled || pending || loading}/></label>
      <button disabled={disabled || pending || loading || !contact.trim()} type="submit">{pending ? '正在读取并学习…' : '学习此联系人回复习惯'}</button>
    </form>
    {pending && <p role="status">正在读取微信可访问的聊天记录，请保持微信窗口可用。完成后将显示实际样本数量。</p>}
    {loading && <p role="status">正在读取本地回复习惯…</p>}
    {message && <p role="status">{message}</p>}
    {error && <p role="alert">{error}</p>}
    {!accountId && <p>点击加载或学习以确认账号。</p>}
    {loaded && !loading && !error && <p role="status">已学习联系人：{profiles.length} 位</p>}
    {loaded && !loading && !error && profiles.length === 0 && <p>暂无已学习的联系人。请先输入联系人名称并点击“学习此联系人回复习惯”。</p>}
    {loaded && profiles.map(profile => <ContactProfile key={`${accountId || 'verified-account'}:${profile.contact?.id || profile.contactId || profile.id}`} profile={profile} disabled={disabled || pending || loading} onChanged={reload}/>)}
  </section>;
}
