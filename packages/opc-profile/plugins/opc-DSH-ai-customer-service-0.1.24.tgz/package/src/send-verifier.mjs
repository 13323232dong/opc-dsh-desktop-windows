const sameText = (a, b) => String(a ?? '') === String(b ?? '');

export function findNewOutgoing({ before = [], after = [], expectedText, expectedContactId, sendStartedAt = 0 } = {}) {
  const beforeIds = new Set(before.map(message => message?.id).filter(Boolean));
  return after.find(message =>
    typeof message?.id === 'string' && message.id.length > 0 &&
    message?.direction === 'outgoing' &&
    sameText(message.text, expectedText) &&
    (!expectedContactId || message.contactId === expectedContactId) &&
    (!message.createdAt || message.createdAt >= sendStartedAt) &&
    !beforeIds.has(message.id),
  ) || null;
}

export function verifySendEvidence({ before = [], after = [], expectedText, expectedContactId, composer, contextChanged = false, failureCode = null, sendStartedAt = 0 } = {}) {
  if (contextChanged) return 'wrong_context';
  if (failureCode) return 'failed';
  const outgoing = findNewOutgoing({ before, after, expectedText, expectedContactId, sendStartedAt });
  if (outgoing && composer === '') return 'sent';
  if (composer === expectedText) return 'failed';
  return 'unknown';
}

export function buildSendEvidence({ before = [], after = [], expectedText, expectedContactId, composer = '', adapterKind = 'accessibility', sendStartedAt = 0 }) {
  const outgoing = findNewOutgoing({ before, after, expectedText, expectedContactId, sendStartedAt });
  return {
    beforeMessageId: before.at(-1)?.id || null,
    afterMessageId: outgoing?.id || null,
    composerVerified: composer === '',
    contactVerified: Boolean(outgoing && (!expectedContactId || outgoing.contactId === expectedContactId)),
    adapterKind,
  };
}
