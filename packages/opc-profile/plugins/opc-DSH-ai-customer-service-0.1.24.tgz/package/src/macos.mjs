import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { assertAdapterContract } from './adapters/adapter-contract.mjs';

export class MacWechatAdapter {
  constructor({ binaryPath, platform = process.platform, transport } = {}) {
    this.binaryPath = binaryPath || process.env.DSH_WECHAT_HELPER_PATH || fileURLToPath(new URL('../native/bin/wechat-helper', import.meta.url));
    this.platform = platform;
    this.transport = transport;
    assertAdapterContract(this, 'Mac WeChat adapter');
  }
  async call(method, payload = {}, onStage) {
    if (this.platform !== 'darwin') throw Object.assign(new Error('当前微信适配器仅支持 macOS'), { code: 'WECHAT_PLATFORM_UNSUPPORTED' });
    if (this.transport) return this.transport(method, payload, onStage);
    return new Promise((resolve, reject) => {
      const child = spawn(this.binaryPath, [], { stdio: ['pipe', 'pipe', 'ignore'] });
      const requestId = randomUUID();
      let buffer = '', settled = false;
      const finish = (error, result) => {
        if (settled) return;
        settled = true; clearTimeout(timeout); child.kill();
        error ? reject(error) : resolve(result);
      };
      const timeout = setTimeout(() => finish(Object.assign(new Error('微信操作超时，发送结果需核查'), { code: method === 'send' ? 'WECHAT_SEND_UNKNOWN' : 'WECHAT_HELPER_TIMEOUT' })), 45000);
      child.on('error', () => finish(Object.assign(new Error('微信本地控制组件不可用'), { code: 'WECHAT_HELPER_UNAVAILABLE' })));
      child.stdout.on('data', data => {
        buffer += data.toString();
        if (buffer.length > 2_000_000) return finish(Object.assign(new Error('微信响应超出限制'), { code: 'WECHAT_PROTOCOL_ERROR' }));
        let split;
        while ((split = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, split); buffer = buffer.slice(split + 1);
          try {
            const item = JSON.parse(line);
            if (item.requestId !== requestId) continue;
            if (item.stage) { onStage?.(item.stage); continue; }
            finish(item.ok ? null : Object.assign(new Error(item.error?.message || '微信操作失败'), { code: item.error?.code || 'WECHAT_HELPER_ERROR' }), item.result);
          } catch { finish(Object.assign(new Error('微信组件返回无效响应'), { code: 'WECHAT_PROTOCOL_ERROR' })); }
        }
      });
      child.on('close', () => finish(Object.assign(new Error('微信组件意外退出'), { code: method === 'send' ? 'WECHAT_SEND_UNKNOWN' : 'WECHAT_HELPER_UNAVAILABLE' })));
      child.stdin.end(JSON.stringify({ requestId, method, payload }) + '\n');
    });
  }
  async status({fresh=false}={}) {
    if (!fresh && this.statusCache && Date.now() - this.statusCache.at < 15000) return this.statusCache.result;
    const result = await this.call('status');
    this.statusCache = { at: Date.now(), result };
    this.probeCache = null;
    return result;
  }
  requestAccessibility() { return this.call('requestAccessibility'); }
  async peekStatus() {
    if (this.probeCache && Date.now() - this.probeCache.at < 5000) return this.probeCache.result;
    if (this.probePending) return this.probePending;
    this.probePending = this.probeStatus().then(result => {
      this.probeCache = {at:Date.now(),result};return result;
    }).finally(() => { this.probePending = null; });
    return this.probePending;
  }
  async probeStatus() {
    const probe = await this.call('probe');
    const cached = this.statusCache?.result;
    if (!probe.ready || !cached || cached.processId !== probe.processId) {
      this.statusCache = null;
      return { ...probe, ready: false, failureCode: probe.failureCode || 'WECHAT_ACCOUNT_UNVERIFIED' };
    }
    return { ...cached, ...probe };
  }
  findContact(name) { return this.call('findContact', { name }); }
  async listChats() {
    const status = await this.peekStatus();
    if (!status.ready || !status.accountId) throw Object.assign(new Error('微信账号需要重新确认'), { code: status.failureCode });
    return this.call('listChats', { accountId: status.accountId, processId: status.processId });
  }
  async tagIdentity() {
    const status = await this.peekStatus();
    if (!status.ready || !status.accountId || !Number.isInteger(status.processId)) {
      throw Object.assign(new Error('微信账号需要重新确认'), { code: status.failureCode || 'WECHAT_ACCOUNT_UNVERIFIED' });
    }
    return { accountId: status.accountId, processId: status.processId };
  }
  async listTags() {
    return this.call('listTags', await this.tagIdentity());
  }
  async listTagContacts(tagIds) {
    if (!Array.isArray(tagIds) || tagIds.length === 0) {
      throw Object.assign(new Error('请选择至少一个微信标签'), { code: 'WECHAT_TAG_SCOPE_EMPTY' });
    }
    if (tagIds.length > 50 || tagIds.some(id => typeof id !== 'string' || !id.trim() || id.length > 500) || new Set(tagIds).size !== tagIds.length) {
      throw Object.assign(new Error('微信标签标识无效'), { code: 'WECHAT_TAG_ID_INVALID' });
    }
    return this.call('listTagContacts', { ...await this.tagIdentity(), tagIds: [...tagIds] });
  }
  openChat(contact) { return this.call('openChat', { contact }); }
  readChat(contact) { return this.call('readChat', { contact }); }
  async readHistory(contact, { pages = 1 } = {}) {
    if (!Number.isInteger(pages) || pages < 1 || pages > 5) {
      throw Object.assign(new Error('历史读取页数必须为 1 到 5 的整数'), { code: 'WECHAT_HISTORY_PAGES_INVALID' });
    }
    return this.call('readHistory', { contact, pages });
  }
  readComposer(contact) { return this.call('readComposer', { contact }); }
  draft(contact, text, { replaceExisting = false } = {}) { return this.call('draft', { contact, text, ...(replaceExisting ? { replaceExisting: true } : {}) }); }
  sendAction(contact, text) { return this.call('sendAction', { contact, text }); }
  readSendEvidence(contact, text, before = []) { return this.call('readSendEvidence', { contact, text, before }); }
  send(contact, text, { onStage } = {}) { return this.call('send', { contact, text }, onStage); }
}
