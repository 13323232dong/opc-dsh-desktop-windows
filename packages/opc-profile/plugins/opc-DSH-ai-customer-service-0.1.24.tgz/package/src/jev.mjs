import { execFile as execFileCallback } from 'node:child_process';
import { promisify } from 'node:util';

export const JEV_MODEL='jev-1.13.0';
const JEV_URL='https://api.typesafe.ai/v1/systemone';
const KEYCHAIN_SERVICE='com.evan.supervisor.typesafe-jev';
const execFile=promisify(execFileCallback);

function coded(code) { return Object.assign(new Error(code),{code}); }
function probability(value) { return typeof value==='number'&&Number.isFinite(value)&&value>=0&&value<=1?value:null; }
function choice(answer) {
  if(!answer||typeof answer.choice!=='string'||!answer.choice||probability(answer.confidence)===null||!answer.probabilities||typeof answer.probabilities!=='object')return null;
  const probabilities=Object.fromEntries(Object.entries(answer.probabilities).filter(([,value])=>probability(value)!==null));
  return Object.keys(probabilities).length?{choice:answer.choice,probabilities,confidence:answer.confidence}:null;
}
function boundedText(value,max) { return typeof value==='string'?value.trim().slice(0,max):''; }
function boundedContext(recentContext) {
  return (Array.isArray(recentContext)?recentContext:[]).slice(-8).map(item=>({
    direction:item?.direction==='outgoing'?'outgoing':'incoming',text:boundedText(item?.text,500),
  })).filter(item=>item.text);
}
async function defaultGetKey() {
  try {
    const {stdout}=await execFile('/usr/bin/security',['find-generic-password','-s',KEYCHAIN_SERVICE,'-w'],{encoding:'utf8',maxBuffer:16*1024});
    return stdout.trim();
  } catch { return ''; }
}
function questions() {
  return {
    intent:{type:'choice',instructions:'将当前客户来信归类为最主要的业务意图。只依据提供的消息，不要把概率解释为客户真实心理。',criteria:{咨询:'询问服务、规则、能力或一般信息',报价:'询问价格、费用、优惠或成本',预约:'明确希望安排时间、上门、到店或服务时段',售后:'已购买或已服务后的问题、进度或支持',投诉:'表达不满、纠纷或负面反馈',闲聊:'非业务日常交流',其他:'无法归入以上类别'}},
    purchase_intent:{type:'noul',instructions:'当前来信是否表达了明确或隐含的购买、预约或进一步成交意愿？只根据消息内容判断。',criteria:{true:'有购买、预约、报价比较或下一步服务意向',false:'没有足够迹象'}},
    urgency:{type:'choice',instructions:'按消息中可观察到的时间要求判断紧急程度。',criteria:{不紧急:'未表达明确时间压力',近期:'希望在近期、当天或明确时间内处理，但非事故级紧急',紧急:'明确紧急、故障影响重大或需要立即处理'}},
    recommended_action:{type:'choice',instructions:'为人工或回复模型选择下一步建议动作；只根据当前消息和提供的业务资料，不得承诺未确认的价格或服务。',criteria:{直接回答:'已有充分资料，可以直接回应',追问需求:'缺少型号、地点、时间或具体需求等关键事实',提供报价范围:'用户询价且可以谨慎说明范围或报价条件',转人工:'需要专业确认、授权、复杂争议或超出资料范围',安抚投诉:'先确认感受并收集问题，再安排跟进',无需跟进:'无需业务动作'}},
    risk:{type:'choice',instructions:'评估这条消息用于自动草稿时的业务风险，不是对人的风险判断。',criteria:{低:'普通咨询，资料充分或可安全追问',中:'价格、承诺、时效或情绪需要谨慎表述',高:'投诉、法律/安全问题、付款纠纷或必须人工确认的敏感事项'}},
  };
}
function parse(body) {
  if(!body||typeof body!=='object'||!body.answers||typeof body.answers!=='object')throw coded('JEV_RESPONSE_INVALID');
  const intent=choice(body.answers.intent),urgency=choice(body.answers.urgency),recommendedAction=choice(body.answers.recommended_action),risk=choice(body.answers.risk),purchaseIntent=probability(body.answers.purchase_intent?.noul);
  if(!intent||!urgency||!recommendedAction||!risk||purchaseIntent===null)throw coded('JEV_RESPONSE_INVALID');
  return {model:typeof body.model==='string'&&body.model?body.model:JEV_MODEL,intent,purchaseIntent,urgency,recommendedAction,risk,analyzedAt:Date.now()};
}

export function createJevAnalyzer({getKey=defaultGetKey,fetch:fetchImpl=globalThis.fetch,timeoutMs=25000}={}) {
  return async ({message,recentContext=[],contact={},businessInstructions=''})=>{
    const key=await getKey();
    if(typeof key!=='string'||!key.trim())throw coded('JEV_KEY_UNAVAILABLE');
    const text=boundedText(message,4000);if(!text)throw coded('JEV_INPUT_INVALID');
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try {
      let response;
      try {
        response=await fetchImpl(JEV_URL,{method:'POST',headers:{Authorization:`Bearer ${key.trim()}`,'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({model:JEV_MODEL,state:{message:text,recentContext:boundedContext(recentContext),contactName:boundedText(contact?.name,200),businessInstructions:boundedText(businessInstructions,2000)},questions:questions()})});
      } catch { throw coded('JEV_API_UNAVAILABLE'); }
      if(!response?.ok)throw coded(response?.status===401||response?.status===403||response?.status===400?'JEV_API_REJECTED':'JEV_API_UNAVAILABLE');
      let body;try {body=JSON.parse(await response.text());} catch {throw coded('JEV_RESPONSE_INVALID');}
      return parse(body);
    } finally { clearTimeout(timer); }
  };
}
