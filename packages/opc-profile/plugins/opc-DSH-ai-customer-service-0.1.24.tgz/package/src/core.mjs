import { randomUUID } from 'node:crypto';
import { Store } from './store.mjs';
import { ContactStyleStore } from './contact-style.mjs';
import { buildSendEvidence, verifySendEvidence } from './send-verifier.mjs';

const ACTIVE=new Set(['locating','reading','inputting','sending','verifying']);
const HALT=new Set(['WECHAT_ACCOUNT_UNVERIFIED','WECHAT_ACCOUNT_CHANGED','WECHAT_ACCOUNT_UNAVAILABLE','WECHAT_LOGIN_REQUIRED','WECHAT_NOT_RUNNING','WECHAT_PLATFORM_RESTRICTED','WECHAT_PLATFORM_REJECTED','WECHAT_PERMISSION_DENIED','WECHAT_ACCESSIBILITY_REQUIRED','WECHAT_TAGS_UNAVAILABLE','WECHAT_TAG_CONTACTS_UNAVAILABLE','VISION_ADAPTER_PAUSED']);
const copy=value=>structuredClone(value);
const EXCLUDED_PREVIEW_TITLES=new Set(['公众号','服务号','服务号消息','订阅号','订阅号消息','文件传输助手','file transfer','file transfer assistant','filehelper','official accounts','subscription accounts','service accounts']);
function excludedPreviewChat(chat) {
 return EXCLUDED_PREVIEW_TITLES.has(String(chat?.title||'').trim().toLowerCase())||['official_account','service_account','subscription_account','file_transfer'].includes(chat?.chatType);
}
const field=(value,name,max=4000)=>{if(typeof value!=='string'||!value.trim()||value.length>max) throw new Error(`INVALID_${name}`); return value;};
function failure(error) {
 const code=String(error?.code||error?.message||'WECHAT_AUTOMATION_ERROR');
 return /^[A-Z][A-Z0-9_]{2,80}$/.test(code)?code:'WECHAT_AUTOMATION_ERROR';
}
function responsibility(code) {
 if(code.includes('KNOWLEDGE')) return '第二大脑知识库';
 if(code.includes('MODEL')) return '模型服务';
 if(code.includes('PERMISSION')||code.includes('ACCESSIBILITY')) return '桌面权限';
 if(code.includes('PLATFORM')) return '微信平台';
 if(code.includes('UNKNOWN')||code.includes('INTERRUPTED')) return '发送结果未确认';
 return '桌面自动化';
}
function errorDetail(code) {
 if(code==='WECHAT_KNOWLEDGE_UNAVAILABLE')return {code,message:'第二大脑检索不可用，待回复消息已保留，请检查知识库与索引'};
 if(code==='WECHAT_HISTORY_RESYNC_REQUIRED')return {code,message:'微信可见消息历史发生变化，已暂停自动回复；请重新开启托管建立新基线'};
 const nativeMessages={WECHAT_ACCESSIBILITY_REQUIRED:'请在系统设置授予桌面应用辅助功能权限',WECHAT_NOT_RUNNING:'请先打开并登录 Mac 微信',WECHAT_ACCOUNT_UNAVAILABLE:'无法确认当前微信账号，任务已停止',WECHAT_PLATFORM_REJECTED:'微信界面明确显示发送失败或接收限制',WECHAT_FOCUS_CHANGED:'微信窗口焦点被切换，本条操作已停止',WECHAT_CONTACT_AMBIGUOUS:'找到多个同名联系人，未选择或发送',WECHAT_EXISTING_DRAFT:'目标聊天已有输入草稿，未覆盖或发送',WECHAT_CHAT_MISMATCH:'当前微信聊天标题与目标不一致',WECHAT_DIRECTION_UNKNOWN:'无法确认消息方向，未自动回复',WECHAT_MODEL_UNAVAILABLE:'客服模型不可用，待回复消息已保留',WECHAT_WORKER_ALREADY_RUNNING:'另一个桌面实例正在控制微信，此实例仅查看状态',WECHAT_TAGS_UNAVAILABLE:'当前微信版本未暴露原生标签结构，无法开启原生标签监听',WECHAT_TAG_CONTACTS_UNAVAILABLE:'微信标签存在，但联系人列表或稳定联系人标识不可读'};
 if(nativeMessages[code])return {code,message:nativeMessages[code]};
 const messages={WECHAT_ACCOUNT_CHANGED:'微信账号已切换，后续任务已停止',WECHAT_LOGIN_REQUIRED:'微信未登录或账号无法识别',WECHAT_PLATFORM_RESTRICTED:'微信界面明确提示操作受限',WECHAT_PERMISSION_DENIED:'缺少 macOS 辅助功能权限',WECHAT_CONTACT_NOT_FOUND:'未找到指定联系人',WECHAT_CONTACT_MISMATCH:'当前聊天与目标联系人不一致',WECHAT_SEND_UNKNOWN:'未确认新增出站消息，请核查聊天记录后再决定是否重试',WECHAT_SEND_INTERRUPTED:'发送过程中服务中断，未自动重发以免重复',WECHAT_WATCH_PAUSED:'该联系人已暂停自动回复',WECHAT_MANUAL_TAKEOVER:'检测到人工发送，自动回复已暂停',MODEL_UNAVAILABLE:'模型服务不可用，待回复消息已保留'};
 return {code,message:messages[code]||'操作未完成，请检查桌面自动化状态与错误码'};
}

export class CustomerService {
 constructor({stateDir,adapter,replyGenerator,jevAnalyzer,pollMs=5000,debounceMs=3000}) {
  this.store=new Store(stateDir); this.state=this.store.read(); this.adapter=adapter;
  this.styles=new ContactStyleStore(stateDir);
  this.replyGenerator=replyGenerator; this.jevAnalyzer=jevAnalyzer; this.pollMs=pollMs; this.debounceMs=debounceMs;
  this.chain=Promise.resolve(); this.running=false; this.stopped=false; this.ticking=false;
  this.previewRevision=0;
  this.readOnly=!this.store.acquire();this.connection=null;
  // A crashed send might already have reached WeChat. Never replay it automatically.
  this.state={...this.state,tasks:this.state.tasks.map(task=>ACTIVE.has(task.status)?{...task,status:'unknown',failureCode:'WECHAT_SEND_INTERRUPTED',error:errorDetail('WECHAT_SEND_INTERRUPTED'),responsibility:'发送结果未确认',updatedAt:Date.now()}:task)};
  if(!this.readOnly)this.store.write(this.state);else this.state=this.store.read();
 }
 save(next) {this.store.write(next);this.state=next;}
 updateTask(id,patch) {this.save({...this.state,tasks:this.state.tasks.map(task=>task.id===id?{...task,...patch,...(patch.failureCode?{error:errorDetail(patch.failureCode)}:{}),updatedAt:Date.now()}:task)});}
 updateWatch(id,patch) {this.save({...this.state,watches:this.state.watches.map(w=>w.id===id?{...w,...patch,...(patch.failureCode?{error:errorDetail(patch.failureCode)}:{}),updatedAt:Date.now()}:w)});}
 locked(operation) {const result=this.chain.then(operation);this.chain=result.catch(()=>{});return result;}
 async account(expected,options) {
  const status=await this.adapter.status(options);
  this.connection=status;
  if(!status.ready||!status.accountId) throw new Error(status.failureCode||'WECHAT_LOGIN_REQUIRED');
  if(expected&&status.accountId!==expected) throw new Error('WECHAT_ACCOUNT_CHANGED');
  return status.accountId;
 }
 async status() {
  let connection;
  try {connection=this.adapter.peekStatus?await this.adapter.peekStatus():this.running&&this.connection?this.connection:await this.locked(()=>this.adapter.status());this.connection=connection;} catch(error){connection={ready:false,failureCode:failure(error)};}
  if(this.readOnly)this.state=this.store.read();
  const globalPreview=(!connection.accountId||this.state.globalPreview?.accountId===connection.accountId)&&this.state.globalPreview?this.state.globalPreview:{
    enabled:false,accountId:connection.accountId||'',adapterKind:'router',stage:'idle',
    baselineVersion:'',baseline:{},events:[],lastScanAt:null,consecutiveFailures:0,failureCode:null,
  };
  return {...connection,watches:copy(this.state.watches.filter(w=>w.accountId===connection.accountId)),globalPreview:copy(globalPreview),tasks:this.tasks(),running:this.running,readOnly:this.readOnly};
 }
 findContact(name) {field(name,'CONTACT',200);if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');return this.locked(()=>this.adapter.findContact(name));}
 async contact(value) {
  if(typeof value==='string') return this.contact(await this.adapter.findContact(field(value,'CONTACT',200)));
  if(!value||typeof value!=='object') throw new Error('INVALID_CONTACT');
  const id=field(value.id||value.contactId,'CONTACT_ID',500);
  const name=field(value.name||value.title,'CONTACT_NAME',200);
  return {id,name,...(value.accountId?{accountId:field(value.accountId,'ACCOUNT_ID',500)}:{})};
 }
 readChat(value) {if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');return this.locked(async()=>{await this.account();return this.adapter.readChat(await this.contact(value));});}
 async analyze({contact:target,message,businessInstructions=''}) {
  if(!this.jevAnalyzer)throw Object.assign(new Error('JEV_API_UNAVAILABLE'),{code:'JEV_API_UNAVAILABLE'});
  if(typeof businessInstructions!=='string'||businessInstructions.length>20000)throw new Error('INVALID_INSTRUCTIONS');
  if(message!==undefined&&(typeof message!=='string'||!message.trim()||message.length>4000))throw new Error('INVALID_MESSAGE');
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  return this.locked(async()=>{
   const accountId=await this.account(undefined,{fresh:true});const contact={...await this.contact(target),accountId};
   const chat=await this.adapter.readChat(contact);this.checkChat(chat,accountId,contact);
   const incoming=message?.trim()||chat.messages.filter(item=>item.direction==='incoming'&&typeof item.text==='string'&&item.text.trim()).at(-1)?.text;
   if(!incoming)throw new Error('WECHAT_NEW_MESSAGE_UNCONFIRMED');
   return this.jevAnalyzer({contact,message:incoming,recentContext:chat.messages.slice(-8),businessInstructions});
  });
 }
 async assess(input) {
  if(!this.jevAnalyzer)return {analysisUnavailable:'JEV_API_UNAVAILABLE'};
  try {return {jevAssessment:await this.jevAnalyzer(input)};} catch(error) {return {analysisUnavailable:failure(error)};}
 }
 async learnStyle({contact:target,relationship,pages=1}) {
  field(target,'CONTACT',200);
  if((relationship!==undefined&&!['work','friend','family','unknown'].includes(relationship))||!Number.isInteger(pages)||pages<1||pages>5)throw new Error('CONTACT_STYLE_INVALID_OPTIONS');
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  return this.locked(async()=>{
   const accountId=await this.account(undefined,{fresh:true});const contact={...await this.contact(target),accountId};
   if(!this.adapter.readHistory)throw new Error('WECHAT_HISTORY_UNAVAILABLE');
   const chat=await this.adapter.readHistory(contact,{pages});this.checkChat(chat,accountId,contact);
   const excludedMessageIds=this.state.tasks.filter(task=>task.accountId===accountId&&task.contact.id===contact.id).flatMap(task=>[task.evidence?.afterMessageId,task.evidence?.messageId]).filter(Boolean);
   const generatedTexts=this.state.globalPreview?.accountId===accountId?(this.state.globalPreview.events||[]).filter(event=>event.chatId===contact.id&&event.draftText).map(event=>event.draftText):[];
   const samples=chat.messages.filter(message=>message.direction!=='outgoing'||!generatedTexts.includes(message.text));
   const profile=this.styles.learn({accountId,contact,messages:samples,coverage:chat.coverage,relationship,excludedMessageIds});
   const {messages,...summary}=profile;return summary;
  });
 }
 async styleAction(action,args={}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  return this.locked(async()=>{
  const accountId=await this.account(undefined,{fresh:true});
  if(action==='list')return this.styles.list(accountId);
  const contactId=field(args.contactId,'CONTACT_ID',500);
  if(action==='export')return this.styles.export(accountId,contactId);
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(action==='update') {
   const profile=this.styles.update(accountId,contactId,{relationship:args.relationship,styleNotes:args.styleNotes});
   const {messages,...summary}=profile;return summary;
  }
  if(action==='delete'){this.styles.remove(accountId,contactId);return {deleted:true};}
  throw new Error('CONTACT_STYLE_INVALID_ACTION');
  });
 }
 replyStyle(accountId,contact) {
  const profile=this.styles.get(accountId,contact.id);
  const excerpt=message=>({direction:message.direction,text:message.text.slice(0,500)});
  return {relationship:profile?.relationship||'unknown',summary:profile?.summary||null,styleNotes:profile?.styleNotes||'',examples:(profile?.examples||[]).map(excerpt),historyContext:(profile?.messages||[]).slice(-12).map(excerpt),revision:profile?.revision||null};
 }
 assertReplyStyle(accountId,contact,profile) {
  if((this.styles.get(accountId,contact.id)?.revision||null)!==profile.revision)throw new Error('CONTACT_STYLE_CHANGED');
 }
 tasks() {if(this.readOnly)this.state=this.store.read();return copy(this.state.tasks.filter(t=>!this.connection?.accountId||t.accountId===this.connection.accountId));}
 clearFailedTasks() {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  const remaining=this.state.tasks.filter(task=>task.status!=='failed');
  const removed=this.state.tasks.length-remaining.length;
  if(removed)this.save({...this.state,tasks:remaining});
  return {removed,remaining:remaining.length};
 }
 async send({contact,text,requestId,sessionId='',watchId,accountId:expected,knowledgeSources=[],styleRevision,jevAssessment,analysisUnavailable}) {
  field(text,'TEXT');field(requestId,'REQUEST_ID',200);
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  const result=await this.locked(async()=>{
   const accountId=await this.account(expected); const resolved=await this.contact(contact);
   if(resolved.accountId&&resolved.accountId!==accountId)throw new Error('WECHAT_ACCOUNT_CHANGED');
   if(styleRevision!==undefined)this.assertReplyStyle(accountId,resolved,{revision:styleRevision});
   const existing=this.state.tasks.find(t=>t.accountId===accountId&&t.requestId===requestId);
   if(existing) {
    if(existing.contact.id!==resolved.id||existing.text!==text) throw new Error('IDEMPOTENCY_CONFLICT');
    return copy(existing);
   }
   const task={id:randomUUID(),requestId,accountId,contact:{...resolved,accountId},text,sessionId,status:'queued',watchId,styleRevision,knowledgeSources:copy(knowledgeSources),...(jevAssessment?{jevAssessment:copy(jevAssessment)}:{}),...(analysisUnavailable?{analysisUnavailable}:{ }),createdAt:Date.now(),updatedAt:Date.now()};
   this.save({...this.state,tasks:[...this.state.tasks,task]}); return copy(task);
  });
  this.kick(); return result;
 }
 kick() {
  if(this.running||this.stopped||this.readOnly) return;
  this.running=true;
  queueMicrotask(async()=>{
   try {
    while(!this.stopped) {
     const task=this.state.tasks.find(t=>t.status==='queued'); if(!task) break;
     await this.locked(()=>this.execute(task));
    }
   } catch(error) {this.lastError=failure(error);} finally {this.running=false;if(this.stopped&&!this.ticking)this.store.release();}
  });
 }
 async execute(task) {
  try {
   await this.account(task.accountId);
   if(task.styleRevision!==undefined)this.assertReplyStyle(task.accountId,task.contact,{revision:task.styleRevision});
   if(task.watchId&&!this.state.watches.some(w=>w.id===task.watchId&&w.enabled)) {
    this.updateTask(task.id,{status:'skipped',failureCode:'WECHAT_WATCH_PAUSED'});return;
   }
   if(task.watchId) {
    const watch=this.state.watches.find(w=>w.id===task.watchId);
    await this.inspectWatch(watch);
    const inspected=this.state.watches.find(w=>w.id===task.watchId);
    if(!inspected?.enabled) {
     this.updateTask(task.id,{status:'skipped',failureCode:inspected?.failureCode||'WECHAT_WATCH_PAUSED'});return;
    }
   }
   this.updateTask(task.id,{status:'locating'});
   const result=await this.executeSend(task);
   if(result?.status!=='sent'||!result.evidence) {
    this.updateTask(task.id,{status:'unknown',failureCode:'WECHAT_SEND_UNKNOWN',responsibility:'发送结果未确认'});return;
   }
   this.updateTask(task.id,{status:'sent',evidence:result.evidence,failureCode:null});
  } catch(error) {
   const code=failure(error);const current=this.state.tasks.find(t=>t.id===task.id);
   const status=['sending','verifying'].includes(current.status)&&!HALT.has(code)?'unknown':'failed';
   this.updateTask(task.id,{status,failureCode:code,responsibility:responsibility(code)});
   if(HALT.has(code)) {
    this.save({...this.state,tasks:this.state.tasks.map(t=>t.accountId===task.accountId&&t.status==='queued'?{...t,status:'skipped',failureCode:code,error:errorDetail(code),responsibility:responsibility(code),updatedAt:Date.now()}:t),watches:this.state.watches.map(w=>w.accountId===task.accountId?{...w,enabled:false,failureCode:code,error:errorDetail(code)}:w)});
   }
  }
 }
 async executeSend(task) {
  const contact={...task.contact,accountId:task.accountId};
  const onStage=stage=>{if(!ACTIVE.has(stage))throw new Error('INVALID_SEND_STAGE');this.updateTask(task.id,{status:stage});};
  // Keep the legacy one-shot adapter contract for test doubles and older hosts.
  if(typeof this.adapter.openChat!=='function'||typeof this.adapter.readSendEvidence!=='function') {
   return this.adapter.send(contact,task.text,{onStage});
  }
  onStage('locating');
  const opened=await this.adapter.openChat(contact);
  if(opened?.accountId&&opened.accountId!==task.accountId)throw new Error('WECHAT_ACCOUNT_CHANGED');
  onStage('reading');
  const before=await this.adapter.readChat(contact);
  this.checkChat(before,task.accountId,contact);
  onStage('inputting');
  await this.adapter.draft(contact,task.text,{replaceExisting:false});
  const composer=await this.adapter.readComposer(contact);
  const composerText=composer?.text??composer?.value;
  if(composerText!==undefined&&composerText!==task.text)throw new Error('WECHAT_COMPOSER_MISMATCH');
  const startedAt=Date.now();
  onStage('sending');
  await this.adapter.sendAction(contact,task.text);
  onStage('verifying');
  let evidence;
  for(let attempt=0;attempt<20;attempt+=1) {
   const checked=await this.adapter.readSendEvidence(contact,task.text,before.messages||[]);
   const after=checked?.chat||checked?.after||checked?.messages||checked;
   const composerText=checked?.composer?.text??checked?.composer;
   const failureCode=checked?.failureCode||(checked?.failure===true?'WECHAT_PLATFORM_REJECTED':null);
   const contextChanged=checked?.contextChanged===true||(checked?.accountId&&checked.accountId!==task.accountId)||(checked?.contactId&&checked.contactId!==contact.id);
   const messages=Array.isArray(after)?after:[];
   const verdict=verifySendEvidence({before:before.messages||[],after:messages,expectedText:task.text,composer:composerText,contextChanged,failureCode,sendStartedAt:startedAt});
   if(verdict==='wrong_context')throw new Error('WECHAT_CONTACT_MISMATCH');
   if(verdict==='sent') { evidence=buildSendEvidence({before:before.messages||[],after:messages,expectedText:task.text,composer:composerText,adapterKind:checked?.adapterKind||'accessibility',sendStartedAt:startedAt}); break; }
   if(verdict==='failed') throw Object.assign(new Error('微信界面未完成发送'),{code:failureCode||'WECHAT_SEND_REJECTED'});
   await new Promise(resolve=>setTimeout(resolve,250));
  }
  return evidence?{status:'sent',evidence}:{status:'unknown'};
 }
 async watch({contact,enabled=true,businessInstructions='',style=''}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(typeof businessInstructions!=='string'||businessInstructions.length>20000||typeof style!=='string'||style.length>2000) throw new Error('INVALID_INSTRUCTIONS');
  return this.locked(async()=>{
   const accountId=await this.account();const found=await this.contact(contact);
   if(found.accountId&&found.accountId!==accountId)throw new Error('WECHAT_ACCOUNT_CHANGED');
   const resolved={...found,accountId};
   const chat=await this.adapter.readChat(resolved);this.checkChat(chat,accountId,resolved);
   const old=this.state.watches.find(w=>w.accountId===accountId&&w.contact.id===resolved.id);
   const watch={id:old?.id||randomUUID(),revision:randomUUID(),accountId,contact:resolved,enabled:!!enabled,businessInstructions,style,seen:chat.messages.map(m=>m.id),observedIds:chat.messages.map(m=>m.id),pending:[],changedAt:0,createdAt:old?.createdAt||Date.now(),updatedAt:Date.now()};
   this.save({...this.state,watches:[...this.state.watches.filter(w=>w.id!==watch.id),watch]}); return copy(watch);
  });
 }
 async pause(contact) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  return this.locked(async()=>{
   const accountId=await this.account();const resolved=await this.contact(contact);
   const watch=this.state.watches.find(w=>w.accountId===accountId&&w.contact.id===resolved.id);
   if(!watch) throw new Error('WATCH_NOT_FOUND');this.updateWatch(watch.id,{enabled:false,pending:[]});
   return copy(this.state.watches.find(w=>w.id===watch.id));
  });
 }
 async globalPreview({enabled,businessInstructions='',style=''}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(typeof enabled!=='boolean')throw new Error('INVALID_ENABLED');
  if(typeof businessInstructions!=='string'||businessInstructions.length>20000||typeof style!=='string'||style.length>2000)throw new Error('INVALID_INSTRUCTIONS');
  const revision=++this.previewRevision;
  if(!enabled) {
   // Stopping is a local state transition. It must not wait behind a slow
   // model generation, otherwise a stale response could overwrite a draft.
   const current=this.state.globalPreview||{};
   const next={...current,enabled:false,failureCode:null,events:(current.events||[]).map(event=>['queued','locating','reading','generating','drafting'].includes(event.status)?{...event,status:'cancelled',draftStatus:'cancelled',updatedAt:Date.now()}:event),updatedAt:Date.now()};
   this.save({...this.state,globalPreview:next});return copy(next);
  }
  return this.locked(async()=>{
   if(revision!==this.previewRevision)return copy(this.state.globalPreview);
   const accountId=await this.account();
   if(revision!==this.previewRevision)return copy(this.state.globalPreview);
   const result=await this.adapter.listChats();
   if(revision!==this.previewRevision)return copy(this.state.globalPreview);
   if(result?.accountId!==accountId||!Array.isArray(result?.chats))throw new Error('WECHAT_CHAT_LIST_UNAVAILABLE');
   const current=this.state.globalPreview?.accountId===accountId?this.state.globalPreview:null;
   const unread=this.unreadChats(result.chats);
    const next={
      enabled:true,
      accountId,
      adapterKind:result.adapterKind||current?.adapterKind||'accessibility',
      stage:'scanning',
      baselineVersion:current?.baselineVersion||randomUUID(),
      baseline:current?.baseline||{},
      completed:current?.completed||{},
      events:current?.events||[],
      businessInstructions,
      style,
      startedAt:current?.startedAt||Date.now(),
      updatedAt:Date.now(),
      lastScanAt:Date.now(),
      consecutiveFailures:0,
      failureCode:null,
    };
   const queued=this.enqueueUnread(next,unread);
   next.events=queued.events;next.baseline=queued.baseline;next.completed=queued.completed;
   this.save({...this.state,globalPreview:next});return copy(next);
  });
 }
 async tags() {
  if(!this.adapter.listTags)throw Object.assign(new Error('当前微信版本未暴露原生标签结构'),{code:'WECHAT_TAGS_UNAVAILABLE'});
  return this.locked(async()=>{
   const accountId=await this.account();const result=await this.adapter.listTags();
   if(result?.accountId!==accountId||!Array.isArray(result?.tags))throw Object.assign(new Error('微信原生标签不可读'),{code:'WECHAT_TAGS_UNAVAILABLE'});
   return {accountId,tags:result.tags.map(tag=>({id:field(tag?.id,'TAG_ID',500),name:field(tag?.name,'TAG_NAME',200),contactCount:Number.isInteger(tag?.contactCount)&&tag.contactCount>=0?tag.contactCount:null}))};
  });
 }
 async tagScope({enabled,tagIds=[],businessInstructions='',style=''}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(typeof enabled!=='boolean')throw new Error('INVALID_ENABLED');
  if(!Array.isArray(tagIds)||tagIds.some(id=>typeof id!=='string'||!id.trim())||new Set(tagIds).size!==tagIds.length)throw Object.assign(new Error('微信标签标识无效'),{code:'WECHAT_TAG_ID_INVALID'});
  if(enabled&&!tagIds.length)throw Object.assign(new Error('请选择至少一个微信标签'),{code:'WECHAT_TAG_SCOPE_EMPTY'});
  if(typeof businessInstructions!=='string'||businessInstructions.length>20000||typeof style!=='string'||style.length>2000)throw new Error('INVALID_INSTRUCTIONS');
  const revision=++this.previewRevision;
  if(!enabled) return this.globalPreview({enabled:false});
  return this.locked(async()=>{
   const accountId=await this.account();
   const current=this.state.globalPreview?.accountId===accountId?this.state.globalPreview:{};
   const monitor={...current,enabled:true,accountId,adapterKind:'accessibility',stage:'syncing-tags',scope:{kind:'wechat-tags',tagIds:[...tagIds]},resolvedContacts:current.resolvedContacts||[],scopeRevision:randomUUID(),lastScopeSyncAt:null,tags:[],baselineVersion:current.baselineVersion||randomUUID(),baseline:current.baseline||{},completed:current.completed||{},events:current.events||[],businessInstructions,style,startedAt:current.startedAt||Date.now(),updatedAt:Date.now(),lastScanAt:current.lastScanAt||null,consecutiveFailures:0,failureCode:null};
   this.save({...this.state,globalPreview:monitor});
   if(revision!==this.previewRevision)return copy(this.state.globalPreview);
   return this.syncTagScope(monitor);
  });
 }
 async syncTagScope(monitor=this.state.globalPreview) {
  if(!monitor?.enabled||monitor.scope?.kind!=='wechat-tags')return copy(monitor);
  if(!this.adapter.listTags||!this.adapter.listTagContacts)throw Object.assign(new Error('当前微信版本未暴露原生标签结构'),{code:'WECHAT_TAGS_UNAVAILABLE'});
  const tagsResult=await this.adapter.listTags();
  if(tagsResult?.accountId!==monitor.accountId||!Array.isArray(tagsResult?.tags))throw Object.assign(new Error('微信原生标签不可读'),{code:'WECHAT_TAGS_UNAVAILABLE'});
  const selected=new Set(monitor.scope.tagIds);
  const tags=tagsResult.tags.filter(tag=>selected.has(tag?.id));
  if(tags.length!==selected.size)throw Object.assign(new Error('已选微信标签不存在或当前账号已变化'),{code:'WECHAT_TAGS_UNAVAILABLE'});
  const contactsResult=await this.adapter.listTagContacts(monitor.scope.tagIds);
  if(contactsResult?.accountId!==monitor.accountId||!Array.isArray(contactsResult?.contacts))throw Object.assign(new Error('微信标签联系人不可读'),{code:'WECHAT_TAG_CONTACTS_UNAVAILABLE'});
  const byId=new Map();
  for(const raw of contactsResult.contacts) {
   if(!raw||typeof raw.id!=='string'||!raw.id||typeof raw.name!=='string'||!raw.name)throw Object.assign(new Error('微信标签联系人缺少稳定标识'),{code:'WECHAT_TAG_CONTACTS_UNAVAILABLE'});
   const tagIds=[...new Set((Array.isArray(raw.tagIds)?raw.tagIds:[]).filter(id=>selected.has(id)))];
   if(!tagIds.length)continue;
   const old=byId.get(raw.id);byId.set(raw.id,{id:raw.id,name:raw.name,tagIds:[...new Set([...(old?.tagIds||[]),...tagIds]) ]});
  }
  const current=this.state.globalPreview;
  if(!current?.enabled||current.accountId!==monitor.accountId||current.scope?.kind!=='wechat-tags')return copy(current);
  const next={...current,tags:tags.map(tag=>({id:tag.id,name:tag.name,contactCount:Number.isInteger(tag.contactCount)?tag.contactCount:null})),resolvedContacts:[...byId.values()],lastScopeSyncAt:Date.now(),scopeRevision:randomUUID(),stage:'scanning',failureCode:null,updatedAt:Date.now()};
  this.save({...this.state,globalPreview:next});return copy(next);
 }
 tagUnreadChats(monitor,chats) {
  const contacts=new Map((monitor.resolvedContacts||[]).map(contact=>[contact.id,contact]));
  const byName=new Map();
  for(const contact of contacts.values()) byName.set(contact.name,(byName.get(contact.name)||[]).concat(contact));
  return this.unreadChats(chats).flatMap(chat=>{
   const exact=contacts.get(chat.id);const named=byName.get(chat.title)||[];const contact=exact||(named.length===1?named[0]:null);
   return contact?[{...chat,chatId:contact.id,id:contact.id,title:contact.name,tagIds:contact.tagIds}]:[];
  });
 }
 async draftCandidate({eventId,candidateId,replaceExisting=false}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(typeof eventId!=='string'||typeof candidateId!=='string'||typeof replaceExisting!=='boolean')throw new Error('INVALID_CANDIDATE');
  return this.locked(async()=>{
   const monitor=this.state.globalPreview;const event=monitor?.events?.find(item=>item.id===eventId);const candidate=event?.candidates?.find(item=>item.id===candidateId);
   if(!monitor?.enabled||!event||!candidate)throw new Error('CANDIDATE_NOT_FOUND');
   const accountId=await this.account(monitor.accountId);const contact={id:event.chatId,name:event.title,accountId};
   const composer=await this.adapter.readComposer(contact);const existing=String(composer?.text??composer?.value??'');
   if(existing&&!replaceExisting)return {status:'requires-replace-confirmation',contact,existingDraft:true};
   const result=await this.adapter.draft(contact,candidate.text,{replaceExisting});
   if(result?.status!=='drafted'||!result.evidence)throw new Error('WECHAT_DRAFT_UNKNOWN');
   return {status:'drafted',contact,evidence:result.evidence};
  });
 }
 unreadChats(chats) {
  return chats.filter(chat=>chat&&!excludedPreviewChat(chat)&&typeof chat.id==='string'&&typeof chat.title==='string'&&typeof chat.preview==='string'&&typeof chat.signature==='string'&&(chat.hasUnread===true||Number(chat.unreadCount)>0));
 }
 enqueueUnread(monitor,chats) {
  const completed={...(monitor.completed||{})};let events=[...(monitor.events||[])];
  for(const chat of chats) {
   const key=`${chat.id}:${chat.signature}`;
   if(completed[key]||events.some(event=>event.key===key&&event.status!=='cancelled')) continue;
   const previous=events.find(event=>event.chatId===chat.id&&event.status==='queued');
   const next={id:previous?.id||randomUUID(),key,chatId:chat.id,title:chat.title,chatType:chat.chatType,preview:chat.preview,unreadCount:Number(chat.unreadCount)||0,hasUnread:true,signature:chat.signature,status:'queued',draftStatus:'queued',receivedAt:previous?.receivedAt||Date.now(),updatedAt:Date.now()};
   events=previous?events.map(event=>event.id===previous.id?next:event):[...events,next];
  }
  const pending=new Set(['queued','locating','reading','generating','drafting']);
  const history=events.filter(event=>!pending.has(event.status)).slice(-100);
  return {events:events.filter(event=>pending.has(event.status)||history.includes(event)),baseline:Object.fromEntries(chats.map(chat=>[chat.id,chat.signature])),completed};
 }
 updateGlobalPreviewEvent(id,patch) {
  const monitor=this.state.globalPreview;
  this.save({...this.state,globalPreview:{...monitor,events:(monitor.events||[]).map(event=>event.id===id?{...event,...patch,updatedAt:Date.now()}:event),updatedAt:Date.now()}});
 }
 async prepareGlobalDraft(event,monitor) {
  if(excludedPreviewChat(event)) {
   this.updateGlobalPreviewEvent(event.id,{status:'skipped',draftStatus:'skipped',failureCode:null,skipReason:'EXCLUDED_CHAT_TYPE'});return;
  }
  const contact={id:event.chatId,name:event.title,accountId:monitor.accountId};
  try {
   this.updateGlobalPreviewEvent(event.id,{status:'locating',draftStatus:'locating',failureCode:null});
   const chat=await this.locked(async()=>{
    if(!this.previewEventActive(event.id,monitor.accountId,'locating'))return null;
    return this.adapter.readChat(contact);
   });
   if(!chat||!this.previewEventActive(event.id,monitor.accountId,'locating'))return;
   this.checkChat(chat,monitor.accountId,contact);
   this.updateGlobalPreviewEvent(event.id,{status:'reading',draftStatus:'reading'});
   // A chat row tells us that its most recent activity is unread. The helper
   // cannot reliably timestamp every visible bubble, so draft only the latest
   // incoming text instead of replaying old visible history.
   const messages=chat.messages.filter(message=>message.direction==='incoming'&&typeof message.text==='string'&&message.text.trim()).slice(-1);
   if(!messages.length)throw new Error('WECHAT_NEW_MESSAGE_UNCONFIRMED');
   if(!this.replyGenerator)throw new Error('MODEL_UNAVAILABLE');
   this.updateGlobalPreviewEvent(event.id,{status:'generating',draftStatus:'generating',incomingMessageIds:messages.map(message=>message.id)});
   const contactStyle=this.replyStyle(monitor.accountId,contact);
   const assessment=await this.assess({contact,message:messages.at(-1).text,recentContext:chat.messages.slice(-8),businessInstructions:contactStyle.relationship==='work'?monitor.businessInstructions||'':''});
   const reply=await this.replyGenerator({contact,messages,recentContext:chat.messages.slice(-20),contactStyle,businessInstructions:contactStyle.relationship==='work'?monitor.businessInstructions||'':'',style:monitor.style||'',...assessment});
   const text=typeof reply==='string'?reply:reply.text;
   const current=this.state.globalPreview;
   if(!current?.enabled||current.accountId!==monitor.accountId||!current.events?.some(item=>item.id===event.id&&item.status==='generating')) return;
   this.updateGlobalPreviewEvent(event.id,{status:'drafting',draftStatus:'drafting'});
   const result=await this.locked(async()=>{
    if(!this.previewEventActive(event.id,monitor.accountId,'drafting'))return null;
    this.assertReplyStyle(monitor.accountId,contact,contactStyle);
    return this.adapter.draft(contact,text,{replaceExisting:true});
   });
   if(!result)return;
   if(result?.status!=='drafted'||!result.evidence)throw new Error('WECHAT_DRAFT_UNKNOWN');
   const finalized=this.state.globalPreview;
   if(!finalized?.enabled||!finalized.events?.some(item=>item.id===event.id&&item.status==='drafting')) return;
   this.updateGlobalPreviewEvent(event.id,{status:'drafted',draftStatus:'drafted',draftText:text,knowledgeSources:typeof reply==='string'?[]:reply.knowledgeSources||[],...assessment,evidence:result.evidence,failureCode:null});
   const after=this.state.globalPreview;
   this.save({...this.state,globalPreview:{...after,completed:{...(after.completed||{}),[event.key]:Date.now()},updatedAt:Date.now()}});
  } catch(error) {
   if(this.state.globalPreview?.events?.some(item=>item.id===event.id&&item.status==='cancelled')) return;
   this.updateGlobalPreviewEvent(event.id,{status:'failed',draftStatus:'failed',failureCode:failure(error),responsibility:responsibility(failure(error))});
   if(HALT.has(failure(error))) {
    await this.globalPreview({enabled:false});
    this.save({...this.state,globalPreview:{...this.state.globalPreview,stage:'paused',failureCode:failure(error)}});
   }
  }
 }
 async prepareTagCandidates(event,monitor) {
  const contact={id:event.chatId,name:event.title,accountId:monitor.accountId};
  try {
   this.updateGlobalPreviewEvent(event.id,{status:'locating',draftStatus:'candidate-pending',failureCode:null});
   const chat=await this.locked(async()=>this.previewEventActive(event.id,monitor.accountId,'locating')?this.adapter.readChat(contact):null);
   if(!chat||!this.previewEventActive(event.id,monitor.accountId,'locating'))return;
   this.checkChat(chat,monitor.accountId,contact);
   const messages=chat.messages.filter(message=>message.direction==='incoming'&&typeof message.text==='string'&&message.text.trim()).slice(-1);
   if(!messages.length)throw new Error('WECHAT_NEW_MESSAGE_UNCONFIRMED');
   if(!this.replyGenerator)throw new Error('MODEL_UNAVAILABLE');
   this.updateGlobalPreviewEvent(event.id,{status:'generating',draftStatus:'candidate-pending',incomingMessageIds:messages.map(message=>message.id)});
   const contactStyle=this.replyStyle(monitor.accountId,contact);
   const assessment=await this.assess({contact,message:messages.at(-1).text,recentContext:chat.messages.slice(-8),businessInstructions:contactStyle.relationship==='work'?monitor.businessInstructions||'':''});
   const reply=await this.replyGenerator({contact,messages,recentContext:chat.messages.slice(-20),contactStyle,businessInstructions:contactStyle.relationship==='work'?monitor.businessInstructions||'':'',style:monitor.style||'',...assessment});
   const text=typeof reply==='string'?reply:reply.text;
   const current=this.state.globalPreview;
   if(!current?.enabled||current.accountId!==monitor.accountId||!current.events?.some(item=>item.id===event.id&&item.status==='generating'))return;
   let concise=text;
   try {
    const alternate=await this.replyGenerator({contact,messages,recentContext:chat.messages.slice(-20),contactStyle,businessInstructions:contactStyle.relationship==='work'?monitor.businessInstructions||'':'',style:`${monitor.style||''}\n更简短直接，只保留必要信息。`,...assessment});
    concise=typeof alternate==='string'?alternate:alternate.text;
   } catch { /* Preserve the primary candidate when an optional alternative fails. */ }
   const candidates=[{id:randomUUID(),label:'推荐回复',text},{id:randomUUID(),label:'简洁回复',text:concise}];
   this.updateGlobalPreviewEvent(event.id,{status:'candidates-ready',draftStatus:'not-drafted',candidates,knowledgeSources:typeof reply==='string'?[]:reply.knowledgeSources||[],...assessment,failureCode:null});
   const after=this.state.globalPreview;this.save({...this.state,globalPreview:{...after,completed:{...(after.completed||{}),[event.key]:Date.now()},updatedAt:Date.now()}});
  } catch(error) {
   if(this.state.globalPreview?.events?.some(item=>item.id===event.id&&item.status==='cancelled'))return;
   const code=failure(error);this.updateGlobalPreviewEvent(event.id,{status:'failed',draftStatus:'failed',failureCode:code,responsibility:responsibility(code)});
  }
 }
 previewEventActive(id,accountId,status) {
  const monitor=this.state.globalPreview;
  return !this.stopped&&monitor?.enabled&&monitor.accountId===accountId&&monitor.events.some(event=>event.id===id&&event.status===status);
 }
 scanGlobalPreview() {
  if(this.scanning)return this.scanning;
  this.scanning=this.locked(()=>this.inspectGlobalPreview()).finally(()=>{
   this.scanning=null;
   if(this.stopped&&!this.ticking&&!this.running)this.store.release();
  });
  return this.scanning;
 }
 async inspectGlobalPreview() {
  const monitor=this.state.globalPreview;
  const revision=this.previewRevision;
  if(!monitor?.enabled||this.stopped) return;
  try {
   const accountId=monitor.accountId;
   if(monitor.scope?.kind==='wechat-tags')await this.syncTagScope(monitor);
   const scoped=this.state.globalPreview;
   if(this.stopped||!scoped?.enabled||revision!==this.previewRevision)return;
   const result=await this.adapter.listChats();
   if(result?.accountId!==accountId||!Array.isArray(result?.chats))throw new Error('WECHAT_CHAT_LIST_UNAVAILABLE');
   const current=this.state.globalPreview;
   if(this.stopped||!current?.enabled||revision!==this.previewRevision)return;
   const queued=this.enqueueUnread(current,current.scope?.kind==='wechat-tags'?this.tagUnreadChats(current,result.chats):this.unreadChats(result.chats));
   this.save({...this.state,globalPreview:{
     ...current,
     ...queued,
     adapterKind:result.adapterKind||monitor.adapterKind||'accessibility',
     stage:'scanning',
     lastScanAt:Date.now(),
     consecutiveFailures:0,
     updatedAt:Date.now(),
     failureCode:null,
   }});
  } catch(error) {
   const code=failure(error);
   const current=this.state.globalPreview;
   if(this.stopped||!current?.enabled||revision!==this.previewRevision)return;
   this.save({...this.state,globalPreview:{
     ...current,
     enabled:current.enabled&&!HALT.has(code),
     stage:HALT.has(code)?'paused':'scanning',
     consecutiveFailures:(current.consecutiveFailures||0)+1,
     failureCode:code,
     updatedAt:Date.now(),
   }});
  }
 }
 checkChat(chat,accountId,contact) {
  if(chat.accountId!==accountId) throw new Error('WECHAT_ACCOUNT_CHANGED');
  if(chat.contactId!==contact.id) throw new Error('WECHAT_CONTACT_MISMATCH');
  if(!Array.isArray(chat.messages)||chat.messages.some(m=>typeof m.id!=='string'||!m.id)) throw new Error('WECHAT_MESSAGE_ID_UNAVAILABLE');
 }
 async inspectWatch(watch) {
  await this.account(watch.accountId);
  const chat=await this.adapter.readChat(watch.contact);this.checkChat(chat,watch.accountId,watch.contact);
  const prior=watch.observedIds||watch.seen;
  const currentIds=chat.messages.map(m=>m.id);
  const lastKnownIndex=prior.length?currentIds.indexOf(prior.at(-1)):-1;
  const overlapBefore=prior.filter(id=>currentIds.includes(id));
  const overlapAfter=currentIds.filter(id=>prior.includes(id));
  if(prior.length&&(lastKnownIndex<0||JSON.stringify(overlapBefore)!==JSON.stringify(overlapAfter))) {
   this.updateWatch(watch.id,{enabled:false,pending:[],failureCode:'WECHAT_HISTORY_RESYNC_REQUIRED',responsibility:'桌面自动化'});return null;
  }
  // The visible prefix can grow when history is scrolled into view. Only
  // messages after the previous tail are eligible incoming events.
  const fresh=chat.messages.slice(lastKnownIndex+1).filter(m=>!watch.seen.includes(m.id));
  const ownIds=new Set(this.state.tasks.filter(t=>t.accountId===watch.accountId&&t.contact.id===watch.contact.id&&t.status==='sent').flatMap(t=>[t.evidence?.messageId,t.evidence?.afterMessageId]).filter(Boolean));
  if(fresh.some(m=>m.direction==='outgoing'&&!ownIds.has(m.id))) {
   this.updateWatch(watch.id,{enabled:false,pending:[],failureCode:'WECHAT_MANUAL_TAKEOVER'});return null;
  }
  const incoming=fresh.filter(m=>m.direction==='incoming'&&typeof m.text==='string'&&m.text.trim());
  const pending=[...watch.pending,...incoming];
  const changedAt=incoming.length?Date.now():watch.changedAt;
  this.updateWatch(watch.id,{seen:[...new Set([...watch.seen,...currentIds])],observedIds:currentIds,pending,changedAt});
  if(!pending.length||Date.now()-changedAt<this.debounceMs) return null;
  return {...watch,pending,changedAt};
 }
 async tick() {
  if(this.stopped||this.readOnly)return;
  // Scan on every timer tick, even while the model is generating a reply.
  // Only native UI operations hold the shared lock, never model requests.
  await this.scanGlobalPreview();
  if(this.ticking||this.stopped||this.readOnly)return;this.ticking=true;
  try {
   while(!this.stopped&&this.state.globalPreview?.enabled) {
    const event=this.state.globalPreview.events.find(item=>item.status==='queued');
    if(!event)break;
    const monitor=this.state.globalPreview;
    await (monitor.scope?.kind==='wechat-tags'?this.prepareTagCandidates(event,monitor):this.prepareGlobalDraft(event,monitor));
   }
   for(const snapshot of this.state.watches.filter(w=>w.enabled)) {
    try {
     const batch=await this.locked(async()=>{
      const current=this.state.watches.find(w=>w.id===snapshot.id);return current?.enabled?this.inspectWatch(current):null;
     });
     if(!batch) continue;
     const requestId=`watch:${batch.id}:${batch.pending.at(-1).id}`;
     // Enqueue and cursor updates are separate durable writes. After a crash,
     // an existing task owns this batch even if the model would now reply differently.
     if(this.state.tasks.some(t=>t.accountId===batch.accountId&&t.requestId===requestId)) {
      this.updateWatch(batch.id,{pending:[]});continue;
     }
     if(!this.replyGenerator) throw new Error('MODEL_UNAVAILABLE');
     const contactStyle=this.replyStyle(batch.accountId,batch.contact);
     const assessment=await this.assess({contact:batch.contact,message:batch.pending.at(-1).text,recentContext:batch.pending.slice(-8),businessInstructions:contactStyle.relationship==='work'?batch.businessInstructions:''});
     const reply=await this.replyGenerator({contact:batch.contact,messages:copy(batch.pending),contactStyle,businessInstructions:contactStyle.relationship==='work'?batch.businessInstructions:'',style:batch.style,...assessment});
     this.assertReplyStyle(batch.accountId,batch.contact,contactStyle);
     const text=typeof reply==='string'?reply:reply.text;
     const knowledgeSources=typeof reply==='string'?[]:reply.knowledgeSources;
     const current=this.state.watches.find(w=>w.id===batch.id);
     if(!current?.enabled||current.revision!==batch.revision) continue;
     await this.send({contact:batch.contact,text,knowledgeSources,requestId,watchId:batch.id,accountId:batch.accountId,styleRevision:contactStyle.revision,...assessment});
     this.updateWatch(batch.id,{pending:[],failureCode:null});
    } catch(error) {
     const code=failure(error);this.updateWatch(snapshot.id,{failureCode:code,responsibility:responsibility(code),...(HALT.has(code)?{enabled:false}:{})});
    }
   }
  } finally {this.ticking=false;if(this.stopped&&!this.running&&!this.scanning)this.store.release();}
 }
 start() {if(!this.store.acquire()){this.readOnly=true;return;}this.readOnly=false;this.stopped=false;if(!this.timer){this.timer=setInterval(()=>{this.tick().catch(()=>{});this.kick();},this.pollMs);this.timer.unref?.();}this.kick();}
 stop() {this.stopped=true;if(this.timer)clearInterval(this.timer);this.timer=null;if(!this.running&&!this.ticking&&!this.scanning)this.store.release();}
}
