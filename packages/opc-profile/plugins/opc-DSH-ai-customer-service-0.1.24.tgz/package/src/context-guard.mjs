const clean = value => String(value ?? '').trim().normalize('NFKC');

export function normalizeContactName(value) {
  return clean(value).replace(/\s+/g, ' ');
}

export function assertContext(expected, actual) {
  const checks = [
    ['accountId', expected?.accountId, actual?.accountId, 'WECHAT_ACCOUNT_CHANGED'],
    ['window', expected?.windowBundleId, actual?.windowBundleId, 'WECHAT_WINDOW_NOT_FOUND'],
    ['contact', normalizeContactName(expected?.contactName), normalizeContactName(actual?.contactName), 'WECHAT_CHAT_CONTEXT_CHANGED'],
    ['session', expected?.sessionId, actual?.sessionId, 'WECHAT_SESSION_CHANGED'],
  ];
  for (const [, wanted, received, code] of checks) {
    if (wanted !== undefined && wanted !== null && clean(wanted) !== clean(received)) {
      throw Object.assign(new Error(code), { code });
    }
  }
  return true;
}

export function contextFromContact(contact, sessionId = '') {
  return {
    accountId: contact?.accountId ?? null,
    contactName: normalizeContactName(contact?.name || contact?.title),
    windowBundleId: contact?.windowBundleId || 'com.tencent.xinWeChat',
    sessionId,
  };
}
