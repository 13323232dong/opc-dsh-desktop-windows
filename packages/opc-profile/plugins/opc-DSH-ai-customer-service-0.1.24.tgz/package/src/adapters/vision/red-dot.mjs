import { VISION_ERROR_CODES, visionError } from './types.mjs';

const DEFAULTS = Object.freeze({ coarseThreshold: 0.01, fineThreshold: 0.04, redMin: 120, redDominance: 1.25 });

function pixelsOf(image) {
  if (!image || !Number.isInteger(image.width) || !Number.isInteger(image.height) ||
      image.width <= 0 || image.height <= 0 || !image.data || image.data.length < image.width * image.height * 4) {
    throw visionError(VISION_ERROR_CODES.IMAGE_INVALID);
  }
  return image;
}

export function scanRedDot(image, options = {}) {
  const source = pixelsOf(image);
  const config = { ...DEFAULTS, ...options };
  let red = 0;
  let edgeTouch = false;
  for (let y = 0; y < source.height; y += 1) {
    for (let x = 0; x < source.width; x += 1) {
      const offset = (y * source.width + x) * 4;
      const r = source.data[offset], g = source.data[offset + 1], b = source.data[offset + 2], a = source.data[offset + 3] ?? 255;
      if (a === 0) continue;
      if (r >= config.redMin && r > g * config.redDominance && r > b * config.redDominance) {
        red += 1;
        edgeTouch ||= x === 0 || y === 0 || x === source.width - 1 || y === source.height - 1;
      }
    }
  }
  const percentage = red / (source.width * source.height);
  const threshold = options.mode === 'fine' ? config.fineThreshold : config.coarseThreshold;
  return { hasUnread: percentage >= threshold, percentage, edgeTouch, retryRecommended: edgeTouch };
}
