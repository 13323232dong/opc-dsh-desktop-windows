import { scanRedDot } from './red-dot.mjs';
import { VisionProvider } from './vision-provider.mjs';

export class SightFlowVisionAdapter {
  constructor({ screenshot, click, type, provider, status, readChat, readComposer, sendAction, readSendEvidence, accountId = '' } = {}) {
    this.screenshot = screenshot;
    this.click = click;
    this.type = type;
    this.provider = provider instanceof VisionProvider ? provider : new VisionProvider(provider);
    this._status = status;
    this._readChat = readChat;
    this._readComposer = readComposer;
    this._sendAction = sendAction;
    this._readSendEvidence = readSendEvidence;
    this.accountId = accountId;
  }

  async status() { return this._status(); }
  async listChats() {
    const image = await this.screenshot();
    const list = await this.provider.locateTarget(image, '定位微信聊天列表', image);
    const unread = scanRedDot(image, { mode: 'coarse' });
    return { accountId: this.accountId, adapterKind: 'vision', chats: [], visual: { list, unread } };
  }
  async findContact(name) { return this._locateContact(name); }
  async openChat(contact) { return this._locateContact(contact?.name || contact?.title); }
  async _locateContact(name) {
    const image = await this.screenshot();
    const target = await this.provider.locateTarget(image, `定位微信联系人：${name}`, image);
    if (target.label !== 'unread_contact' && target.label !== 'chat_title') {
      throw Object.assign(new Error('视觉未定位到联系人'), { code: 'VISION_TARGET_UNCERTAIN' });
    }
    await this.click(target.bbox);
    return { id: contactId(name), name, title: name, accountId: this.accountId, adapterKind: 'vision' };
  }
  async readChat(contact) { return this._readChat(contact); }
  async readComposer(contact) { return this._readComposer(contact); }
  async draft(contact, text, options) { return this._write(contact, text, options); }
  async _write(contact, text) {
    const image = await this.screenshot();
    const target = await this.provider.locateTarget(image, '定位微信聊天输入框', image);
    if (target.label !== 'chat_input') throw Object.assign(new Error('微信输入框不可用'), { code: 'WECHAT_COMPOSER_UNAVAILABLE' });
    await this.click(target.bbox);
    await this.type(text);
    return { status: 'drafted', evidence: { kind: 'input_draft', adapterKind: 'vision' } };
  }
  async sendAction(contact, text) { return this._sendAction(contact, text); }
  async readSendEvidence(contact, text, before) { return this._readSendEvidence(contact, text, before); }
}

function contactId(name) { return `${name}`.normalize('NFKC'); }

export function createUnavailableVisionAdapter() {
  const unavailable = async () => { throw Object.assign(new Error('桌面视觉桥尚不可用'), { code: 'VISION_PROVIDER_UNAVAILABLE' }); };
  return {
    status: unavailable,
    listChats: unavailable,
    findContact: unavailable,
    openChat: unavailable,
    readChat: unavailable,
    readComposer: unavailable,
    draft: unavailable,
    sendAction: unavailable,
    readSendEvidence: unavailable,
  };
}
