export const VISION_ERROR_CODES = Object.freeze({
  IMAGE_INVALID: 'VISION_IMAGE_INVALID',
  TARGET_UNCERTAIN: 'VISION_TARGET_UNCERTAIN',
  PROVIDER_UNAVAILABLE: 'VISION_PROVIDER_UNAVAILABLE',
});

export function visionError(code, message = code) {
  return Object.assign(new Error(message), { code });
}

export function assertTarget(target, bounds) {
  if (!target || !Number.isFinite(target.confidence) || target.confidence < 0.7) {
    throw visionError(VISION_ERROR_CODES.TARGET_UNCERTAIN);
  }
  const labels = new Set(['chat_list', 'unread_contact', 'chat_input', 'chat_title']);
  if (!labels.has(target.label) || !['x', 'y', 'width', 'height'].every(key => Number.isFinite(target.bbox?.[key]))) {
    throw visionError(VISION_ERROR_CODES.TARGET_UNCERTAIN);
  }
  if (bounds && (target.bbox.x < 0 || target.bbox.y < 0 ||
    target.bbox.x + target.bbox.width > bounds.width ||
    target.bbox.y + target.bbox.height > bounds.height)) {
    throw visionError(VISION_ERROR_CODES.TARGET_UNCERTAIN);
  }
  return target;
}
