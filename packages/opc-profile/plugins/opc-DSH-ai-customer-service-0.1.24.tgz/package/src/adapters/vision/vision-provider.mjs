import { assertTarget, VISION_ERROR_CODES, visionError } from './types.mjs';

export class VisionProvider {
  constructor({ locate, timeoutMs = 8000, minConfidence = 0.7 } = {}) {
    this.locate = locate;
    this.timeoutMs = timeoutMs;
    this.minConfidence = minConfidence;
  }

  async locateTarget(image, prompt, bounds) {
    if (typeof this.locate !== 'function') throw visionError(VISION_ERROR_CODES.PROVIDER_UNAVAILABLE);
    const timeout = new Promise((_, reject) => setTimeout(() => reject(visionError(VISION_ERROR_CODES.PROVIDER_UNAVAILABLE)), this.timeoutMs));
    const result = await Promise.race([Promise.resolve(this.locate(image, prompt)), timeout]);
    return assertTarget({ ...result, confidence: result?.confidence ?? 0 }, bounds);
  }
}
