const REQUIRED_METHODS = [
  'status',
  'listChats',
  'findContact',
  'openChat',
  'readChat',
  'readComposer',
  'draft',
  'sendAction',
  'readSendEvidence',
];

export const adapterMethods = Object.freeze([...REQUIRED_METHODS]);

export function normalizeAutomationError(error, fallback = 'WECHAT_AUTOMATION_ERROR') {
  const code = String(error?.code || fallback);
  const stable = /^[A-Z][A-Z0-9_]{2,80}$/.test(code) ? code : fallback;
  return Object.assign(new Error(String(error?.message || stable)), { code: stable });
}

export function assertAdapterContract(adapter, label = 'wechat adapter') {
  if (!adapter || typeof adapter !== 'object') {
    throw Object.assign(new TypeError(`${label} is required`), { code: 'WECHAT_ADAPTER_INVALID' });
  }
  const missing = REQUIRED_METHODS.filter(name => typeof adapter[name] !== 'function');
  if (missing.length) {
    throw Object.assign(new TypeError(`${label} missing methods: ${missing.join(', ')}`), {
      code: 'WECHAT_ADAPTER_CONTRACT_INVALID',
      missing,
    });
  }
  return adapter;
}

export function adapterResult(result, adapterKind) {
  if (!result || typeof result !== 'object') {
    throw Object.assign(new Error('adapter returned an invalid result'), { code: 'WECHAT_ADAPTER_RESULT_INVALID' });
  }
  return { adapterKind, ...result };
}
