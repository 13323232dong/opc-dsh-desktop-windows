import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "opc-second-brain";
export declare const inject: string[];
export interface Config {
    readonly desktopMode?: boolean;
    readonly documentsDir?: string;
    readonly stateDir?: string;
    /** Injected by the trusted desktop host; never accepted from browser input. */
    readonly accountKey?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export { SecondBrainService, resolveSecondBrainPaths } from './second-brain.js';
export type { SecondBrainServiceOptions } from './second-brain.js';
export { SecondBrainError } from './types.js';
export type { SecondBrainSearchResponse, SecondBrainSearchResult, SecondBrainStatus, SecondBrainStatusName } from './types.js';
