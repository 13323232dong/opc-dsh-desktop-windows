import { writeFile } from 'node:fs/promises';
import { build } from 'esbuild';

const id = '@opc/DSH-ai-customer-service';
const result = await build({
 entryPoints:['src/client.jsx'],
 bundle:true,
 format:'cjs',
 platform:'browser',
 external:['react','react/jsx-runtime'],
 write:false,
 outfile:'lib/client.js',
 jsx:'automatic'
});
const bundle = result.outputFiles?.[0]?.text;
if (!bundle) throw new Error('AI customer-service client build produced no output');
await writeFile(
 'lib/client.js',
 `window.__ModuleLoader__.load({ id: ${JSON.stringify(id)}, factory: (require) => {\n` +
 'var module = { exports: {} };\nvar exports = module.exports;\n' +
 bundle +
 '\nreturn module.exports;\n}});\n',
 'utf8'
);
