"""Closed WeChat draft/send state machine.

The flow never reports a send as successful until the visible chat surface
confirms the outgoing message. Callers receive a closed result for any failed
verification and must create a fresh draft before trying again.
"""

from __future__ import annotations

import hashlib
from typing import Protocol

from worker.ime import ImeController


class WeChatSurface(Protocol):
    def verify_draft(self, text: str) -> bool: ...

    def tap_send(self) -> None: ...

    def verify_sent(self, text: str) -> bool: ...


class WeChatMessageFlow:
    def __init__(self, ime: ImeController, surface: WeChatSurface) -> None:
        self._ime = ime
        self._surface = surface
        self._prepared_digest: str | None = None

    def prepare(self, text: str) -> dict[str, str | bool]:
        self._prepared_digest = None
        self._ime.enter_text(text)
        if not self._surface.verify_draft(text):
            return self._closed("draft-not-verified")

        digest = self._digest(text)
        self._prepared_digest = digest
        return {"status": "drafted", "verified": True, "textHash": digest}

    def send(self, text: str, prepared_text_hash: str) -> dict[str, str | bool]:
        expected = self._digest(text)
        if prepared_text_hash != expected or self._prepared_digest != expected:
            return self._closed("prepared-text-mismatch")

        self._prepared_digest = None
        self._surface.tap_send()
        if not self._surface.verify_sent(text):
            return self._closed("send-not-verified")
        return {"status": "sent", "verified": True, "textHash": expected}

    @staticmethod
    def _digest(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    @staticmethod
    def _closed(reason: str) -> dict[str, str]:
        return {"status": "closed", "reason": reason}
