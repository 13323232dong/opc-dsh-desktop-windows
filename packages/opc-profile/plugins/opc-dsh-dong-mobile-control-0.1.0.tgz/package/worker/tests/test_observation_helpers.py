import unittest
import xml.etree.ElementTree as ElementTree

from worker.mobile_worker import current_focus_package, ui_tree_has_package


class ObservationHelpersTest(unittest.TestCase):
    def test_current_focus_requires_the_last_focused_package(self):
        dump = "mCurrentFocus=null\nmCurrentFocus=Window{abc u0 com.tencent.mm/com.tencent.mm.ui.LauncherUI}"
        self.assertEqual(current_focus_package(dump), "com.tencent.mm")

    def test_empty_or_other_package_ui_tree_is_not_accepted_as_wechat(self):
        empty = ElementTree.fromstring('<hierarchy><node package="com.tencent.mm" /></hierarchy>')
        launcher = ElementTree.fromstring('<hierarchy><node package="com.huawei.android.launcher" text="桌面" /></hierarchy>')
        self.assertTrue(ui_tree_has_package(empty, "com.tencent.mm"))
        self.assertFalse(ui_tree_has_package(launcher, "com.tencent.mm"))

    def test_zero_sized_wechat_root_has_no_accessible_content(self):
        root = ElementTree.fromstring('<hierarchy><node package="com.tencent.mm" bounds="[0,0][0,0]" /></hierarchy>')
        self.assertTrue(ui_tree_has_package(root, "com.tencent.mm"))
        self.assertFalse(any(node.attrib.get("text") or node.attrib.get("content-desc") for node in root.iter("node")))


if __name__ == "__main__":
    unittest.main()
