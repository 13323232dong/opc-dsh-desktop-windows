import json
import subprocess
import sys
import unittest
from pathlib import Path


class MobileWorkerContractTest(unittest.TestCase):
    def test_worker_accepts_parallel_jsonl_requests_without_shell_input(self):
        worker = Path(__file__).parents[1] / "mobile_worker.py"
        proc = subprocess.run(
            [sys.executable, str(worker)],
            input="\n".join([
                json.dumps({"requestId": "a", "operation": "task_status", "deviceId": "device-a", "payload": {"taskId": "task-a"}}),
                json.dumps({"requestId": "b", "operation": "task_status", "deviceId": "device-b", "payload": {"taskId": "task-b"}}),
            ]) + "\n",
            text=True,
            capture_output=True,
            timeout=5,
        )
        self.assertEqual(proc.returncode, 0)
        rows = [json.loads(line) for line in proc.stdout.splitlines()]
        self.assertEqual({row["requestId"] for row in rows}, {"a", "b"})


if __name__ == "__main__":
    unittest.main()
