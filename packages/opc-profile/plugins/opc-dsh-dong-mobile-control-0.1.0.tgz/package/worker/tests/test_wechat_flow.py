import hashlib
import unittest

from worker.ime import ImeController, TextEntryResult
from worker.wechat_flow import WeChatMessageFlow


class FakeImeDevice:
    def __init__(self):
        self.current_ime = "com.sohu.inputmethod.sogou/.SogouIME"
        self.calls = []
        self.draft = ""

    def get_ime(self):
        self.calls.append("get_ime")
        return self.current_ime

    def set_ime(self, ime):
        self.calls.append(("set_ime", ime))
        self.current_ime = ime

    def focus_input(self):
        self.calls.append("focus_input")

    def clear_text(self):
        self.calls.append("clear_text")
        self.draft = ""

    def input_text(self, text):
        self.calls.append(("input_text", text))
        self.draft = text


class FakeWeChatSurface:
    def __init__(self, draft_matches=True, sent_matches=True):
        self.draft_matches = draft_matches
        self.sent_matches = sent_matches
        self.calls = []

    def focus_input(self):
        self.calls.append("focus_input")

    def verify_draft(self, text):
        self.calls.append(("verify_draft", text))
        return self.draft_matches

    def tap_send(self):
        self.calls.append("tap_send")

    def verify_sent(self, text):
        self.calls.append(("verify_sent", text))
        return self.sent_matches


class ImeControllerTest(unittest.TestCase):
    def test_preserves_original_ime_and_refocuses_after_switch_before_input(self):
        device = FakeImeDevice()
        controller = ImeController(device, "com.adbkeyboard/.AdbIME")

        result = controller.enter_text("测试AI发送")

        self.assertEqual(result, TextEntryResult(status="drafted"))
        self.assertEqual(device.current_ime, "com.sohu.inputmethod.sogou/.SogouIME")
        self.assertEqual(
            device.calls,
            [
                "get_ime",
                ("set_ime", "com.adbkeyboard/.AdbIME"),
                "focus_input",
                "clear_text",
                ("input_text", "测试AI发送"),
                ("set_ime", "com.sohu.inputmethod.sogou/.SogouIME"),
            ],
        )

    def test_restores_original_ime_when_input_fails(self):
        class FailingInputDevice(FakeImeDevice):
            def input_text(self, text):
                super().input_text(text)
                raise RuntimeError("input unavailable")

        device = FailingInputDevice()
        controller = ImeController(device, "com.adbkeyboard/.AdbIME")

        with self.assertRaisesRegex(RuntimeError, "input unavailable"):
            controller.enter_text("测试")

        self.assertEqual(device.current_ime, "com.sohu.inputmethod.sogou/.SogouIME")


class WeChatMessageFlowTest(unittest.TestCase):
    def _flow(self, *, draft_matches=True, sent_matches=True):
        device = FakeImeDevice()
        surface = FakeWeChatSurface(draft_matches=draft_matches, sent_matches=sent_matches)
        return WeChatMessageFlow(ImeController(device, "com.adbkeyboard/.AdbIME"), surface), device, surface

    def test_prepare_requires_refocus_after_ime_switch_and_returns_draft_receipt(self):
        flow, device, surface = self._flow()

        result = flow.prepare("测试AI发送")

        self.assertEqual(result["status"], "drafted")
        self.assertEqual(result["textHash"], hashlib.sha256("测试AI发送".encode()).hexdigest())
        self.assertEqual(device.calls[2], "focus_input")
        self.assertEqual(surface.calls, [("verify_draft", "测试AI发送")])

    def test_draft_verification_failure_is_closed_and_never_exposes_send(self):
        flow, _, surface = self._flow(draft_matches=False)

        result = flow.prepare("测试AI发送")

        self.assertEqual(result, {"status": "closed", "reason": "draft-not-verified"})
        self.assertNotIn("tap_send", surface.calls)

    def test_send_verification_failure_is_closed(self):
        flow, _, surface = self._flow(sent_matches=False)

        prepared = flow.prepare("测试AI发送")
        result = flow.send("测试AI发送", prepared["textHash"])

        self.assertEqual(result, {"status": "closed", "reason": "send-not-verified"})
        self.assertEqual(surface.calls[-2:], ["tap_send", ("verify_sent", "测试AI发送")])

    def test_send_rejects_a_text_different_from_the_prepared_draft(self):
        flow, _, surface = self._flow()
        prepared = flow.prepare("测试AI发送")

        result = flow.send("另一条消息", prepared["textHash"])

        self.assertEqual(result, {"status": "closed", "reason": "prepared-text-mismatch"})
        self.assertNotIn("tap_send", surface.calls)


if __name__ == "__main__":
    unittest.main()
