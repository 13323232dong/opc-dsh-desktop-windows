#!/usr/bin/env python3
"""Small JSONL worker for the self-built OPC mobile plugin.

The worker intentionally owns a closed operation vocabulary. It never accepts
arbitrary shell text from the model or the DSH host.
"""

from __future__ import annotations

import json
import base64
import contextlib
import hashlib
import io
import os
import subprocess
import sys
import xml.etree.ElementTree as ElementTree
import re
import threading
import time
import tempfile
from concurrent.futures import ThreadPoolExecutor
from typing import Any

TASK_STATUS: dict[str, str] = {}


def emit(request_id: str, status: str, result: Any = None, error_code: str | None = None, error_message: str | None = None) -> None:
    payload: dict[str, Any] = {"requestId": request_id, "status": status}
    if result is not None:
        payload["result"] = result
    if error_code is not None:
        payload["errorCode"] = error_code
    if error_message is not None:
        payload["errorMessage"] = error_message[:500]
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def adb(device: str, *arguments: str) -> subprocess.CompletedProcess[str]:
    # Arguments are fixed by dispatch_operation; no model-authored command is accepted.
    return subprocess.run(["adb", "-s", device, *arguments], check=False, capture_output=True, text=True, timeout=20)


def dispatch_operation(operation: str, device: str, payload: dict[str, Any]) -> Any:
    if operation == "device_list":
        result = subprocess.run(["adb", "devices", "-l"], check=False, capture_output=True, text=True, timeout=10)
        devices = []
        for line in result.stdout.splitlines()[1:]:
            fields = line.split()
            if len(fields) >= 2 and fields[1] == "device":
                devices.append({"deviceId": fields[0], "state": fields[1], "details": " ".join(fields[2:])})
        return {"devices": devices}
    if operation == "device_status":
        result = adb(device, "get-state")
        props = adb(device, "shell", "getprop", "ro.product.model")
        android = adb(device, "shell", "getprop", "ro.build.version.release")
        return {"deviceId": device, "state": result.stdout.strip() or "offline", "model": props.stdout.strip(), "androidVersion": android.stdout.strip()}
    if operation == "screenshot":
        result = subprocess.run(["adb", "-s", device, "exec-out", "screencap", "-p"], check=False, capture_output=True, timeout=20)
        if result.returncode != 0:
            raise RuntimeError("无法获取手机屏幕")
        # The first slice is enough for a health/read-only response; image delivery is added in the next phase.
        return {"deviceId": device, "bytes": len(result.stdout), "mediaType": "image/png"}
    if operation == "screen_read":
        result = adb(device, "shell", "dumpsys", "window", "windows")
        return {"deviceId": device, "foreground": result.stdout[-4_000:]}
    if operation == "launch_app":
        result = adb(device, "shell", "monkey", "-p", str(payload["packageName"]), "1")
        if result.returncode != 0:
            raise RuntimeError("启动白名单应用失败")
        return {"deviceId": device, "packageName": payload["packageName"], "started": True}
    if operation == "tap":
        result = adb(device, "shell", "input", "tap", str(payload["x"]), str(payload["y"]))
        if result.returncode != 0:
            raise RuntimeError("点击操作失败")
        return {"deviceId": device, "action": "tap", "x": payload["x"], "y": payload["y"]}
    if operation == "swipe":
        result = adb(device, "shell", "input", "swipe", str(payload["x1"]), str(payload["y1"]), str(payload["x2"]), str(payload["y2"]), str(payload.get("durationMs", 300)))
        if result.returncode != 0:
            raise RuntimeError("滑动操作失败")
        return {"deviceId": device, "action": "swipe"}
    if operation == "input_text":
        # AutoGLM handles Unicode input through its approved helper; this direct
        # primitive intentionally accepts only ASCII until that adapter is enabled.
        text = str(payload["text"])
        if not text.isascii():
            raise ValueError("当前输入工具暂只支持 ASCII，中文输入由 AutoGLM 适配器处理")
        result = adb(device, "shell", "input", "text", text)
        if result.returncode != 0:
            raise RuntimeError("文本输入失败")
        return {"deviceId": device, "action": "input_text", "length": len(text)}
    if operation == "press_back":
        result = adb(device, "shell", "input", "keyevent", "4")
        if result.returncode != 0:
            raise RuntimeError("返回操作失败")
        return {"deviceId": device, "action": "back"}
    if operation == "task_status":
        task_id = str(payload["taskId"])
        return {"taskId": task_id, "status": TASK_STATUS.get(task_id, "queued"), "provider": "open-autoglm"}
    if operation == "autoglm_plan":
        return autoglm_plan(device, str(payload["task"]))
    if operation == "planner_observe":
        return planner_observe(device)
    if operation == "wechat_read_current_chat":
        return wechat_read_current_chat(device)
    if operation == "wechat_visual_observe":
        return wechat_visual_observe(device)
    if operation == "wechat_send_message":
        return wechat_send_message(device, str(payload["text"]), str(payload["expectedTextDigest"]))
    if operation == "wechat_visual_prepare_reply":
        return wechat_visual_prepare_reply(device, str(payload["text"]), str(payload.get("contact", "")).strip() or None)
    if operation == "douyin_open":
        return launch_allowed_app(device, "com.ss.android.ugc.aweme")
    if operation == "douyin_swipe_next":
        return douyin_swipe_next(device)
    if operation == "douyin_like_current":
        return douyin_like_current(device)
    if operation == "douyin_verify_liked":
        return douyin_verify_liked(device)
    if operation == "alipay_open":
        return launch_allowed_app(device, "com.eg.android.AlipayGphone")
    if operation == "alipay_read_screen":
        return alipay_read_screen(device)
    raise ValueError("不支持的手机操作")


def launch_allowed_app(device: str, package_name: str) -> dict[str, Any]:
    result = adb(device, "shell", "monkey", "-p", package_name, "1")
    if result.returncode != 0:
        raise RuntimeError("启动应用失败")
    return {"deviceId": device, "packageName": package_name, "started": True}


def planner_observe(device: str) -> dict[str, Any]:
    """Capture one bounded internal-only screenshot for GELab shadow evaluation."""
    screenshot = subprocess.run(["adb", "-s", device, "exec-out", "screencap", "-p"], check=False, capture_output=True, timeout=20)
    if screenshot.returncode != 0 or not screenshot.stdout:
        raise RuntimeError("无法获取手机屏幕")
    if len(screenshot.stdout) > 6_000_000:
        raise RuntimeError("手机屏幕图像过大")
    foreground = adb(device, "shell", "dumpsys", "window").stdout
    package_name = current_focus_package(foreground)
    if not package_name:
        raise RuntimeError("无法识别当前前台应用")
    digest = hashlib.sha256(screenshot.stdout).hexdigest()
    now = str(time.time_ns())
    return {
        "observationId": hashlib.sha256(f"{device}:{now}".encode()).hexdigest()[:32],
        "packageName": package_name,
        "pageFingerprint": hashlib.sha256(foreground.encode()).hexdigest()[:32],
        "screenDigest": digest,
        "screenshotDataUrl": "data:image/png;base64," + base64.b64encode(screenshot.stdout).decode("ascii"),
    }


def screen_size(device: str) -> tuple[int, int]:
    result = adb(device, "shell", "wm", "size")
    match = re.search(r"(\d+)x(\d+)", result.stdout)
    if match is None:
        return 1080, 2388
    return int(match.group(1)), int(match.group(2))


def douyin_swipe_next(device: str) -> dict[str, Any]:
    if current_focus_package(adb(device, "shell", "dumpsys", "window").stdout) != "com.ss.android.ugc.aweme":
        raise RuntimeError("DOUYIN_NOT_FOREGROUND")
    width, height = screen_size(device)
    result = adb(device, "shell", "input", "swipe", str(width // 2), str(int(height * 0.82)), str(width // 2), str(int(height * 0.22)), "450")
    if result.returncode != 0:
        raise RuntimeError("抖音滑动失败")
    return {"deviceId": device, "action": "next", "app": "douyin"}


def douyin_like_current(device: str) -> dict[str, Any]:
    if current_focus_package(adb(device, "shell", "dumpsys", "window").stdout) != "com.ss.android.ugc.aweme":
        raise RuntimeError("DOUYIN_NOT_FOREGROUND")
    plan = autoglm_plan(device, "只观察当前抖音视频页面。识别右侧点赞按钮是否已点亮；如果明确未点赞，返回点击点赞按钮的坐标；如果已点赞或无法确认，只返回 finish。不要执行其他操作。")
    action = plan.get("action") if isinstance(plan, dict) else None
    if not isinstance(action, dict) or action.get("_metadata") != "do" or action.get("action") != "Tap":
        return {"deviceId": device, "liked": False, "changed": False, "verification": "not-confirmed", "plan": plan}
    element = action.get("element")
    if not isinstance(element, list) or len(element) != 2 or not all(isinstance(value, int) for value in element):
        raise RuntimeError("DOUYIN_LIKE_TARGET_UNAVAILABLE")
    width, height = screen_size(device)
    x, y = int(element[0]), int(element[1])
    x = round(x * width / 1000)
    y = round(y * height / 1000)
    if x < 0 or y < 0 or x > width or y > height:
        raise RuntimeError("DOUYIN_LIKE_TARGET_UNAVAILABLE")
    result = adb(device, "shell", "input", "tap", str(x), str(y))
    if result.returncode != 0:
        raise RuntimeError("DOUYIN_LIKE_FAILED")
    return {"deviceId": device, "liked": True, "changed": True, "coordinate": [x, y]}


def douyin_verify_liked(device: str) -> dict[str, Any]:
    if current_focus_package(adb(device, "shell", "dumpsys", "window").stdout) != "com.ss.android.ugc.aweme":
        raise RuntimeError("DOUYIN_NOT_FOREGROUND")
    plan = autoglm_plan(device, "只观察当前抖音视频页面，判断右侧点赞按钮是否已点亮。不要点击。只返回已点赞、未点赞或无法确认。")
    message = str((plan.get("action") or {}).get("message", "")) if isinstance(plan, dict) else ""
    lowered = message.lower()
    status = "liked" if "已点赞" in message or "已点亮" in message or "liked" in lowered else "not-confirmed"
    return {"deviceId": device, "liked": status == "liked", "verification": status, "plan": plan}


def alipay_read_screen(device: str) -> dict[str, Any]:
    if current_focus_package(adb(device, "shell", "dumpsys", "window").stdout) != "com.eg.android.AlipayGphone":
        raise RuntimeError("ALIPAY_NOT_FOREGROUND")
    result = adb(device, "shell", "dumpsys", "window", "windows")
    return {"deviceId": device, "packageName": "com.eg.android.AlipayGphone", "foreground": result.stdout[-4_000:], "readOnly": True}


def wechat_read_current_chat(device: str) -> dict[str, Any]:
    """Read only visible WeChat UI text from the current foreground window."""
    try:
        _, visible, digest = read_wechat_ui(device)
    except RuntimeError as error:
        if str(error) != "WECHAT_UI_UNAVAILABLE":
            raise
        return wechat_visual_observe(device)
    return {
        "packageName": "com.tencent.mm",
        "observationMode": "uiautomator",
        "visibleTexts": visible,
        "textDigest": digest,
        "truncated": len(visible) >= 100,
    }


def wechat_visual_prepare_reply(device: str, text: str, contact: str | None = None) -> dict[str, Any]:
    """Locate the custom-rendered WeChat input, type locally, then verify by vision."""
    window = adb(device, "shell", "dumpsys", "window")
    if current_focus_package(window.stdout) != "com.tencent.mm":
        raise RuntimeError("WECHAT_NOT_FOREGROUND")
    if contact is not None:
        ocr_point = ocr_contact_point(device, contact)
        if ocr_point is not None:
            ox, oy = ocr_point
            result = adb(device, "shell", "input", "tap", str(ox), str(oy))
            if result.returncode != 0:
                raise RuntimeError("WECHAT_VISUAL_CONTACT_TARGET_UNAVAILABLE")
            time.sleep(0.5)
        else:
            # The model decides whether a bounded vertical scroll is needed;
            # OCR remains the authority for the final text row when available.
            for _ in range(3):
                navigation = autoglm_plan(device, f"只操作规划当前微信界面：在聊天列表中找到联系人‘{contact}’，返回该联系人行中心的 Tap 坐标；如果联系人不在可见区域，只返回从屏幕下方向上方的 Swipe；如果当前已经是该联系人聊天则返回 finish。不要选择其他联系人，不要返回横向滑动。")
                navigation_point = visual_tap_point(navigation, device)
                if navigation_point is not None:
                    width, height = screen_size(device)
                    nx, ny = navigation_point
                    if not (0 <= nx <= width and 0 <= ny <= height):
                        raise RuntimeError("WECHAT_VISUAL_CONTACT_TARGET_UNAVAILABLE")
                    result = adb(device, "shell", "input", "tap", str(nx), str(ny))
                    if result.returncode != 0:
                        raise RuntimeError("WECHAT_VISUAL_CONTACT_TARGET_UNAVAILABLE")
                    time.sleep(0.5)
                    break
                if visual_swipe_up(navigation, device):
                    time.sleep(0.4)
                    continue
                break
        confirmation = autoglm_plan(device, f"只观察当前微信界面，确认顶部聊天标题是否明确显示‘{contact}’。不要点击或输入。若不是该联系人或无法确认，返回 finish(message=未确认)；若确认，返回 finish(message=已确认 {contact})。")
        confirmation_message = str((confirmation.get("action") or {}).get("message", "")) if isinstance(confirmation, dict) else ""
        if contact not in confirmation_message:
            raise RuntimeError("WECHAT_VISUAL_CONTACT_NOT_VERIFIED")
    plan = autoglm_plan(device, "只观察当前微信私聊界面。定位底部文字输入框中心坐标。不要点击或输入。只返回 Tap 坐标；无法确认则 finish。")
    point = visual_tap_point(plan, device)
    if point is None:
        raise RuntimeError("WECHAT_VISUAL_INPUT_TARGET_UNAVAILABLE")
    width, height = screen_size(device)
    x, y = point
    if not (0 <= x <= width and 0 <= y <= height and y > int(height * 0.65)):
        raise RuntimeError("WECHAT_VISUAL_INPUT_TARGET_UNAVAILABLE")
    tap_result = adb(device, "shell", "input", "tap", str(x), str(y))
    if tap_result.returncode != 0:
        raise RuntimeError("WECHAT_VISUAL_INPUT_TARGET_UNAVAILABLE")
    type_with_approved_keyboard(device, text, focus_point=point)
    verification = autoglm_plan(device, f"只观察当前微信聊天输入框。确认输入框中是否完整显示以下文本：{text}。不要点击、发送或修改。只返回 finish(message=...)。")
    message = str((verification.get("action") or {}).get("message", "")) if isinstance(verification, dict) else ""
    if text not in message and not any(token in message for token in ("已输入", "显示", "完整")):
        raise RuntimeError("WECHAT_VISUAL_INPUT_NOT_VERIFIED")
    return {"packageName": "com.tencent.mm", "status": "drafted", "verified": True, "textHash": hashlib.sha256(text.encode("utf-8")).hexdigest(), "inputPoint": [x, y]}


def ocr_contact_point(device: str, contact: str) -> tuple[int, int] | None:
    """Use local macOS Vision OCR for an exact visible contact row."""
    script = os.path.join(os.path.dirname(__file__), "macos_ocr.swift")
    if sys.platform != "darwin" or not os.path.exists(script):
        return None
    screenshot = subprocess.run(["adb", "-s", device, "exec-out", "screencap", "-p"], check=False, capture_output=True, timeout=20)
    if screenshot.returncode != 0 or not screenshot.stdout:
        return None
    try:
        with tempfile.NamedTemporaryFile(suffix=".png") as image_file:
            image_file.write(screenshot.stdout)
            image_file.flush()
            result = subprocess.run(["swift", script, image_file.name], check=False, capture_output=True, text=True, timeout=20)
        width, height = screen_size(device)
        for line in result.stdout.splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            recognized = str(item.get("text", "")).strip()
            if recognized != contact and contact not in recognized:
                continue
            confidence = float(item.get("confidence", 0))
            if confidence < 0.65:
                continue
            x = int((float(item["x"]) + float(item["width"]) / 2) * width)
            y = int((1 - float(item["y"]) - float(item["height"]) / 2) * height)
            if 0 <= x <= width and 0 <= y <= height:
                return x, y
    except (OSError, subprocess.SubprocessError, ValueError, KeyError):
        return None
    return None


def visual_tap_point(plan: Any, device: str | None = None) -> tuple[int, int] | None:
    action = plan.get("action") if isinstance(plan, dict) else None
    if not isinstance(action, dict) or action.get("_metadata") != "do" or action.get("action") != "Tap":
        return None
    element = action.get("element")
    if not isinstance(element, list) or len(element) != 2 or not all(isinstance(value, int) for value in element):
        return None
    x, y = int(element[0]), int(element[1])
    if device is not None:
        width, height = screen_size(device)
        x = round(x * width / 1000)
        y = round(y * height / 1000)
    return x, y


def visual_swipe_up(plan: Any, device: str) -> bool:
    action = plan.get("action") if isinstance(plan, dict) else None
    if not isinstance(action, dict) or action.get("_metadata") != "do" or action.get("action") != "Swipe":
        return False
    start, end = action.get("start"), action.get("end")
    if not (isinstance(start, list) and isinstance(end, list) and len(start) == 2 and len(end) == 2 and all(isinstance(v, int) for v in [*start, *end])):
        return False
    width, height = screen_size(device)
    sx, sy, ex, ey = map(int, [start[0], start[1], end[0], end[1]])
    sx, ex = round(sx * width / 1000), round(ex * width / 1000)
    sy, ey = round(sy * height / 1000), round(ey * height / 1000)
    if not (0 <= sx <= width and 0 <= ex <= width and 0 <= sy <= height and 0 <= ey <= height and sy > ey and sy - ey >= 100):
        return False
    result = adb(device, "shell", "input", "swipe", str(sx), str(sy), str(ex), str(ey), "350")
    return result.returncode == 0


def wechat_visual_observe(device: str) -> dict[str, Any]:
    """Observe a WeChat screen when the app exposes no UiAutomator tree.

    Some WeChat builds render the conversation as a custom surface and expose
    only a zero-sized UiAutomator root.  A screenshot plus the local AutoGLM
    observer is the safe fallback.  The returned plan is descriptive only;
    no action from it is executed by this operation.
    """
    window = adb(device, "shell", "dumpsys", "window")
    if current_focus_package(window.stdout) != "com.tencent.mm":
        raise RuntimeError("WECHAT_NOT_FOREGROUND")
    screenshot = subprocess.run(["adb", "-s", device, "exec-out", "screencap", "-p"], check=False, capture_output=True, timeout=20)
    if screenshot.returncode != 0 or not screenshot.stdout:
        raise RuntimeError("WECHAT_SCREENSHOT_UNAVAILABLE")
    screenshot_digest = hashlib.sha256(screenshot.stdout).hexdigest()
    visual = None
    visual_error = None
    try:
        visual = autoglm_plan(device, "只观察当前普通微信聊天界面。不要点击、输入或发送。识别当前聊天标题、最近可见消息，以及输入框和发送按钮是否可定位；仅返回观察结果。")
    except Exception:  # noqa: BLE001 - observation remains useful without a model server
        visual_error = "PHONE_MODEL_UNAVAILABLE"
    return {
        "packageName": "com.tencent.mm",
        "observationMode": "visual",
        "accessibility": "unavailable",
        "screenshotDigest": screenshot_digest,
        "visualPlan": visual,
        "visualReady": visual is not None,
        "visualError": visual_error,
        "visibleTexts": [],
        "textDigest": screenshot_digest,
        "truncated": False,
    }


def read_wechat_ui(device: str) -> tuple[ElementTree.Element, list[str], str]:
    window = adb(device, "shell", "dumpsys", "window")
    if current_focus_package(window.stdout) != "com.tencent.mm":
        raise RuntimeError("WECHAT_NOT_FOREGROUND")
    root = None
    for attempt in range(2):
        dump = adb(device, "shell", "uiautomator", "dump", "--compressed", "/sdcard/opc-window.xml")
        xml = adb(device, "shell", "cat", "/sdcard/opc-window.xml") if dump.returncode == 0 else None
        if xml is not None and xml.returncode == 0:
            try:
                candidate = ElementTree.fromstring(xml.stdout)
            except ElementTree.ParseError:
                candidate = None
            if candidate is not None and ui_tree_has_package(candidate, "com.tencent.mm") and any(node.attrib.get("text") or node.attrib.get("content-desc") for node in candidate.iter("node")):
                root = candidate
                break
        if attempt == 0:
            time.sleep(0.15)
    if root is None:
        raise RuntimeError("WECHAT_UI_UNAVAILABLE")
    visible: list[str] = []
    for node in root.iter("node"):
        text = (node.attrib.get("text") or node.attrib.get("content-desc") or "").strip()
        if text and text not in visible and len(text) <= 1_000:
            visible.append(text)
        if len(visible) >= 100:
            break
    joined = "\n".join(visible)
    return root, visible, hashlib.sha256(joined.encode("utf-8")).hexdigest()


def current_focus_package(window_dump: str) -> str | None:
    matches = re.findall(r"mCurrentFocus=Window\{[^}]+\s+([^/\s]+)/", window_dump)
    return matches[-1] if matches else None


def ui_tree_has_package(root: ElementTree.Element, package_name: str) -> bool:
    return any(node.attrib.get("package") == package_name for node in root.iter("node"))


def wechat_send_message(device: str, text: str, expected_digest: str) -> dict[str, Any]:
    """Send only after the caller supplied the digest from the preflight read."""
    root, _, current_digest = read_wechat_ui(device)
    if current_digest != expected_digest:
        raise RuntimeError("WECHAT_SCREEN_CHANGED")
    edit_bounds: tuple[int, int] | None = None
    send_bounds: tuple[int, int] | None = None
    for node in root.iter("node"):
        attrs = node.attrib
        bounds = parse_bounds(attrs.get("bounds", ""))
        if bounds is None:
            continue
        label = (attrs.get("text") or attrs.get("content-desc") or "").strip()
        class_name = attrs.get("class", "")
        if edit_bounds is None and "EditText" in class_name and attrs.get("enabled", "true") != "false":
            edit_bounds = center(bounds)
        if send_bounds is None and label == "发送" and attrs.get("enabled", "true") != "false":
            send_bounds = center(bounds)
    if edit_bounds is None or send_bounds is None:
        raise RuntimeError("WECHAT_SEND_TARGET_NOT_FOUND")
    tap_result = adb(device, "shell", "input", "tap", str(edit_bounds[0]), str(edit_bounds[1]))
    if tap_result.returncode != 0:
        raise RuntimeError("WECHAT_SEND_TARGET_NOT_FOUND")
    type_with_approved_keyboard(device, text, focus_point=edit_bounds)
    send_result = adb(device, "shell", "input", "tap", str(send_bounds[0]), str(send_bounds[1]))
    if send_result.returncode != 0:
        raise RuntimeError("WECHAT_SEND_FAILED")
    return {"packageName": "com.tencent.mm", "sent": True, "textHash": hashlib.sha256(text.encode("utf-8")).hexdigest()}


def parse_bounds(value: str) -> tuple[int, int, int, int] | None:
    match = re.fullmatch(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", value)
    if match is None:
        return None
    left, top, right, bottom = (int(part) for part in match.groups())
    if right <= left or bottom <= top:
        return None
    return left, top, right, bottom


def center(bounds: tuple[int, int, int, int]) -> tuple[int, int]:
    left, top, right, bottom = bounds
    return (left + right) // 2, (top + bottom) // 2


def type_with_approved_keyboard(device: str, text: str, *, focus_point: tuple[int, int]) -> None:
    """Inject Unicode text and re-focus the editor after an Android IME switch."""
    from ime import ImeController

    class AdbImeDevice:
        def get_ime(self) -> str:
            result = adb(device, "shell", "settings", "get", "secure", "default_input_method")
            original = result.stdout.strip()
            if result.returncode != 0 or not original:
                raise RuntimeError("PHONE_MODEL_UNAVAILABLE")
            return original

        def set_ime(self, ime: str) -> None:
            result = adb(device, "shell", "ime", "set", ime)
            if result.returncode != 0:
                raise RuntimeError("PHONE_MODEL_UNAVAILABLE")

        def focus_input(self) -> None:
            result = adb(device, "shell", "input", "tap", str(focus_point[0]), str(focus_point[1]))
            if result.returncode != 0:
                raise RuntimeError("WECHAT_VISUAL_INPUT_TARGET_UNAVAILABLE")

        def clear_text(self) -> None:
            result = adb(device, "shell", "am", "broadcast", "-a", "ADB_CLEAR_TEXT")
            if result.returncode != 0:
                raise RuntimeError("PHONE_MODEL_UNAVAILABLE")

        def input_text(self, value: str) -> None:
            encoded = base64.b64encode(value.encode("utf-8")).decode("ascii")
            result = adb(device, "shell", "am", "broadcast", "-a", "ADB_INPUT_B64", "--es", "msg", encoded)
            if result.returncode != 0:
                raise RuntimeError("PHONE_MODEL_UNAVAILABLE")

    try:
        ImeController(AdbImeDevice(), "com.android.adbkeyboard/.AdbIME").enter_text(text)
    except ImportError as error:
        raise RuntimeError("PHONE_MODEL_UNAVAILABLE") from error


def autoglm_plan(device: str, task: str) -> dict[str, Any]:
    """Ask Open-AutoGLM for one action without executing that action.

    Open-AutoGLM's normal PhoneAgent combines planning and device mutation. The
    plugin deliberately uses its model client and parser only; the returned
    action must go through the closed DSH operation vocabulary afterwards.
    """
    auto_glm_path = os.environ.get("AUTOGLM_PATH", "").strip()
    if not auto_glm_path:
        raise RuntimeError("未配置 Open-AutoGLM 路径")
    sys.path.insert(0, auto_glm_path)
    try:
        from phone_agent.actions.handler import parse_action
        from phone_agent.config import get_system_prompt
        from phone_agent.device_factory import get_device_factory
        from phone_agent.model import ModelClient, ModelConfig
        from phone_agent.model.client import MessageBuilder

        factory = get_device_factory()
        screenshot = factory.get_screenshot(device)
        current_app = factory.get_current_app(device)
        messages = [
            MessageBuilder.create_system_message(get_system_prompt(os.environ.get("PHONE_AGENT_LANG", "cn"))),
            MessageBuilder.create_user_message(
                text=f"{task}\n\n{MessageBuilder.build_screen_info(current_app)}",
                image_base64=screenshot.base64_data,
            ),
        ]
        model_config = ModelConfig(
            base_url=os.environ.get("PHONE_MODEL_BASE_URL", "http://localhost:8000/v1"),
            api_key=os.environ.get("PHONE_MODEL_API_KEY", "EMPTY"),
            model_name=os.environ.get("PHONE_MODEL_NAME", "autoglm-phone-9b"),
            max_tokens=512,
            lang=os.environ.get("PHONE_AGENT_LANG", "cn"),
        )
        # ModelClient prints streaming diagnostics. Keep stdout a valid JSONL
        # transport and never return provider diagnostics to the DSH model.
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            response = ModelClient(model_config).request(messages)
        action = parse_action(response.action)
        return {
            "provider": "open-autoglm",
            "model": model_config.model_name,
            "deviceId": device,
            "currentApp": current_app,
            "action": action,
            "hasSensitiveConfirmation": "message" in action,
        }
    except ImportError as error:
        raise RuntimeError("Open-AutoGLM 依赖未安装") from error
    finally:
        try:
            sys.path.remove(auto_glm_path)
        except ValueError:
            pass


def main() -> None:
    device_locks: dict[str, threading.Lock] = {}
    locks_guard = threading.Lock()
    output_guard = threading.Lock()

    def run(request: dict[str, Any]) -> None:
        request_id = str(request.get("requestId", "unknown"))
        operation = str(request.get("operation", ""))
        device = str(request.get("deviceId", ""))
        # Read-only status remains responsive; mutations are FIFO per device.
        lock = None
        if operation not in {"device_list", "device_status", "task_status"}:
            with locks_guard:
                lock = device_locks.setdefault(device, threading.Lock())
        try:
            if lock is not None:
                lock.acquire()
            task_id = request.get("payload", {}).get("taskId") if isinstance(request.get("payload"), dict) else None
            if isinstance(task_id, str):
                TASK_STATUS[task_id] = "running"
            result = dispatch_operation(operation, device, dict(request.get("payload") or {}))
            if isinstance(task_id, str):
                TASK_STATUS[task_id] = "completed"
            with output_guard:
                emit(request_id, "completed", result=result)
        except Exception as error:  # noqa: BLE001 - worker boundary must keep JSONL alive
            message = str(error)
            code = "MOBILE_OPERATION_FAILED"
            if message == "WECHAT_NOT_FOREGROUND":
                code = "WECHAT_NOT_FOREGROUND"
                message = "普通微信当前不在前台"
            elif message == "WECHAT_SCREEN_CHANGED":
                code = "WECHAT_SCREEN_CHANGED"
                message = "微信当前界面已变化，发送已拒绝"
            elif message == "WECHAT_SEND_TARGET_NOT_FOUND":
                code = "WECHAT_SEND_TARGET_NOT_FOUND"
                message = "未找到可确认的微信输入框或发送按钮"
            elif message == "WECHAT_UI_UNAVAILABLE":
                code = "WECHAT_UI_UNAVAILABLE"
                message = "微信无障碍控件树不可用，视觉观察也未能完成"
            elif message == "WECHAT_SCREENSHOT_UNAVAILABLE":
                code = "WECHAT_SCREENSHOT_UNAVAILABLE"
                message = "无法获取微信当前屏幕截图"
            elif message in {"WECHAT_VISUAL_INPUT_TARGET_UNAVAILABLE", "WECHAT_VISUAL_INPUT_NOT_VERIFIED"}:
                code = message
                message = "无法安全定位微信输入框" if code.endswith("TARGET_UNAVAILABLE") else "微信草稿输入后未能通过视觉校验"
            elif message in {"WECHAT_VISUAL_CONTACT_TARGET_UNAVAILABLE", "WECHAT_VISUAL_CONTACT_NOT_VERIFIED"}:
                code = message
                message = "无法安全定位微信联系人" if code.endswith("TARGET_UNAVAILABLE") else "微信联系人未能通过视觉确认"
            elif message in {"WECHAT_SEND_FAILED", "PHONE_MODEL_UNAVAILABLE"}:
                code = message
                message = "微信发送未能确认完成" if code == "WECHAT_SEND_FAILED" else "手机输入依赖未配置"
            elif "No output from dumpsys window" in message or "no devices" in message.lower():
                code = "MOBILE_DEVICE_NOT_FOUND"
                message = "未找到在线 Android 设备"
            elif "Open-AutoGLM" in message:
                code = "PHONE_MODEL_UNAVAILABLE"
            with output_guard:
                emit(request_id, "failed", error_code=code, error_message=message)
            if isinstance(task_id, str):
                TASK_STATUS[task_id] = "failed"
        finally:
            if lock is not None:
                lock.release()

    with ThreadPoolExecutor(max_workers=8, thread_name_prefix="mobile-device") as pool:
        for line in sys.stdin:
            try:
                request = json.loads(line)
                if not isinstance(request, dict):
                    raise ValueError("请求格式无效")
                pool.submit(run, request)
            except Exception as error:  # noqa: BLE001 - malformed input must not kill JSONL
                with output_guard:
                    emit("unknown", "failed", error_code="MOBILE_INVALID_INPUT", error_message="手机请求格式无效")


if __name__ == "__main__":
    main()
