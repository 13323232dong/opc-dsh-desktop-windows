"""Safe, device-agnostic text entry through an approved Android IME."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class ImeDevice(Protocol):
    """The narrow device boundary needed for IME-backed text entry."""

    def get_ime(self) -> str: ...

    def set_ime(self, ime: str) -> None: ...

    def focus_input(self) -> None: ...

    def clear_text(self) -> None: ...

    def input_text(self, text: str) -> None: ...


@dataclass(frozen=True)
class TextEntryResult:
    status: str


class ImeController:
    """Switch to an approved IME temporarily and restore the user's IME."""

    def __init__(self, device: ImeDevice, automation_ime: str) -> None:
        self._device = device
        self._automation_ime = automation_ime

    def enter_text(self, text: str) -> TextEntryResult:
        if not text:
            raise ValueError("text must not be empty")

        original_ime = self._device.get_ime()
        self._device.set_ime(self._automation_ime)
        try:
            # Android drops focus when an IME changes. Re-focus before mutation.
            self._device.focus_input()
            self._device.clear_text()
            self._device.input_text(text)
        finally:
            self._device.set_ime(original_ime)
        return TextEntryResult(status="drafted")
