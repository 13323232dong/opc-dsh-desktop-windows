export declare const publicToolNames: readonly ["mobile_device_status", "mobile_read_screen", "mobile_navigate", "mobile_task_status", "wechat_read_current_chat", "wechat_draft_reply", "wechat_prepare_reply", "wechat_send_reply", "wechat_visual_prepare_reply", "douyin_open", "douyin_swipe_next", "douyin_like_current", "douyin_verify_liked", "alipay_open", "alipay_read_screen"];
export type MobileAction = {
    readonly kind: 'tap_selector';
    readonly selector: Record<string, string>;
} | {
    readonly kind: 'tap_point';
    readonly x: number;
    readonly y: number;
    readonly observationId: string;
} | {
    readonly kind: 'swipe';
    readonly direction: 'up' | 'down' | 'left' | 'right';
    readonly distance: number;
} | {
    readonly kind: 'input_text';
    readonly textRef: string;
} | {
    readonly kind: 'launch_app';
    readonly packageName: string;
} | {
    readonly kind: 'back';
};
export declare function normalizeInternalAction(value: unknown): MobileAction;
