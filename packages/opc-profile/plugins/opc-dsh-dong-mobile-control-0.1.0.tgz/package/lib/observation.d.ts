export interface MobileObservationRef {
    readonly observationId: string;
    readonly expiresAt: string;
}
export interface VerificationCheck {
    readonly name: string;
    readonly passed: boolean;
    readonly detail?: string;
}
export declare function assertFreshObservation(observation: MobileObservationRef, expectedId: string): void;
export declare function buildVerificationResult(checks: readonly VerificationCheck[]): {
    readonly status: 'passed' | 'failed';
    readonly checks: readonly VerificationCheck[];
};
