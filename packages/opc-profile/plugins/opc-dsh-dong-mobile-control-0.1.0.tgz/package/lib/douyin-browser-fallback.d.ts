import { spawn as nodeSpawn } from 'node:child_process';
export interface DouyinBrowserOpenResult {
    readonly opened: true;
    readonly channel: 'ego-lite';
    readonly taskSpace: string;
    readonly url: 'https://www.douyin.com/';
}
export interface DouyinBrowserFallback {
    open(taskSpace: string, signal?: AbortSignal): Promise<DouyinBrowserOpenResult>;
}
interface BrowserFallbackDependencies {
    readonly spawn?: typeof nodeSpawn;
    readonly environment?: NodeJS.ProcessEnv;
}
export declare function parseDouyinBrowserResult(stdout: string, stderr: string): DouyinBrowserOpenResult | undefined;
export declare function createDouyinBrowserFallback(command?: string, dependencies?: BrowserFallbackDependencies): DouyinBrowserFallback;
export {};
