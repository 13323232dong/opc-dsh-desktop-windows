export type MobileEffect = 'read' | 'write' | 'paid' | 'destructive';
export declare function requiresToolApproval(effect: MobileEffect): boolean;
export declare function proposalHash(input: {
    readonly toolId: string;
    readonly version: string;
    readonly input: unknown;
    readonly maximumCost: number;
}): string;
