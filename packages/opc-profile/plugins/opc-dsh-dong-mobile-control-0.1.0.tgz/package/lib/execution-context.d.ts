export interface TrustedMobileIdentity {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
    readonly sessionId: string;
}
export declare function requireTrustedMobileIdentity(value: unknown): TrustedMobileIdentity;
export declare function identityFromAgent(agent: unknown): TrustedMobileIdentity;
