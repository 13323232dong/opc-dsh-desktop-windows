import { type ShadowEvaluation } from './shadow-evaluator.js';
import type { MobilePlanner, MobilePlannerActionType } from './types.js';
import type { MobileWorkerClient } from '../types.js';
export interface GELabShadowInput {
    readonly deviceId: string;
    readonly sessionId: string;
    readonly agentId: string;
    readonly goal: string;
    readonly allowedActions: readonly MobilePlannerActionType[];
}
export interface GELabShadowRuntime {
    evaluate(input: GELabShadowInput, signal?: AbortSignal): Promise<ShadowEvaluation>;
}
export declare function createGELabShadowRuntime(options: {
    readonly worker: MobileWorkerClient;
    readonly planner: MobilePlanner;
    readonly onRecord?: (record: ShadowEvaluation) => void;
}): GELabShadowRuntime;
