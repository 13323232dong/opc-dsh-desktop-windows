import type { MobilePlanner } from './types.js';
type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;
export interface GelabPlannerOptions {
    readonly baseUrl: string;
    readonly modelName: string;
    readonly minimumConfidence?: number;
    readonly timeoutMs?: number;
    readonly fetchImpl?: FetchLike;
}
export declare class MobilePlannerError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function createGelabPlanner(options: GelabPlannerOptions): MobilePlanner;
export {};
