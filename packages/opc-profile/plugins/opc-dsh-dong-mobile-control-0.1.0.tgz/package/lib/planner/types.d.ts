export type MobilePlannerActionType = 'tap_selector' | 'tap_point' | 'swipe' | 'focus_input' | 'wait' | 'back';
export interface MobilePlannerObservation {
    readonly observationId: string;
    readonly packageName: string;
    readonly pageFingerprint: string;
    readonly screenDigest: string;
    readonly screenshotDataUrl?: string;
}
export interface MobilePlannerRequest {
    readonly observation: MobilePlannerObservation;
    readonly goal: string;
    readonly allowedActions: readonly MobilePlannerActionType[];
}
export type MobilePlannerAction = {
    readonly type: 'tap_selector';
    readonly selector: Readonly<Record<string, string>>;
} | {
    readonly type: 'tap_point';
    readonly x: number;
    readonly y: number;
} | {
    readonly type: 'swipe';
    readonly direction: 'up' | 'down' | 'left' | 'right';
} | {
    readonly type: 'focus_input';
} | {
    readonly type: 'wait';
} | {
    readonly type: 'back';
};
export interface MobilePlannerCandidate {
    readonly source: 'gelab';
    readonly observationId: string;
    readonly confidence: number;
    readonly action: MobilePlannerAction;
}
export interface MobilePlanner {
    plan(request: MobilePlannerRequest, signal?: AbortSignal): Promise<MobilePlannerCandidate>;
}
