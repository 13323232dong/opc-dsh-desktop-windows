import type { MobilePlanner, MobilePlannerCandidate, MobilePlannerRequest } from './types.js';
export type ShadowEvaluation = {
    readonly status: 'recorded';
    readonly observationId: string;
    readonly candidate: MobilePlannerCandidate;
} | {
    readonly status: 'unavailable';
    readonly observationId: string;
    readonly code: 'MOBILE_PLANNER_UNAVAILABLE';
};
export interface ShadowEvaluator {
    evaluate(request: MobilePlannerRequest, signal?: AbortSignal): Promise<ShadowEvaluation>;
}
/**
 * Runs an untrusted planner for measurement only. This boundary deliberately
 * has no worker dependency and exposes no execution method.
 */
export declare function createShadowEvaluator(planner: MobilePlanner): ShadowEvaluator;
