export type MobileOperation = 'device_list' | 'device_status' | 'screenshot' | 'screen_read' | 'launch_app' | 'tap' | 'swipe' | 'input_text' | 'press_back' | 'task_status' | 'autoglm_plan' | 'planner_observe' | 'navigate' | 'wechat_read_current_chat' | 'wechat_visual_observe' | 'wechat_send_message' | 'wechat_preflight_reply' | 'wechat_confirm_send' | 'wechat_visual_prepare_reply' | 'douyin_open' | 'douyin_swipe_next' | 'douyin_like_current' | 'douyin_verify_liked' | 'alipay_open' | 'alipay_read_screen';
export interface MobileWorkerRequest {
    readonly requestId: string;
    readonly operation: MobileOperation;
    readonly deviceId: string;
    readonly sessionId: string;
    readonly agentId: string;
    readonly payload: Readonly<Record<string, unknown>>;
}
export interface MobileWorkerResponse {
    readonly requestId: string;
    readonly status: 'completed' | 'waiting_confirmation' | 'failed' | 'unknown';
    readonly result?: unknown;
    readonly errorCode?: string;
    readonly errorMessage?: string;
    readonly retryable?: boolean;
}
export interface MobileWorkerClient {
    request(request: MobileWorkerRequest, signal?: AbortSignal): Promise<MobileWorkerResponse>;
    requestMutation?(request: MobileWorkerRequest, signal?: AbortSignal): Promise<MobileWorkerResponse>;
    requestControl?(request: MobileWorkerRequest, signal?: AbortSignal): Promise<MobileWorkerResponse>;
    close(): Promise<void>;
}
export interface MobileControlConfig {
    readonly pythonCommand?: string;
    readonly workerScript?: string;
    readonly autoGlmPath?: string;
    readonly phoneModelBaseUrl?: string;
    readonly phoneModelName?: string;
    readonly plannerProvider?: string;
    readonly gelabBaseUrl?: string;
    readonly gelabModelName?: string;
    readonly gelabMinimumConfidence?: number;
    readonly gelabShadowMode?: boolean;
    readonly deviceAllowlist?: readonly string[];
    readonly allowedPackages?: readonly string[];
    readonly workerTimeoutMs?: number;
    readonly toolVersion?: string;
}
export interface MobileCoreRequest {
    readonly operation: `mobile_${MobileOperation}`;
    readonly deviceId: string;
    readonly sessionId: string;
    readonly agentId: string;
    readonly payload: Readonly<Record<string, unknown>>;
}
