import type { MobileControlConfig, MobileOperation } from './types.js';
export declare class MobilePolicyError extends Error {
    readonly code: string;
    constructor(message: string, code?: string);
}
export declare function validateDevice(deviceId: string, config: MobileControlConfig): void;
export declare function validatePayload(operation: MobileOperation, payload: Readonly<Record<string, unknown>>, config: MobileControlConfig): void;
