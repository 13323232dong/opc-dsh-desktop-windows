export interface WechatReplyProposal {
    readonly proposalId: string;
    readonly agentId: string;
    readonly sessionId: string;
    readonly deviceId: string;
    readonly contactDigest: string;
    readonly text: string;
    readonly textHash: string;
    readonly confirmationToken: string;
    readonly expiresAt: string;
    readonly status: 'waiting_confirmation' | 'sending' | 'sent' | 'unknown' | 'expired';
}
export declare class WechatProposalError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function createWechatProposalStore(ttlMs?: number): {
    create(input: {
        readonly agentId: string;
        readonly sessionId: string;
        readonly deviceId: string;
        readonly contactDigest: string;
        readonly text: string;
    }): WechatReplyProposal;
    beginSend(input: {
        readonly proposalId: string;
        readonly confirmationToken: string;
        readonly agentId: string;
        readonly sessionId: string;
        readonly deviceId: string;
    }): WechatReplyProposal;
    finish(proposalId: string, status: "sent" | "unknown"): WechatReplyProposal;
    get(proposalId: string): WechatReplyProposal | undefined;
};
export declare function hashText(text: string): string;
