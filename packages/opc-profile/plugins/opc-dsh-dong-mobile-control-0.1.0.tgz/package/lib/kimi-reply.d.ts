export interface KimiReplyConfig {
    readonly baseUrl?: string;
    readonly modelName?: string;
    readonly apiKey?: string;
    readonly fetcher?: typeof fetch;
    readonly timeoutMs?: number;
}
export declare class KimiReplyError extends Error {
    readonly code: string;
    readonly retryable: boolean;
    constructor(code: string, message: string, retryable?: boolean);
}
export interface KimiReplyInput {
    readonly conversationText: string;
    readonly tone?: string;
    readonly maxLength?: number;
    readonly knowledge?: readonly {
        readonly question?: string;
        readonly answer: string;
        readonly score: number;
        readonly documentId?: string;
        readonly documentVersion?: number;
    }[];
}
export declare function createKimiReplyClient(config?: KimiReplyConfig): {
    draft(input: KimiReplyInput, signal?: AbortSignal): Promise<{
        readonly text: string;
        readonly model: string;
    }>;
};
