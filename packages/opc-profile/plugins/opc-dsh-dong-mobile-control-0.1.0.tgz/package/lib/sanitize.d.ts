export declare function sanitizeText(value: string): string;
export declare function sanitizeUnknown(value: unknown, depth?: number): unknown;
export declare function safeErrorMessage(error: unknown): string;
