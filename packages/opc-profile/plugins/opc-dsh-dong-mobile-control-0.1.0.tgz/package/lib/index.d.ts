import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { MobileControlConfig } from './types.js';
import { type DouyinBrowserFallback } from './douyin-browser-fallback.js';
export declare const name = "opc-mobile-control";
export declare const inject: string[];
export interface Config extends MobileControlConfig {
    readonly deviceAllowlist?: string[];
    readonly allowedPackages?: string[];
    readonly replyModelBaseUrl?: string;
    readonly replyModelName?: string;
    readonly knowledgeBaseUrl?: string;
    readonly opcAgentApiKey?: string;
    readonly egoCommand?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export declare function executeDouyinOpenWithFallback(input: {
    readonly agent: unknown;
    readonly deviceId: string;
    readonly core: {
        execute(request: import('./types.js').MobileCoreRequest, signal?: AbortSignal): Promise<unknown>;
    };
    readonly browser: DouyinBrowserFallback;
    readonly signal?: AbortSignal;
}): Promise<{
    channel: "android";
    deviceId: string;
} | {
    fallbackReason: string;
    opened: true;
    channel: "ego-lite";
    taskSpace: string;
    url: "https://www.douyin.com/";
}>;
export type { MobileControlConfig, MobileCoreRequest, MobileOperation, MobileWorkerClient, MobileWorkerRequest, MobileWorkerResponse } from './types.js';
export { createMobileControlCore, MobileControlError } from './core.js';
export { createMobileWorkerClient, createWorkerRequest, MobileWorkerError } from './worker-client.js';
export { createDouyinBrowserFallback, parseDouyinBrowserResult } from './douyin-browser-fallback.js';
export { requireTrustedMobileIdentity, identityFromAgent } from './execution-context.js';
export { publicToolNames, normalizeInternalAction } from './action-dsl.js';
export { proposalHash, requiresToolApproval } from './approval-policy.js';
export { assertFreshObservation, buildVerificationResult } from './observation.js';
