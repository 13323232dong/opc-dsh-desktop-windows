import { spawn as nodeSpawn } from 'node:child_process';
import type { MobileControlConfig, MobileWorkerClient, MobileWorkerRequest } from './types.js';
export declare class MobileWorkerError extends Error {
    readonly code: string;
    readonly retryable: boolean;
    constructor(code: string, message: string, retryable?: boolean);
}
interface WorkerDependencies {
    readonly spawn?: typeof nodeSpawn;
    readonly environment?: NodeJS.ProcessEnv;
}
export declare function createMobileWorkerClient(config: MobileControlConfig, dependencies?: WorkerDependencies): MobileWorkerClient;
export declare function createWorkerRequest(input: Omit<MobileWorkerRequest, 'requestId'>): MobileWorkerRequest;
export {};
