import type { MobileControlConfig, MobileCoreRequest, MobileWorkerClient } from './types.js';
export declare class MobileControlError extends Error {
    readonly code: string;
    readonly retryable: boolean;
    constructor(code: string, message: string, retryable?: boolean);
}
export declare function createMobileControlCore(options: MobileControlConfig & {
    readonly worker: MobileWorkerClient;
}): {
    execute(request: MobileCoreRequest, signal?: AbortSignal): Promise<unknown>;
};
