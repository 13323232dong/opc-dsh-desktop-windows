export interface KnowledgeIdentity {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
    readonly sessionId: string;
}
export interface KnowledgeMatch {
    readonly chunkId: string;
    readonly documentId?: string;
    readonly documentVersion?: number;
    readonly question?: string;
    readonly answer: string;
    readonly tags?: readonly string[];
    readonly score: number;
    readonly matchedKeywords?: readonly string[];
}
export declare function createKnowledgeClient(config?: {
    readonly baseUrl?: string;
    readonly agentKey?: string;
    readonly fetcher?: typeof fetch;
    readonly timeoutMs?: number;
}): {
    search(identity: KnowledgeIdentity, query: string, limit?: number, signal?: AbortSignal): Promise<readonly KnowledgeMatch[]>;
};
