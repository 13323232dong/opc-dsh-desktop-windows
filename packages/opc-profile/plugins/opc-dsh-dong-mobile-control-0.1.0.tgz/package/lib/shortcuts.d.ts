export type MobileShortcutKind = 'focus_input' | 'tap_search';
export type MobileShortcutStatus = 'candidate' | 'active';
export interface MobileShortcut {
    readonly id: string;
    readonly packageName: string;
    readonly pageKind: string;
    readonly kind: MobileShortcutKind;
    readonly relativeX: number;
    readonly relativeY: number;
    readonly status: MobileShortcutStatus;
    readonly verifiedUses: number;
    readonly failedUses: number;
}
export interface MobileViewport {
    readonly width: number;
    readonly height: number;
}
export declare function createMobileShortcut(input: Omit<MobileShortcut, 'status' | 'failedUses'> & {
    readonly failedUses?: number;
}): MobileShortcut;
export declare function recordShortcutVerification(shortcut: MobileShortcut, passed: boolean): MobileShortcut;
export declare function resolveShortcutPoint(shortcut: MobileShortcut, viewport: MobileViewport): {
    readonly x: number;
    readonly y: number;
};
