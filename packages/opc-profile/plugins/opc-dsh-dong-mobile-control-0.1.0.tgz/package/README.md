# OPC Android 手机控制插件

这是 OPC 自研的 DSH 手机控制插件，不复用社区手机插件。设备控制边界由本插件维护，手机视觉规划预留给本机 `/Users/mac/autoGLM` 的 AutoGLM-Phone 适配器。

## 当前首版

- 设备列表和设备状态查询
- 当前屏幕和前台窗口读取
- 白名单应用启动
- 受限点击、滑动、输入和返回操作
- 手机任务状态查询接口
- `mobile_autoglm_plan`：调用本机 Open-AutoGLM 读取当前屏幕并返回下一步动作计划，但不直接执行动作
- `wechat_draft_reply`：将脱敏后的当前私聊文本交给 Kimi 生成客服草稿，不读取、不输入、不发送
- `wechat_read_current_chat`：优先读取 UIAutomator 可见文本；微信自绘界面不提供控件树时，自动切换到本机截图视觉观察，并返回 `observationMode: visual`、截图摘要和模型就绪状态，不自动切换联系人
- `wechat_preflight_reply`：绑定当前界面摘要、最终文本和一次性确认令牌
- `wechat_visual_prepare_reply`：微信自绘页面无控件树时，先用 macOS Vision 本地 OCR 定位联系人文字框，必要时再由 AutoGLM 规划受限滚动；随后定位输入框，使用 ADBKeyboard 输入草稿，并再次截图视觉校验文本；只生成已验证草稿，不发送
- `wechat_confirm_send`：用户明确确认后再次校验界面，再通过固定输入框和发送按钮执行
- JSONL 常驻 Worker，Worker 重启后不会伪造成功状态
- 设备 ID、应用包名、坐标、输入长度和错误信息均在边界校验/脱敏

发送链路已接入预检和一次性确认令牌：令牌绑定 Agent、Session、设备、当前界面摘要和最终文本，发送前会重新读取 UIAutomator；界面变化、目标控件缺失、视觉模型未就绪或 Worker 异常都会拒绝或标记未知，不会重试发送。插件仍不会自动登录、处理验证码、支付、转账、群发或调用任意 `adb shell`。`mobile_autoglm_plan` 和视觉 fallback 会使用本机 AutoGLM 的模型客户端读取截图并只返回动作计划；计划必须再次映射到本插件的固定工具后才能执行。截图不会上传到第三方服务。`wechat_draft_reply` 只生成草稿，Kimi Key 只从服务端环境读取。截图工具本身目前只返回受控元数据。

视觉输入工具的状态链路为：`视觉定位输入框 -> 本地输入 -> 截图/视觉验证 -> drafted`。它不会点击发送按钮；验证失败时返回稳定错误码 `WECHAT_VISUAL_INPUT_TARGET_UNAVAILABLE` 或 `WECHAT_VISUAL_INPUT_NOT_VERIFIED`。

## 架构

```text
DSH tools
  -> src/core.ts（策略、会话/Agent 绑定、稳定错误码）
  -> src/worker-client.ts（JSONL RPC、超时、取消、重启）
  -> worker/mobile_worker.py（固定 ADB 操作词表）
  -> AutoGLM planner（复用本机 /Users/mac/autoGLM，只规划不执行）
```

## 安装到 DSH Profile

```bash
dsh plugin --profile <profile-name> add /Users/mac/OPC智能体团队/dsh-plugins/opc-mobile-control
```

安装后重启对应 DSH Profile。配置中的 `deviceAllowlist` 和 `allowedPackages` 必须显式填写；默认只允许普通微信包名 `com.tencent.mm`，不接受浏览器传入任意设备或租户身份。

## 本地验证

```bash
npm test
python3 -m py_compile worker/mobile_worker.py
printf '%s\n' '{"requestId":"smoke-1","operation":"device_list","deviceId":"auto","sessionId":"session-a","agentId":"agent-a","payload":{}}' | python3 worker/mobile_worker.py
```
