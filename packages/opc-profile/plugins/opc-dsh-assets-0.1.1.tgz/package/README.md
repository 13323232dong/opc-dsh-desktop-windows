# @opc/dsh-assets

独立的 OPC 资产部门 DSH 插件。插件只提供 DSH 对话入口，资产部门的完整界面继续复用 OPC 工作台 `/workspace/assets`，避免维护两套 UI。
