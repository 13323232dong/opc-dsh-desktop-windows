import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** Independent DSH asset surface. OPC remains the data source; this component only projects it. */
export declare function AssetDepartmentView({ sessionId }: ConvViewProps): JSX.Element;
