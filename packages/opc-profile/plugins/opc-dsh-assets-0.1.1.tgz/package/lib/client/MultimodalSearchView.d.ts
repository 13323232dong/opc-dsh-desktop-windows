export declare function MultimodalSearchView({ sessionId }: {
    sessionId: string;
}): JSX.Element;
