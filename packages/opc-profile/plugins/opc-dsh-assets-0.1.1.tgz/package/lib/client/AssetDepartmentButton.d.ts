export declare function AssetDepartmentButton(): JSX.Element;
