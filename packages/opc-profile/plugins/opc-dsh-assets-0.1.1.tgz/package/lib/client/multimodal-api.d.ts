export type MultimodalIndexType = 'video' | 'knowledge' | 'all';
export interface MultimodalSearchResult {
    assetId: string;
    segmentId?: string | null;
    name: string;
    kind?: string;
    score: number;
    snippet?: string | null;
    startMs?: number | null;
    endMs?: number | null;
    mimeType?: string | null;
    url?: string | null;
    metadata?: Record<string, unknown>;
}
export interface MultimodalSearchResponse {
    results: MultimodalSearchResult[];
    nextCursor?: string | null;
    truncated?: boolean;
}
export interface MultimodalIndexStatus {
    indexType: MultimodalIndexType;
    status: 'ready' | 'processing' | 'failed' | 'disabled' | string;
    pending: number;
    failed: number;
    indexed: number;
    updatedAt?: string | null;
}
export interface ContextSearchHit {
    sourceType: 'knowledge_document' | 'design_asset' | string;
    sourceId: string;
    title: string;
    summary?: string | null;
    updatedAt?: string;
    score: number;
    match: 'semantic' | 'structured' | 'hybrid' | string;
    facets?: Record<string, unknown>;
}
export interface ContextSearchResponse {
    hits: ContextSearchHit[];
    semanticAvailable: boolean;
}
export declare function searchMultimodal(sessionId: string, input: {
    query: string;
    indexType?: MultimodalIndexType;
    limit?: number;
    cursor?: string;
}): Promise<MultimodalSearchResponse>;
export declare function getMultimodalIndexStatus(sessionId: string, indexType?: MultimodalIndexType): Promise<MultimodalIndexStatus[]>;
export declare function searchContext(sessionId: string, query: string): Promise<ContextSearchResponse>;
