import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "opc-assets";
export declare const inject: string[];
export interface Config {
    readonly assetsUrl?: string;
    readonly apiBaseUrl?: string;
    readonly tenantId?: string;
    readonly userId?: string;
    readonly identityHmacSecret?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
