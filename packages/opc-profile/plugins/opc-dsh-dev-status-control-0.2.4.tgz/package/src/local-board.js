import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

// Codex keeps the conversations shown in its sidebar in named thread sections.
// Rows without a current section are retained history, not current UI entries.
const SESSIONS_QUERY = "SELECT id, title, name, agent_nickname, agent_role, first_user_message, preview, cwd, git_branch, source, thread_source, originator, coalesce(updated_at_ms, updated_at * 1000, 0) AS updated_at_ms FROM threads WHERE archived = 0 AND thread_section_id IN (SELECT id FROM thread_sections) AND (trim(title) <> '' OR trim(name) <> '' OR trim(agent_nickname) <> '' OR trim(agent_role) <> '' OR trim(first_user_message) <> '' OR trim(preview) <> '') ORDER BY updated_at_ms DESC"
const WORKSPACES_QUERY = "SELECT cwd, count(*) AS session_count, max(coalesce(updated_at_ms, updated_at * 1000, 0)) AS updated_at_ms FROM threads WHERE archived = 0 AND cwd IS NOT NULL AND cwd <> '' GROUP BY cwd ORDER BY updated_at_ms DESC"

const DEFAULT_WORKSPACES = [
  { id: 'opc', name: 'OPC智能体团队', path: '/Users/mac/OPC智能体团队' },
  { id: 'dsh-codex-control', name: 'DSH Codex 控制服务', path: '/Users/mac/.codex/worktrees/dsh-codex-control/control-service' },
  { id: 'openai-codex', name: 'OpenAI Codex', path: '/Users/mac/openai-codex' }
]

export class LocalCodexBoard {
  constructor(options = {}) {
    const codexHome = options.codexHome ?? join(homedir(), '.codex')
    this.databasePath = options.databasePath ?? join(codexHome, 'state_5.sqlite')
    this.locksPath = options.locksPath ?? join(codexHome, 'thread-writer-locks')
    this.workspaces = (options.workspaces ?? DEFAULT_WORKSPACES).map((workspace) => ({
      ...workspace,
      path: resolve(workspace.path)
    }))
    this.defaultWorkspaceId = options.defaultWorkspaceId ?? 'opc'
    this.featureConfigPath = options.featureConfigPath ?? null
    this.worktreePathsCache = new Map()
  }

  listWorkspaces() {
    const configured = this.workspaces.filter((workspace) => isProjectDirectory(workspace.path))
    const configuredPaths = new Set(configured.map((workspace) => workspace.path))
    const discovered = this.#withDatabase((database) => database.prepare(WORKSPACES_QUERY).all()
      .map((row) => String(row.cwd))
      .filter((path) => !configuredPaths.has(path) && isProjectDirectory(path))
      .map((path) => ({ id: workspaceId(path), name: workspaceName(path), path })))
    this.workspaces = [...configured, ...discovered]
    return this.workspaces.map(({ id, name }) => ({ id, name, isDefault: id === this.defaultWorkspaceId }))
  }

  listSessions(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const locks = this.#lockNames()
    const sessions = this.#withDatabase((database) => database.prepare(SESSIONS_QUERY).all()
      .filter((row) => this.#belongsToWorkspace(String(row.cwd ?? ''), workspace.path))
      .filter((row) => !isInternalSubagent(row))
      .map((row) => ({
        id: String(row.id),
        title: normalizeTitle(row.title, row.name, row.first_user_message, row.preview),
        branch: String(row.git_branch ?? ''),
        updatedAt: Number(row.updated_at_ms) || 0,
        workspaceId: workspace.id,
        runtimeStatus: locks.has(String(row.id)) ? 'active' : 'idle',
      })))
    return { workspaceId: workspace.id, sessions }
  }

  projectOverview(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const sessions = this.listSessions(workspace.id).sessions
    const branches = [...new Set(sessions.map((session) => session.branch).filter(Boolean))].slice(0, 6)
    return {
      workspaceId: workspace.id,
      projectName: workspace.name,
      generatedAt: Date.now(),
      sessionCount: sessions.length,
      activeCount: sessions.filter((session) => session.runtimeStatus === 'active').length,
      branches,
      modules: readProjectModules(workspace.path),
      sources: sessions.slice(0, 12).map(({ id, title, branch, updatedAt }) => ({ id, title, branch, updatedAt })),
    }
  }

  status(workspaceId) {
    const workspace = this.#workspace(workspaceId)
    const sessions = this.listSessions(workspace.id).sessions
    const features = this.#loadFeatures().map((feature) => {
      const matchedSessions = sessions.filter((session) => feature.sessionIds.includes(session.id) || feature.titleIncludes.some((title) => session.title.includes(title)))
      const git = readGitState(workspace.path, feature.branch, feature.paths)
      return deriveFeatureStatus(feature, matchedSessions, git)
    })
    return { generatedAt: Date.now(), workspaceId: workspace.id, features }
  }

  listTasks(workspaceId, query = '') {
    const result = this.status(workspaceId)
    const needle = String(query ?? '').trim().toLowerCase()
    const tasks = result.features
      .filter((feature) => !needle || [feature.name, feature.status, feature.mergeDecision, feature.nextStep].some((value) => String(value ?? '').toLowerCase().includes(needle)))
      .map((feature) => ({
        id: feature.id,
        name: feature.name,
        status: feature.status,
        mergeDecision: feature.mergeDecision ?? '未判断',
        nextStep: feature.nextStep ?? '等待下一步',
        updatedAt: feature.updatedAt,
        sessions: (feature.sessions ?? []).map(({ id, title, runtimeStatus, updatedAt }) => ({ id, title, runtimeStatus, updatedAt })),
      }))
    return { generatedAt: result.generatedAt, workspaceId: result.workspaceId, tasks, total: tasks.length }
  }

  #workspace(workspaceId) {
    if (typeof workspaceId !== 'string' || !/^[a-z0-9-]{2,64}$/u.test(workspaceId)) throw new Error('工作区不可用')
    const workspace = this.workspaces.find((item) => item.id === workspaceId)
    if (!workspace || !existsSync(workspace.path)) throw new Error('工作区不可用')
    return workspace
  }

  #belongsToWorkspace(candidatePath, workspacePath) {
    if (!candidatePath || !workspacePath) return false
    const candidate = resolve(candidatePath)
    const workspace = resolve(workspacePath)
    if (candidate === workspace) return true
    return this.#worktreePaths(workspace).has(candidate)
  }

  #worktreePaths(workspacePath) {
    if (this.worktreePathsCache.has(workspacePath)) return this.worktreePathsCache.get(workspacePath)
    const paths = new Set([workspacePath])
    try {
      const output = execFileSync('git', ['worktree', 'list', '--porcelain'], { cwd: workspacePath, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 2_000 })
      for (const line of output.split('\n')) if (line.startsWith('worktree ')) paths.add(resolve(line.slice('worktree '.length)))
    } catch {}
    this.worktreePathsCache.set(workspacePath, paths)
    return paths
  }

  #lockNames() {
    try {
      return new Set(readdirSync(this.locksPath).filter((name) => name.endsWith('.lock')).map((name) => name.slice(0, -5)))
    } catch {
      return new Set()
    }
  }

  #withDatabase(run) {
    let database
    try {
      database = new DatabaseSync(this.databasePath, { readOnly: true })
      return run(database)
    } catch {
      throw new Error('本机 Codex 数据库不可用')
    } finally {
      database?.close()
    }
  }

  #loadFeatures() {
    if (!this.featureConfigPath || !existsSync(this.featureConfigPath)) return []
    try {
      const config = JSON.parse(readFileSync(this.featureConfigPath, 'utf8'))
      return Array.isArray(config.features) ? config.features.map((feature) => ({
        ...feature,
        sessionIds: Array.isArray(feature.sessionIds) ? feature.sessionIds : [],
        titleIncludes: Array.isArray(feature.titleIncludes) ? feature.titleIncludes : [],
        paths: Array.isArray(feature.paths) ? feature.paths : [],
      })) : []
    } catch {
      return []
    }
  }
}

function isInternalSubagent(row) {
  return Boolean(String(row.agent_nickname ?? '').trim() || String(row.agent_role ?? '').trim()) ||
    ['subagent', 'agent', 'child'].includes(String(row.source ?? '').toLowerCase()) ||
    ['subagent', 'agent', 'child'].includes(String(row.thread_source ?? '').toLowerCase()) ||
    ['subagent', 'agent', 'child'].includes(String(row.originator ?? '').toLowerCase())
}

function readProjectModules(path) {
  try {
    return readdirSync(path, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && !entry.name.startsWith('.') && !['node_modules', 'dist', 'build', 'coverage'].includes(entry.name))
      .slice(0, 8)
      .map((entry) => ({ id: entry.name, name: entry.name, kind: moduleKind(entry.name) }))
  } catch {
    return []
  }
}

function moduleKind(name) {
  if (['src', 'app', 'apps'].includes(name)) return '应用逻辑'
  if (['packages', 'plugins', 'modules'].includes(name)) return '能力模块'
  if (['test', 'tests'].includes(name)) return '质量验证'
  if (['docs', 'documentation'].includes(name)) return '项目资料'
  return '项目模块'
}

function deriveFeatureStatus(feature, sessions, git) {
  const active = sessions.some((session) => session.runtimeStatus === 'active')
  let status = '状态未知'
  if (active) status = '正在开发'
  else if (sessions.some((session) => session.runtimeStatus === 'error')) status = '异常中断'
  else if (git?.dirty) status = '开发中，有未提交改动'
  else if (git?.merged) status = '已合并'
  else if (git && git.ahead > 0) status = '已提交，待测试或合并'
  else if (sessions.length) status = '暂停，等待继续'
  return { ...feature, status, sessions: [...sessions].sort((left, right) => right.updatedAt - left.updatedAt), git, updatedAt: Math.max(0, ...sessions.map((session) => session.updatedAt), git?.updatedAt ?? 0) }
}

function readGitState(repository, branch, paths) {
  if (!branch || !existsSync(join(repository, '.git'))) return null
  try {
    const run = (args) => execFileSync('git', args, { cwd: repository, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 5_000 }).trim()
    const currentBranch = run(['branch', '--show-current'])
    const changed = run(['status', '--porcelain=v1', '--', ...paths]).split('\n').filter(Boolean)
    const [behind = 0, ahead = 0] = run(['rev-list', '--left-right', '--count', `main...${branch}`]).split(/\s+/u).map(Number)
    let merged = false
    try { execFileSync('git', ['merge-base', '--is-ancestor', branch, 'main'], { cwd: repository, stdio: 'ignore', timeout: 5_000 }); merged = true } catch {}
    const updatedAt = Number(run(['log', '-1', '--format=%ct', branch])) * 1000 || 0
    return { branch, currentBranch, behind, ahead, merged, dirty: changed.length > 0, changedCount: changed.length, dirtyBranch: changed.length ? currentBranch : null, updatedAt }
  } catch {
    return null
  }
}

function normalizeTitle(...values) {
  for (const value of values) {
    const title = readableTitle(String(value ?? '').replace(/\s+/gu, ' ').trim())
    if (!title) continue
    return title.length > 80 ? `${title.slice(0, 80)}…` : title
  }
  return '未命名任务'
}

function readableTitle(value) {
  if (!value || /^https?:\/\//u.test(value)) return ''
  const referenced = value.replace(/^codex:\/\/threads\/[0-9a-f-]{36}\s*/iu, '').trim()
  return referenced.startsWith('codex://') ? '' : referenced
}

function isProjectDirectory(path) {
  try {
    return path !== '/' && statSync(path).isDirectory()
  } catch {
    return false
  }
}

function workspaceId(path) {
  return `project-${createHash('sha256').update(path).digest('hex').slice(0, 12)}`
}

function workspaceName(path) {
  const parts = path.split('/').filter(Boolean)
  return parts.at(-1) || path
}
