# Security Policy

## Scope

This package contains a DSH tool adapter. It must not contain API keys,
cookies, tenant records, user records, or provider credentials.

## Reporting

Please report security issues privately to the repository maintainers before
opening a public issue. Include the affected version, reproduction steps, and
the smallest safe disclosure possible.

Do not include real credentials or customer data in reports.
