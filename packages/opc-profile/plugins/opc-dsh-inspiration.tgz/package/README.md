# OPC Inspiration Plugin

Independent DSH host plugin for TikHub-backed Douyin inspiration, topic and
ranking tools. It owns only tool registration and the OPC API adapter; tenant
data, credentials, billing and provider policy remain in the OPC control plane.

Install it into a profile with `dsh plugin --profile <name> add @opc/dsh-inspiration`.

Before publishing or installing from a source checkout, run `pnpm build`. The
plugin refuses to run without an explicit tenant and user identity; production
profiles must inject these values from the authenticated OPC session rather
than relying on shared defaults.

## Configuration

The plugin is a thin DSH adapter. It calls the OPC API endpoint configured by
`apiBaseUrl` and sends the authenticated `tenantId` and `userId` configured by
the profile or environment:

```yaml
- insert:
    - id: opc-inspiration
      name: '@opc/dsh-inspiration'
      config:
        apiBaseUrl: 'https://opc.example.com'
        tenantId: 'tenant-from-your-session'
        userId: 'user-from-your-session'
```

`OPC_API_BASE_URL`, `OPC_TENANT_ID`, `OPC_USER_ID`, and `OPC_AGENT_API_KEY`
are supported for deployment environments. Do not commit their values. The
plugin deliberately fails when tenant or user identity is missing.

## Tools

The bundle contributes five host tools: categories, video rankings, topic
rankings, search rankings, and video search. The OPC control plane owns provider
credentials, billing, rate limits, tenant authorization, and upstream API
contracts.

## Development

```bash
pnpm install
pnpm typecheck
pnpm build
pnpm test
pnpm pack --dry-run
```

## License

MIT. See [LICENSE](./LICENSE).
