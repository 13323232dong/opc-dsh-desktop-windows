import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/**
 * Applies the authenticated tenant boundary to the native DSH session mirror.
 * The Host remains the authority; this client fence prevents a merchant shell
 * from presenting legacy shared sessions while the Host migration is pending.
 */
export declare function applySessionIsolation(ctx: ClientContext): void;
