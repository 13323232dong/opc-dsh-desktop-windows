import type { IncomingMessage } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Evan-OPC browser brand and SSO host plugin. */
export declare const name = "opc-brand";
export declare const inject: string[];
export interface Config {
    readonly opcApiBaseUrl?: string;
    readonly opcAdminUrl?: string;
    readonly opcWebBaseUrl?: string;
    readonly identityHmacSecret?: string;
    /** Dedicated optional signing key for the browser session cookie. */
    readonly sessionHmacSecret?: string;
    readonly sessionTtlMs?: number;
}
export interface OpcDshPrincipal {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
    /** OPC login session, distinct from the DSH conversation ID used as agentId. */
    readonly loginSessionId: string;
    readonly accountName?: string;
}
export interface OpcDshIdentityService {
    /** Resolve the authenticated OPC session for one DSH session. */
    resolve(sessionId: string, request?: IncomingMessage, parentSessionId?: string): Promise<OpcDshPrincipal | undefined>;
}
/** Accept either the public API origin or the internal /api/v1 base. */
export declare function normalizeApiOrigin(value: string): string;
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
/** Only expose the identity fields needed by the DSH shell. */
export declare function toPublicSession(claims: Record<string, unknown>): Record<string, unknown>;
