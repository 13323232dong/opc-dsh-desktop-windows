/**
 * Registers the current native DSH session against the authenticated browser
 * cookie. The component is mounted in a strict session-scoped utility slot,
 * so direct model tool calls do not depend on a prior gateway request.
 */
export declare function SessionBinding({ sessionId }: {
    sessionId: string;
}): null;
