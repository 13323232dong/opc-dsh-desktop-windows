import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type AccountSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'opcAccount'>;
/** Merchant account controls shown as a first-class DSH settings section. */
export declare function AccountSection({ t }: AccountSectionProps): import("react").JSX.Element;
