import type { SidebarFooterActionOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
/** Shows the authenticated OPC principal and the single logout action. */
export declare function SessionStatus({ wide }: SidebarFooterActionOwnerProps): import("react").JSX.Element;
