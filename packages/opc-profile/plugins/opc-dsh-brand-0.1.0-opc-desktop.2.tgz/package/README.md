# DSH Community OPC Brand

An independent DeepSeek Harness Web plugin that owns the sidebar and
empty-conversation brand slots for the Evan-OPC product.

It is intentionally limited to visible brand presentation. It does not change
Harness protocols, API routes, authentication, or agent behavior.

## Development

```bash
pnpm install
pnpm typecheck
pnpm build
pnpm test
```

The DSH loading page activates before client plugins. Its paired `Evan-OPC`
wordmark is configured by the Web shell, while this plugin controls the
brand shown once the application has loaded.
