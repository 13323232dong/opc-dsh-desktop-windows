# DSH Universal File Attachments

Session-scoped universal file attachments for [DeepSeek Harness (DSH)](https://github.com/deepseek-ai/DeepSeek-Harness).

It replaces path injection with a compact attachment rail: images, videos,
audio, documents, archives, unknown files, and folders are kept as safe,
session-scoped attachments. Browser and agent tooling receive attachment IDs,
never a local machine path.

## Features

- Drag or paste files directly into a DSH conversation. No extra picker UI.
- Preview images and videos; show type cards for documents, audio, archives,
  folders, and other files.
- Chunked uploads with SHA-256 finalization and a 2 GB per-file / 10 GB batch
  limit.
- Session, tenant, user, and agent isolation on every host route.
- Agent tools for listing, reading, extracting, searching, materializing, and
  explicitly importing attachments into an asset or knowledge service.
- Safe folder manifests: relative paths only; `.git`, `node_modules`,
  `.DS_Store`, device files, and unsafe paths are rejected.

## Platform support

The plugin is implemented with Node.js and standard Chromium browser APIs and
works on macOS, Windows 10/11, and Linux when DSH runs on a supported Node.js
runtime.

| Capability | Windows Chrome / Edge | macOS Chrome | Firefox |
| --- | --- | --- | --- |
| File drag and paste | Supported | Supported | Supported |
| Image / video previews | Supported | Supported | Supported |
| Folder drag with directory tree | Supported | Supported | Browser fallback only |
| Chunked file upload | Supported | Supported | Supported |

Folder traversal uses the File System Access API when available, then the
standard Chromium directory entry API, then the browser file list. Use current
Chrome or Edge for complete folder-tree support on Windows.

## Install

From a local clone:

```bash
git clone https://github.com/13323232dong/dsh-file-attachments.git
cd dsh-file-attachments
npm install
npm run build
dsh plugin --profile web add .
```

Restart the DSH web process after installation. The plugin occupies the
`conversation.input.attachments` slot with a higher-priority universal rail,
so remove other plugins that independently consume document-level file-drop
events.

## Configuration

The core attachment store works without external services. Optional explicit
imports to an OPC-compatible asset or knowledge API need server-side settings:

```yaml
- id: opc-file-attachments
  config:
    apiBaseUrl: https://your-opc-api.example
    identityHmacSecret: !!js process.env.OPC_DSH_IDENTITY_HMAC_SECRET
```

Never expose `identityHmacSecret` to the browser. The browser sends only its
current DSH session ID; the host resolves the principal and signs outbound
requests.

## Development

```bash
npm install
npm test
npm run typecheck
npm run build
```

## License

[MIT](LICENSE)
