export declare const ATTACHMENT_CHUNK_BYTES: number;
export declare const ATTACHMENT_FILE_MAX_BYTES: number;
export declare const ATTACHMENT_BATCH_MAX_BYTES: number;
export type AttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'archive' | 'folder' | 'file';
export type AttachmentStatus = 'queued' | 'uploading' | 'processing' | 'ready' | 'failed' | 'cancelled';
export type AttachmentPreview = Readonly<{
    type: 'image' | 'video' | 'audio' | 'icon' | 'folder';
    value: string;
}>;
export interface AttachmentOwner {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
    readonly sessionId: string;
}
export interface FolderManifestEntry {
    readonly path: string;
    readonly size: number;
    readonly mediaType: string;
}
export interface UniversalAttachment {
    readonly id: string;
    readonly kind: AttachmentKind;
    readonly name: string;
    readonly mediaType: string;
    readonly size: number;
    readonly status: AttachmentStatus;
    readonly preview: AttachmentPreview;
    readonly folderManifest?: readonly FolderManifestEntry[];
    readonly sessionId: string;
    readonly createdAt: number;
    readonly processingState: 'pending' | 'ready' | 'failed';
}
export interface CreateUploadInput {
    readonly name: string;
    readonly mediaType?: string;
    readonly size: number;
}
export interface CreateFolderInput {
    readonly name: string;
    readonly entries: readonly FolderManifestEntry[];
}
export interface UploadSnapshot {
    readonly id: string;
    readonly offset: number;
    readonly size: number;
    readonly status: Exclude<AttachmentStatus, 'processing' | 'ready' | 'failed'>;
}
export interface AttachmentRepository {
    createUpload(owner: AttachmentOwner, input: CreateUploadInput): UploadSnapshot;
    appendChunk(owner: AttachmentOwner, id: string, offset: number, bytes: Uint8Array): UploadSnapshot;
    finalizeUpload(owner: AttachmentOwner, id: string, sha256: string): UniversalAttachment;
    createFolder(owner: AttachmentOwner, input: CreateFolderInput): UniversalAttachment;
    getAttachment(owner: AttachmentOwner, id: string): UniversalAttachment;
    listAttachments(owner: AttachmentOwner): readonly UniversalAttachment[];
    readContent(owner: AttachmentOwner, id: string): Buffer;
    cancelUpload(owner: AttachmentOwner, id: string): UploadSnapshot;
}
export interface AttachmentRepositoryOptions {
    readonly maxFileBytes?: number;
    readonly maxBatchBytes?: number;
    readonly now?: () => number;
    readonly createId?: () => string;
}
export declare class AttachmentValidationError extends Error {
    constructor(message: string);
}
/** Classifies by a conservative MIME prefix first, then by filename extension. */
export declare function classifyAttachment(name: string, mediaType?: string): Readonly<{
    kind: AttachmentKind;
    extension: string;
}>;
/** Display names are opaque labels, never filesystem paths. */
export declare function sanitizeAttachmentName(value: string): string;
/** Folder manifests may preserve relative hierarchy but cannot reference the host filesystem. */
export declare function sanitizeRelativePath(value: string): string;
export declare function createAttachmentRepository(options?: AttachmentRepositoryOptions): AttachmentRepository;
