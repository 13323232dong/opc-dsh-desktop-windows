import React from 'react'

export const inject = ['slots']

const PLUGIN_PATH = '/plugins/opc-dev-status-control'
const CODEX_WORKSPACE_STORAGE_KEY = 'opc-dev-status-control.workspace-id'

function readStoredWorkspaceId() {
  try {
    return globalThis.localStorage?.getItem(CODEX_WORKSPACE_STORAGE_KEY) ?? ''
  } catch {
    return ''
  }
}

function writeStoredWorkspaceId(workspaceId) {
  try {
    globalThis.localStorage?.setItem(CODEX_WORKSPACE_STORAGE_KEY, workspaceId)
  } catch {
    // Storage is optional. The selected project still works for this mount.
  }
}

function boardRequest(path) {
  return fetch(`${PLUGIN_PATH}${path}`, { credentials: 'same-origin', cache: 'no-store' })
    .then(async (response) => {
      const payload = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(payload.error ?? '本机 Codex 控制服务未启动')
      return payload
    })
}

function relativeTime(value) {
  const timestamp = Number(value)
  if (!Number.isFinite(timestamp) || timestamp <= 0) return '未知'
  const minutes = Math.max(0, Math.floor((Date.now() - timestamp) / 60_000))
  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes} 分钟前`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours} 小时前`
  return `${Math.floor(hours / 24)} 天前`
}

function statusStyle(status) {
  if (status === 'active') return { color: '#0b6e4f', background: '#e5f6ee' }
  if (status === 'error') return { color: '#a4322f', background: '#fce9e7' }
  return { color: '#58635f', background: '#edf1ef' }
}

function sessionTitle(session) {
  const title = String(session?.title ?? '').trim()
  if (title && title !== '未命名任务') return title
  const shortId = String(session?.id ?? '').slice(0, 8)
  return shortId ? `未命名会话 · ${shortId}` : '未命名会话'
}

function featureStatusStyle(status) {
  if (String(status).includes('正在') || String(status).includes('开发中')) return { color: '#0b6e4f', background: '#e5f6ee' }
  if (String(status).includes('异常')) return { color: '#a4322f', background: '#fce9e7' }
  if (String(status).includes('已提交') || String(status).includes('待测试')) return { color: '#825800', background: '#fff2ce' }
  return { color: '#365d75', background: '#e7f0f5' }
}

function badge(label, style) {
  return React.createElement('span', {
    style: { display: 'inline-block', borderRadius: 3, fontSize: 12, fontWeight: 600, padding: '4px 8px', ...style },
  }, label)
}

function CodexControlView() {
  const [workspaces, setWorkspaces] = React.useState([])
  const [workspaceId, setWorkspaceId] = React.useState('')
  const [sessions, setSessions] = React.useState([])
  const [features, setFeatures] = React.useState([])
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState('')
  const [updatedAt, setUpdatedAt] = React.useState(0)
  const [query, setQuery] = React.useState('')
  const [statusFilter, setStatusFilter] = React.useState('all')

  const refresh = React.useCallback(async (selectedWorkspace) => {
    if (!selectedWorkspace) return
    setLoading(true)
    try {
      const [sessionPayload, statusPayload] = await Promise.all([
        boardRequest(`/sessions?workspace=${encodeURIComponent(selectedWorkspace)}`),
        boardRequest(`/status?workspace=${encodeURIComponent(selectedWorkspace)}`),
      ])
      setSessions(Array.isArray(sessionPayload.sessions) ? sessionPayload.sessions : [])
      setFeatures(Array.isArray(statusPayload.features) ? statusPayload.features : [])
      setUpdatedAt(Number(statusPayload.generatedAt) || Date.now())
      setError(statusPayload.codexError ? `Codex 状态读取失败：${statusPayload.codexError}` : '')
    } catch (cause) {
      setSessions([])
      setFeatures([])
      setError(cause instanceof Error ? cause.message : '本机 Codex 控制服务未启动')
    } finally {
      setLoading(false)
    }
  }, [])

  React.useEffect(() => {
    let disposed = false
    async function initialize() {
      setLoading(true)
      try {
        const payload = await boardRequest('/workspaces')
        const available = Array.isArray(payload.workspaces) ? payload.workspaces : []
        const storedWorkspaceId = readStoredWorkspaceId()
        const initial = available.find((item) => item.id === storedWorkspaceId)
          ?? available.find((item) => item.id === payload.defaultWorkspace)
          ?? available[0]
        if (disposed) return
        setWorkspaces(available)
        setWorkspaceId(initial?.id ?? '')
        if (!initial) {
          setError('未发现可用的本机 Codex 工作区')
          setLoading(false)
          return
        }
        await refresh(initial.id)
      } catch (cause) {
        if (!disposed) {
          setError(cause instanceof Error ? cause.message : '本机 Codex 控制服务未启动')
          setLoading(false)
        }
      }
    }
    void initialize()
    return () => { disposed = true }
  }, [refresh])

  const onWorkspaceChange = (event) => {
    const next = event.target.value
    writeStoredWorkspaceId(next)
    setWorkspaceId(next)
    void refresh(next)
  }

  const visibleSessions = sessions.filter((session) => {
    const needle = query.trim().toLowerCase()
    const matchesQuery = !needle || [sessionTitle(session), session.branch, session.id].some((value) => String(value ?? '').toLowerCase().includes(needle))
    return matchesQuery && (statusFilter === 'all' || session.runtimeStatus === statusFilter)
  })
  const activeCount = sessions.filter((session) => session.runtimeStatus === 'active').length
  const idleCount = sessions.length - activeCount

  const cardStyle = { border: '1px solid var(--dsw-alias-border-secondary, #dce2df)', background: 'var(--dsw-alias-background-default, #fff)', borderRadius: 8 }
  const muted = { color: 'var(--dsw-alias-label-secondary, #66716d)' }
  const controlStyle = { background: 'var(--dsw-alias-bg-layer-1, #fff)', border: '1px solid var(--dsw-alias-border-secondary, #dce2df)', borderRadius: 6, color: 'var(--dsw-alias-label-primary, #202124)', height: 36, padding: '0 10px' }

  return React.createElement('section', { style: { color: 'var(--dsw-alias-label-primary, #202124)', maxWidth: 1180, padding: '18px 22px 28px' } },
    React.createElement('header', { style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', display: 'flex', gap: 18, justifyContent: 'space-between', paddingBottom: 16 } },
      React.createElement('div', null,
        React.createElement('p', { style: { color: '#176b4d', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 10, fontWeight: 700, letterSpacing: 1, margin: '0 0 6px' } }, 'LOCAL CODEX'),
        React.createElement('h2', { style: { fontSize: 22, letterSpacing: 0, margin: 0 } }, 'Codex 任务看板'),
        React.createElement('p', { style: { ...muted, fontSize: 13, margin: '6px 0 0' } }, '查看本机工作区中的 Codex 会话与运行状态。'),
      ),
      React.createElement('div', { style: { alignItems: 'center', display: 'flex', gap: 8 } },
        React.createElement('select', { 'aria-label': '选择 Codex 工作区', disabled: workspaces.length === 0, onChange: onWorkspaceChange, style: { ...controlStyle, maxWidth: 230 }, value: workspaceId },
          workspaces.map((workspace) => React.createElement('option', { key: workspace.id, value: workspace.id }, workspace.name)),
        ),
        React.createElement('button', { 'aria-label': '刷新 Codex 状态', disabled: loading || !workspaceId, onClick: () => void refresh(workspaceId), style: { ...controlStyle, background: '#202124', borderColor: '#202124', color: '#fff', cursor: loading ? 'wait' : 'pointer', opacity: loading ? 0.6 : 1, padding: '0 13px' }, type: 'button' }, loading ? '同步中' : '刷新'),
      ),
    ),
    error ? React.createElement('p', { role: 'alert', style: { background: '#fce9e7', borderLeft: '3px solid #a4322f', color: '#a4322f', margin: '16px 0', padding: '10px 12px' } }, error) : null,
    React.createElement('div', { style: { alignItems: 'center', display: 'grid', gap: 10, gridTemplateColumns: 'repeat(4, minmax(120px, 1fr)) auto', margin: '18px 0 8px', padding: '8px 0' } },
      [['正在开发', features.filter((item) => String(item.status).includes('正在') || String(item.status).includes('开发中')).length], ['待测试 / 合并', features.filter((item) => String(item.status).includes('已提交') || item.mergeDecision === '待测试').length], ['已合并', features.filter((item) => item.status === '已合并').length], ['异常 / 未知', features.filter((item) => String(item.status).includes('异常') || String(item.status).includes('未知')).length]].map(([label, value]) => React.createElement('div', { key: label, style: { alignItems: 'baseline', borderRight: '1px solid var(--dsw-alias-border-secondary, #dce2df)', display: 'flex', gap: 8, paddingRight: 14 } }, React.createElement('strong', { style: { fontSize: 22 } }, value), React.createElement('span', { style: { ...muted, fontSize: 13 } }, label))),
      React.createElement('span', { style: { ...muted, fontSize: 12, textAlign: 'right' } }, updatedAt ? `最后同步 ${new Date(updatedAt).toLocaleTimeString('zh-CN')}` : '等待同步'),
    ),
    React.createElement('section', { style: { ...cardStyle, margin: '16px 0', overflow: 'hidden' } },
      React.createElement('div', { style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', display: 'flex', gap: 12, justifyContent: 'space-between', padding: '12px 16px' } },
        React.createElement('div', null,
          React.createElement('strong', { style: { fontSize: 16 } }, '当前项目 Codex 对话'),
          React.createElement('span', { style: { ...muted, fontSize: 12, marginLeft: 8 } }, `${sessions.length} 个会话 · ${activeCount} 个运行中 · ${idleCount} 个空闲`),
        ),
        React.createElement('input', { 'aria-label': '搜索当前项目 Codex 对话', onChange: (event) => setQuery(event.target.value), placeholder: '搜索标题、分支或 Session', style: { ...controlStyle, maxWidth: 260, width: '100%' }, value: query }),
      ),
      React.createElement('div', { style: { display: 'grid', gap: 0, maxHeight: 360, overflowY: 'auto' } }, (() => {
        if (!visibleSessions.length) return React.createElement('p', { style: { ...muted, margin: 0, padding: '22px 16px', textAlign: 'center' } }, loading ? '正在同步当前项目的 Codex 对话…' : '当前项目暂无可显示的 Codex 对话')
        return visibleSessions.slice(0, 60).map((session) => {
          const target = `codex://threads/${encodeURIComponent(session.id)}`
          return React.createElement('a', { key: session.id, href: target, onClick: (event) => { event.preventDefault(); event.stopPropagation(); window.open(target, '_blank', 'noopener,noreferrer') }, rel: 'noreferrer', style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', color: 'inherit', display: 'grid', gap: 12, gridTemplateColumns: 'minmax(260px, 1fr) 80px minmax(120px, .45fr) 88px', padding: '11px 16px', textDecoration: 'none' }, target: '_blank' },
            React.createElement('span', { style: { color: '#315f76', fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, sessionTitle(session)),
            badge(session.runtimeStatus === 'active' ? '运行中' : '空闲', statusStyle(session.runtimeStatus)),
            React.createElement('code', { style: { ...muted, fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, session.branch || '未记录分支'),
            React.createElement('span', { style: { ...muted, fontSize: 12, textAlign: 'right' } }, relativeTime(session.updatedAt)),
          )
        })
      })()),
      visibleSessions.length > 60 ? React.createElement('p', { style: { ...muted, fontSize: 12, margin: 0, padding: '9px 16px' } }, `仅显示前 60 个匹配会话，共 ${visibleSessions.length} 个。可使用搜索筛选。`) : null,
    ),
    React.createElement('nav', { 'aria-label': '状态筛选', style: { display: 'flex', gap: 4, margin: '4px 0 12px' } },
      [['all', '全部'], ['正在开发', '开发中'], ['待测试', '待测试'], ['已合并', '已合并'], ['异常', '异常']].map(([value, label]) => React.createElement('button', { key: value, onClick: () => setStatusFilter(value), style: { background: statusFilter === value ? '#202124' : 'transparent', border: 0, color: statusFilter === value ? '#fff' : muted.color, cursor: 'pointer', padding: '8px 12px' }, type: 'button' }, label)),
    ),
    React.createElement('section', { style: { ...cardStyle, overflow: 'auto' } },
      React.createElement('div', { style: { alignItems: 'center', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', display: 'flex', justifyContent: 'space-between', padding: '14px 16px' } }, React.createElement('strong', { style: { fontSize: 18 } }, '开发状态'), React.createElement('span', { style: { ...muted, fontSize: 12 } }, `${features.length} 项功能`)),
      React.createElement('table', { style: { borderCollapse: 'collapse', minWidth: 1060, tableLayout: 'fixed', width: '100%' } },
        React.createElement('thead', null, React.createElement('tr', null, ['功能', 'Codex 对话', '当前状态', '分支 / 代码证据', '合并判断', '下一步', '更新'].map((label) => React.createElement('th', { key: label, style: { background: 'var(--dsw-alias-bg-layer-2, rgba(32,33,36,.03))', borderBottom: '1px solid var(--dsw-alias-border-secondary, #dce2df)', color: muted.color, fontSize: 12, fontWeight: 600, padding: '12px 14px', textAlign: 'left' } }, label)))),
        React.createElement('tbody', null, (() => {
          const visible = features.filter((item) => statusFilter === 'all' || String(item.status).includes(statusFilter))
          if (!visible.length) return React.createElement('tr', null, React.createElement('td', { colSpan: 7, style: { ...muted, padding: 28, textAlign: 'center' } }, loading ? '正在同步 Codex 与 Git…' : '当前筛选没有功能'))
          return visible.map((feature) => React.createElement('tr', { key: feature.id },
            React.createElement('td', { style: { fontSize: 14, fontWeight: 650, padding: '15px 14px', verticalAlign: 'top' } }, feature.name),
        React.createElement('td', { style: { padding: '15px 14px', verticalAlign: 'top' } }, feature.sessions?.length ? React.createElement('div', { style: { display: 'grid', gap: 6 } }, feature.sessions.slice(0, 3).map((session) => { const target = `codex://threads/${encodeURIComponent(session.id)}`; return React.createElement('a', { key: session.id, href: target, target: '_blank', rel: 'noreferrer', onClick: (event) => { event.preventDefault(); event.stopPropagation(); window.open(target, '_blank', 'noopener,noreferrer') }, style: { color: '#315f76', cursor: 'pointer', textDecoration: 'none' } }, `${session.runtimeStatus === 'active' ? '●' : '•'} ${sessionTitle(session)}`) })) : React.createElement('span', { style: muted }, '未找到绑定对话')),
            React.createElement('td', { style: { padding: '15px 14px', verticalAlign: 'top' } }, badge(feature.status || '状态未知', featureStatusStyle(feature.status))),
            React.createElement('td', { style: { padding: '15px 14px', verticalAlign: 'top' } }, feature.git ? React.createElement('div', { style: { display: 'grid', gap: 5 } }, React.createElement('code', { style: { color: '#273b34', fontSize: 12 } }, feature.git.branch), React.createElement('small', { style: muted }, feature.git.merged ? '已进入 main' : `领先 main ${feature.git.ahead} 个提交`)) : React.createElement('span', { style: muted }, 'Git 证据不可用')),
            React.createElement('td', { style: { padding: '15px 14px', verticalAlign: 'top' } }, badge(feature.mergeDecision || '未判断', { color: '#59625f', background: '#edf0ee' })),
            React.createElement('td', { style: { fontSize: 13, lineHeight: 1.5, padding: '15px 14px', verticalAlign: 'top' } }, feature.nextStep || '等待下一步'),
            React.createElement('td', { style: { ...muted, fontSize: 12, padding: '15px 14px', verticalAlign: 'top', whiteSpace: 'nowrap' } }, feature.updatedAt ? relativeTime(feature.updatedAt) : '未知'),
          ))
        })()),
      ),
    ),
  )
}

export function apply(ctx) {
  ctx.slots.inject('conversation.view', () => ctx.slots.register({ name: 'conversation.view', id: 'opc-codex-control', order: 5, label: () => 'Codex 任务看板' }, CodexControlView))
}
