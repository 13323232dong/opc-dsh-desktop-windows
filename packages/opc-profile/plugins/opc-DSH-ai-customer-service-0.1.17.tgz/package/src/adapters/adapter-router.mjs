import { assertAdapterContract, normalizeAutomationError } from './adapter-contract.mjs';

export class AdapterRouter {
  constructor({ accessibility, vision, maxVisionFailures = 3, onDiagnostic } = {}) {
    this.accessibility = assertAdapterContract(accessibility, 'accessibility adapter');
    this.vision = assertAdapterContract(vision, 'vision adapter');
    this.maxVisionFailures = maxVisionFailures;
    this.onDiagnostic = onDiagnostic;
    this.visionFailures = new Map();
    this.lastAdapter = 'accessibility';
    this.accountId = null;
  }
  emit(patch) { this.onDiagnostic?.({ adapterKind: this.lastAdapter, ...patch }); }
  async call(method, ...args) {
    try {
      const result = await this.accessibility[method](...args);
      this.visionFailures.delete(method);
      this.lastAdapter = 'accessibility';
      this.emit({ stage: 'idle', failureCode: null });
      if (result?.accountId && this.accountId && result.accountId !== this.accountId) this.emit({ stage: 'paused', failureCode: 'WECHAT_ACCOUNT_CHANGED' });
      if (result?.accountId) this.accountId = result.accountId;
      return { ...result, adapterKind: 'accessibility' };
    } catch (error) {
      const normalized = normalizeAutomationError(error);
      if (!['WECHAT_HELPER_TIMEOUT', 'WECHAT_CHAT_LIST_UNAVAILABLE', 'WECHAT_ACCESSIBILITY_REQUIRED', 'WECHAT_UNREAD_UNAVAILABLE'].includes(normalized.code)) throw normalized;
      try {
        const result = await this.vision[method](...args);
        this.lastAdapter = 'vision';
        this.visionFailures.delete(method);
        this.emit({ stage: 'scanning', failureCode: null });
        if (result?.accountId) this.accountId = result.accountId;
        return { ...result, adapterKind: 'vision' };
      } catch (visionError) {
        const failures = (this.visionFailures.get(method) || 0) + 1;
        this.visionFailures.set(method, failures);
        const failure = normalizeAutomationError(visionError, 'VISION_PROVIDER_UNAVAILABLE');
        this.emit({ stage: failures >= this.maxVisionFailures ? 'paused' : 'scanning', failureCode: failure.code, consecutiveFailures: failures });
        if (failures >= this.maxVisionFailures) throw Object.assign(new Error('视觉适配器连续失败，已暂停'), { code: 'VISION_ADAPTER_PAUSED' });
        throw failure;
      }
    }
  }
  status() { return this.call('status'); }
  peekStatus() { return this.accessibility.peekStatus?.() ?? this.status(); }
  requestAccessibility() { return this.accessibility.requestAccessibility?.(); }
  listChats() { return this.call('listChats'); }
  findContact(...args) { return this.call('findContact', ...args); }
  openChat(...args) { return this.call('openChat', ...args); }
  readChat(...args) { return this.call('readChat', ...args); }
  readComposer(...args) { return this.call('readComposer', ...args); }
  draft(...args) { return this.call('draft', ...args); }
  sendAction(...args) { return this.call('sendAction', ...args); }
  readSendEvidence(...args) { return this.call('readSendEvidence', ...args); }
}
