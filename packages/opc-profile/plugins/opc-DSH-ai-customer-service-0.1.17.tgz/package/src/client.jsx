import React,{useEffect,useState,useRef} from 'react';
export const inject=['slots'];
const base='/plugins/ai-customer-service';
const labels={queued:'排队中',locating:'定位联系人',reading:'读取新消息',generating:'生成草稿',drafting:'写入微信输入框',drafted:'已写入草稿',cancelled:'已停止',inputting:'输入消息',sending:'正在发送',verifying:'验证发送结果',sent:'客户端已发送',failed:'发送失败',unknown:'结果待核验',paused:'人工接管',skipped:'已跳过',scanning:'扫描未读',measuring:'识别微信窗口'};
const progress={queued:0,locating:20,inputting:45,sending:65,verifying:85,sent:100,failed:100,unknown:85};
function Board(){
 const [data,setData]=useState({}),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const [contact,setContact]=useState(''),[text,setText]=useState(''),[business,setBusiness]=useState(''),[style,setStyle]=useState('简洁、自然，资料不足时询问');
 const sendRequest=useRef(null);
 function requestId(){const key=JSON.stringify([contact,text]);if(sendRequest.current?.key!==key)sendRequest.current={key,id:crypto.randomUUID()};return sendRequest.current.id;}
 async function load(){try{const r=await fetch(`${base}/status`);if(!r.ok)throw Error('客服状态暂时不可用');setData(await r.json());}catch(e){setError(e.message);}}
 useEffect(()=>{load();const t=setInterval(load,1000);return()=>clearInterval(t);},[]);
 async function act(path,args){setBusy(true);setError('');try{const r=await fetch(`${base}/${path}`,{method:'POST',headers:{'content-type':'application/json','x-dsh-customer-service':'1'},body:JSON.stringify(args)});const result=await r.json();if(!r.ok)throw Error(result.error?.code||result.error||result.message||'请求未完成');await load();}catch(e){setError(e.message);}finally{setBusy(false);}}
 const tasks=data.tasks||[],watches=data.watches||[],globalPreview=data.globalPreview||{events:[]};
 const previewEvents=globalPreview.events||[];
 const activePreview=previewEvents.find(event=>['locating','reading','generating','drafting'].includes(event.status));
 const scanAge=globalPreview.lastScanAt?Math.max(0,Math.floor((Date.now()-globalPreview.lastScanAt)/1000)):null;
 return <section style={{padding:24,overflow:'auto',height:'100%',background:'#10151f',color:'#e8edf5',fontSize:14}} aria-label="AI 客服">
 <h2>AI 客服 <small style={{fontSize:12,color:'#99b3cd'}}>微信桌面助手</small></h2>
 <p role="status">{busy?'正在提交任务…':data.ready?'微信已连接':data.failureCode?'微信暂不可用':'正在检查微信连接或权限'}　{data.failureCode||data.code||data.error?.code||''} {data.readOnly?'另一个桌面实例正在运行客服，本窗口只读':''}</p>
 {data.failureCode==='WECHAT_ACCESSIBILITY_REQUIRED'&&<button disabled={busy} onClick={()=>act('request-accessibility',{})}>打开辅助功能设置</button>}
 {error&&<p role="alert" style={{color:'#ffb8ab'}}>{error}</p>}
 <section style={{margin:'18px 0',padding:14,border:'1px solid #394252',borderRadius:8}}>
 <h3>全局微信草稿</h3>
 <p>跳过公众号、服务号、订阅号入口及文件传输助手。独立品牌账号在微信未提供账号类型时，暂不能可靠排除。</p>
 <p>立即按会话列表顺序处理当前及后续未读消息：进入目标聊天，生成并写入微信输入框。不会按发送；已有草稿会被 AI 草稿替换。</p>
 <button disabled={busy||data.readOnly} onClick={()=>act('global-preview',{enabled:!globalPreview.enabled})}>{globalPreview.enabled?'停止全局监听':'开启全局监听'}</button>
 <p role="status">适配器：{globalPreview.adapterKind||'router'} · 阶段：{labels[globalPreview.stage]||globalPreview.stage||'待机'} · 连续失败：{globalPreview.consecutiveFailures||0} · 最近扫描：{globalPreview.lastScanAt?new Date(globalPreview.lastScanAt).toLocaleTimeString():'尚未扫描'}</p>
 <p role="status">待处理：{previewEvents.filter(event=>event.status==='queued').length} · 当前任务：{activePreview?`${activePreview.title} · ${labels[activePreview.status]}`:'无'} · 距最近扫描：{scanAge===null?'尚未扫描':`${scanAge} 秒`}</p>
 {globalPreview.enabled&&scanAge>15&&<p role="alert">扫描已延迟：当前微信操作或扫描尚未完成。生成草稿不会阻塞下一轮扫描。</p>}
 {globalPreview.failureCode&&<p role="alert">预览异常：{globalPreview.failureCode}</p>}
 {(globalPreview.events||[]).length===0?<p>开启后会立即处理当前带未读标记的会话。</p>:<ol>{globalPreview.events.map(event=><li key={event.id}><strong>{event.title}</strong>：{event.preview} · {event.status==='drafted'?'已写入微信，待人工发送':event.status==='failed'?`草稿失败：${event.failureCode}`:labels[event.status]||'准备草稿中'}</li>)}</ol>}
 </section>
 <div style={{display:'grid',gap:12,maxWidth:780}}>
 <label>联系人<input aria-label="联系人" value={contact} onChange={e=>setContact(e.target.value)} style={{display:'block',width:'100%'}} placeholder="输入微信联系人名称"/></label>
 <label>发送内容<textarea aria-label="发送内容" value={text} onChange={e=>setText(e.target.value)} rows={3} style={{width:'100%'}}/></label>
 <button disabled={busy||data.readOnly||!contact.trim()||!text.trim()} onClick={()=>act('send',{contact,text,requestId:requestId()})}>发送消息</button>
 <label>业务资料<textarea value={business} onChange={e=>setBusiness(e.target.value)} rows={3} style={{width:'100%'}} placeholder="服务内容、已确认的价格与政策"/></label>
 <label>回复风格<input value={style} onChange={e=>setStyle(e.target.value)} style={{width:'100%'}}/></label>
 <button disabled={busy||!contact.trim()} onClick={()=>act('watch',{contact,enabled:true,businessInstructions:business,style})}>开启此联系人自动回复</button>
 </div>
 <h3>托管联系人</h3>{watches.length===0?<p>暂无托管联系人。首次开启请在 DSH 对话中指定联系人和业务资料。</p>:watches.map((w,i)=><div key={w.id||i}>{typeof w.contact==='string'?w.contact:w.contact?.name} · {w.enabled?'自动回复中':'已暂停'} · {w.failureCode||''} <button disabled={data.readOnly} onClick={()=>w.enabled?act('pause',{contact:w.contact}):act('watch',{contact:w.contact,enabled:true,businessInstructions:w.businessInstructions,style:w.style})}>{w.enabled?'人工接管':'恢复托管'}</button></div>)}
 <h3>发送任务</h3>{tasks.length===0?<p>暂无发送任务</p>:tasks.map(t=><article key={t.id||t.taskId} style={{padding:16,marginBottom:12,border:'1px solid #394252',borderRadius:10}}>
 <strong>{typeof t.contact==='string'?t.contact:t.contact?.name}</strong><span style={{float:'right'}}>{labels[t.status]||t.status}</span>
 <p style={{whiteSpace:'pre-wrap'}}>{t.text}</p><progress style={{width:'100%'}} max="100" value={progress[t.status]||0}/>
 {(t.failureCode||t.error)&&<p role="alert">责任归属：{t.responsibility||'桌面自动化'} · {t.failureCode||t.error?.code} · {t.error?.message||t.failureReason||'请检查微信及连接状态'}</p>}
 </article>)}
 </section>;
}
export function apply(ctx){ctx.slots.inject('conversation.view',()=>ctx.slots.register({name:'conversation.view',id:'ai-customer-service',order:35,label:()=>'AI 客服'},Board));}
