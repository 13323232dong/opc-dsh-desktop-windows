export interface ContextRetrievalGatewayConfig {
    readonly apiBaseUrl?: string;
    readonly identityHmacSecret?: string;
    readonly requestTimeoutMs?: number;
}
export interface ContextRetrievalPrincipal {
    readonly tenantId: string;
    readonly userId: string;
    readonly agentId: string;
}
export interface ContextRetrievalGatewayDependencies {
    readonly fetcher?: typeof fetch;
    readonly resolveIdentity: (sessionId: string, parentSessionId?: string) => Promise<ContextRetrievalPrincipal | undefined>;
    readonly environment?: NodeJS.ProcessEnv;
    readonly now?: () => number;
    readonly nonce?: () => string;
    readonly scheduleTimeout?: (callback: () => void, delayMs: number) => unknown;
    readonly cancelTimeout?: (handle: unknown) => void;
}
export interface ContextRetrievalGatewayRequest {
    readonly sessionId: string;
    readonly parentSessionId?: string;
    readonly action: string;
    readonly input: unknown;
}
export declare class ContextRetrievalGatewayError extends Error {
}
export declare function createContextRetrievalGateway(config: ContextRetrievalGatewayConfig, dependencies: ContextRetrievalGatewayDependencies): {
    execute(request: ContextRetrievalGatewayRequest): Promise<unknown>;
};
