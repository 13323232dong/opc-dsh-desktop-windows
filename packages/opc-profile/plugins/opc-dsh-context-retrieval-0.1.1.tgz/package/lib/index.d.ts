import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "opc-context-retrieval";
export declare const inject: string[];
export interface Config {
    readonly apiBaseUrl?: string;
    readonly identityHmacSecret?: string;
    readonly requestTimeoutMs?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export { SYSTEM_PROMPT } from './prompt.js';
export { ContextRetrievalGatewayError, createContextRetrievalGateway, } from './gateway.js';
