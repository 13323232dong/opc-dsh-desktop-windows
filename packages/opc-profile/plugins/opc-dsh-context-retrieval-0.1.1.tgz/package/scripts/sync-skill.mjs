import { mkdir, readFile, writeFile } from 'node:fs/promises'

const published = new URL('../skills/opc-business-context/SKILL.md', import.meta.url)
const runtime = new URL('../../../.dsh/skills/opc-business-context/SKILL.md', import.meta.url)
const expected = await readFile(published, 'utf8')

if (process.argv.includes('--check')) {
  const actual = await readFile(runtime, 'utf8').catch(() => undefined)
  if (actual !== expected) {
    throw new Error('opc-business-context runtime mirror is missing or stale; run npm run sync:skill')
  }
} else {
  await mkdir(new URL('.', runtime), { recursive: true })
  await writeFile(runtime, expected, 'utf8')
}
