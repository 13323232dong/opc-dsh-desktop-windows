# OPC Context Retrieval

DSH host plugin exposing three read-only OPC business-context tools. The plugin derives tenant, user, and Agent identity from the trusted DSH session identity service and signs requests to fixed OPC API gateway routes.

The model-facing inputs never accept `tenantId`, `userId`, or `scope`. Search results are references rather than authoritative dynamic state; use `opc_context_get` to resolve current full content.

The publishable Skill lives at `skills/opc-business-context/SKILL.md`. Run `npm run sync:skill` to update the workspace `.dsh` runtime mirror, or `npm run check:skill` to verify that the two copies match.
