import test from 'node:test';
import assert from 'node:assert/strict';
import {createKnowledgeReplyGenerator} from '../src/knowledge.mjs';

test('retrieves before generating and carries source evidence without private content',async()=>{
 const events=[];
 const generate=createKnowledgeReplyGenerator({
  search:async(input)=>{events.push(input);return {results:[{title:'营业',relativePath:'商户/营业.md',snippet:'9点开门',sourceType:'markdown'}]};},
  reply:async(input)=>{assert.equal(input.knowledge[0].snippet,'9点开门');return '我们9点开门';},
 });
 const result=await generate({messages:[{direction:'incoming',text:'几点开门'}]});
 assert.equal(events[0].query,'几点开门');
 assert.equal(result.text,'我们9点开门');
 assert.deepEqual(result.knowledgeSources,[{title:'营业',relativePath:'商户/营业.md'}]);
});
test('unavailable knowledge fails closed without model call or raw errors',async()=>{
 const generate=createKnowledgeReplyGenerator({search:async()=>{throw Error('private-path');},reply:async()=>assert.fail('must not generate')});
 await assert.rejects(generate({messages:[{text:'问题'}]}),e=>e.code==='WECHAT_KNOWLEDGE_UNAVAILABLE'&&!e.message.includes('private-path'));
});
test('no matching knowledge is explicit and does not invent evidence',async()=>{
 const generate=createKnowledgeReplyGenerator({search:async()=>({results:[]}),reply:async input=>{assert.deepEqual(input.knowledge,[]);return '资料中暂无答案，需要人工确认';}});
 const result=await generate({messages:[{text:'问题'}]});
 assert.deepEqual(result.knowledgeSources,[]);
});
