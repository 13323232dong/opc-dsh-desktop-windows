import test from 'node:test';
import assert from 'node:assert/strict';
import { MacWechatAdapter } from '../src/macos.mjs';
test('reject unsupported platform before transport', async () => {
  const adapter = new MacWechatAdapter({ platform: 'win32', transport: () => assert.fail('must not run') });
  await assert.rejects(adapter.status(), { code: 'WECHAT_PLATFORM_UNSUPPORTED' });
});
test('adapter preserves exact contact and text and stage callback', async () => {
  const calls = [], stages = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload, stage) => {
    calls.push({ method, payload }); stage?.('verifying'); return { status: 'unknown' };
  } });
  const contact = { contactId: 'account:邹敏', title: '邹敏', accountId: 'account' };
  assert.deepEqual(await adapter.send(contact, 'AI发送测试', { onStage: stage => stages.push(stage) }), { status: 'unknown' });
  assert.deepEqual(calls, [{ method: 'send', payload: { contact, text: 'AI发送测试' } }]);
  assert.deepEqual(stages, ['verifying']);
});
test('adapter exposes an explicit accessibility permission request', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return { ready: false, permissionRequested: true };
  } });
  assert.deepEqual(await adapter.requestAccessibility(), { ready: false, permissionRequested: true });
  assert.deepEqual(calls, [{ method: 'requestAccessibility', payload: {} }]);
});
test('missing helper produces stable error without raw process output', async () => {
  const adapter = new MacWechatAdapter({ platform: 'darwin', binaryPath: '/nonexistent/wechat-helper' });
  await assert.rejects(adapter.status(), { code: 'WECHAT_HELPER_UNAVAILABLE' });
});
test('status cache avoids repeatedly opening account popup but send remains fresh', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async method => {
    calls.push(method); return { ready: true, accountId: 'example' };
  } });
  await adapter.status(); await adapter.status(); await adapter.send('contact', 'text');
  assert.deepEqual(calls, ['status', 'send']);
});
test('adapter exposes read-only visible conversation previews', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method) => {
    calls.push(method); return { accountId: 'example', chats: [{ id: 'example:甲', title: '甲', preview: '你好' }] };
  } });
  assert.deepEqual(await adapter.listChats(), { accountId: 'example', chats: [{ id: 'example:甲', title: '甲', preview: '你好' }] });
  assert.deepEqual(calls, ['listChats']);
});
test('adapter drafts into WeChat without invoking the send operation', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return { status: 'drafted', evidence: { kind: 'input_draft' } };
  } });
  await adapter.draft({ title: '甲' }, '您好');
  assert.deepEqual(calls, [{ method: 'draft', payload: { contact: { title: '甲' }, text: '您好' } }]);
});
test('adapter forwards draft replacement only when explicitly requested', async () => {
  const calls = [];
  const adapter = new MacWechatAdapter({ platform: 'darwin', transport: async (method, payload) => {
    calls.push({ method, payload }); return { status: 'drafted', evidence: { kind: 'input_draft' } };
  } });
  await adapter.draft({ title: '甲' }, '您好', { replaceExisting: true });
  assert.deepEqual(calls, [{ method: 'draft', payload: { contact: { title: '甲' }, text: '您好', replaceExisting: true } }]);
});
