import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { assertAdapterContract } from './adapters/adapter-contract.mjs';

export class MacWechatAdapter {
  constructor({ binaryPath, platform = process.platform, transport } = {}) {
    this.binaryPath = binaryPath || process.env.DSH_WECHAT_HELPER_PATH || fileURLToPath(new URL('../native/bin/wechat-helper', import.meta.url));
    this.platform = platform;
    this.transport = transport;
    assertAdapterContract(this, 'Mac WeChat adapter');
  }
  async call(method, payload = {}, onStage) {
    if (this.platform !== 'darwin') throw Object.assign(new Error('当前微信适配器仅支持 macOS'), { code: 'WECHAT_PLATFORM_UNSUPPORTED' });
    if (this.transport) return this.transport(method, payload, onStage);
    return new Promise((resolve, reject) => {
      const child = spawn(this.binaryPath, [], { stdio: ['pipe', 'pipe', 'ignore'] });
      const requestId = randomUUID();
      let buffer = '', settled = false;
      const finish = (error, result) => {
        if (settled) return;
        settled = true; clearTimeout(timeout); child.kill();
        error ? reject(error) : resolve(result);
      };
      const timeout = setTimeout(() => finish(Object.assign(new Error('微信操作超时，发送结果需核查'), { code: method === 'send' ? 'WECHAT_SEND_UNKNOWN' : 'WECHAT_HELPER_TIMEOUT' })), 45000);
      child.on('error', () => finish(Object.assign(new Error('微信本地控制组件不可用'), { code: 'WECHAT_HELPER_UNAVAILABLE' })));
      child.stdout.on('data', data => {
        buffer += data.toString();
        if (buffer.length > 2_000_000) return finish(Object.assign(new Error('微信响应超出限制'), { code: 'WECHAT_PROTOCOL_ERROR' }));
        let split;
        while ((split = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, split); buffer = buffer.slice(split + 1);
          try {
            const item = JSON.parse(line);
            if (item.requestId !== requestId) continue;
            if (item.stage) { onStage?.(item.stage); continue; }
            finish(item.ok ? null : Object.assign(new Error(item.error?.message || '微信操作失败'), { code: item.error?.code || 'WECHAT_HELPER_ERROR' }), item.result);
          } catch { finish(Object.assign(new Error('微信组件返回无效响应'), { code: 'WECHAT_PROTOCOL_ERROR' })); }
        }
      });
      child.on('close', () => finish(Object.assign(new Error('微信组件意外退出'), { code: method === 'send' ? 'WECHAT_SEND_UNKNOWN' : 'WECHAT_HELPER_UNAVAILABLE' })));
      child.stdin.end(JSON.stringify({ requestId, method, payload }) + '\n');
    });
  }
  async status() {
    if (this.statusCache && Date.now() - this.statusCache.at < 15000) return this.statusCache.result;
    const result = await this.call('status');
    this.statusCache = { at: Date.now(), result };
    return result;
  }
  requestAccessibility() { return this.call('requestAccessibility'); }
  findContact(name) { return this.call('findContact', { name }); }
  listChats() { return this.call('listChats'); }
  openChat(contact) { return this.call('openChat', { contact }); }
  readChat(contact) { return this.call('readChat', { contact }); }
  readComposer(contact) { return this.call('readComposer', { contact }); }
  draft(contact, text, { replaceExisting = false } = {}) { return this.call('draft', { contact, text, ...(replaceExisting ? { replaceExisting: true } : {}) }); }
  sendAction(contact, text) { return this.call('sendAction', { contact, text }); }
  readSendEvidence(contact, text, before = []) { return this.call('readSendEvidence', { contact, text, before }); }
  send(contact, text, { onStage } = {}) { return this.call('send', { contact, text }, onStage); }
}
