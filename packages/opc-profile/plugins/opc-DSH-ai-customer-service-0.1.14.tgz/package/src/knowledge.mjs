export function createKnowledgeReplyGenerator({ search, reply }) {
  return async input => {
    const query = input.messages.map(message => message.text ?? '').join('\n').trim().slice(0, 2000);
    let knowledge;
    try {
      const response = await search({ query, limit: 5 });
      if (!Array.isArray(response?.results)) throw new Error('INVALID_KNOWLEDGE_RESULT');
      knowledge = response.results.slice(0, 5).map(item => {
        if (typeof item.title !== 'string' || typeof item.relativePath !== 'string' || typeof item.snippet !== 'string') throw new Error('INVALID_KNOWLEDGE_RESULT');
        return { title: item.title.slice(0, 300), relativePath: item.relativePath.slice(0, 500), snippet: item.snippet.slice(0, 3000) };
      });
    } catch {
      throw Object.assign(new Error('第二大脑检索不可用，待回复消息已保留，请检查知识库及索引'), { code: 'WECHAT_KNOWLEDGE_UNAVAILABLE' });
    }
    const text = await reply({ ...input, knowledge });
    return { text, knowledgeSources: knowledge.map(({ title, relativePath }) => ({ title, relativePath })) };
  };
}

export function createSecondBrainSearch() {
  let service;
  return async input => {
    // Reuse the installed plugin's public core and its existing linked-vault configuration.
    if (!service) {
      const { SecondBrainService } = await import('@opc/dsh-second-brain/core');
      service = new SecondBrainService({ desktopMode: true });
    }
    return service.search(input);
  };
}
