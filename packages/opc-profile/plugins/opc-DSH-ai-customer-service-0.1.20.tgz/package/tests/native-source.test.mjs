import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

test('history returns verified loaded messages with honest coverage before any composer mutation', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  const start = source.indexOf('if method == "readHistory" {', source.indexOf('let baseline = try messages'))
  const end = source.indexOf('guard let text = payload["text"]', start)
  assert.ok(start > 0 && end > start)
  const history = source.slice(start, end)
  assert.match(history, /"pagesRead": 1/)
  assert.match(history, /"requestedPages": requestedPages/)
  assert.match(history, /"complete": false/)
  assert.match(history, /"source": "wechat_accessibility"/)
  assert.match(history, /"timeLabels": timeLabels/)
  assert.match(history, /identity\.merging/)
  assert.doesNotMatch(history, /try key|press\(|AXUIElementSetAttributeValue|messages\(/)
  assert.match(source, /"timestampLabel": stamp/)
  assert.match(source, /WECHAT_HISTORY_PAGES_INVALID/)
});

test('wechat search waits for asynchronous AX value and submits the query', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /for _ in 0\.\.<8[\s\S]*attr\(search, "AXValue"\) == title/)
  assert.match(source, /AXUIElementSetAttributeValue\(search, "AXValue" as CFString, title as CFTypeRef\)/)
  assert.match(source, /guard received else \{ try fail\("WECHAT_SEARCH_UNAVAILABLE"/)
  assert.match(source, /guard received else[\s\S]*try key\(36\); pause\(0\.25\)/)
})

test('wechat actions recover a transient DSH focus change before failing', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /if NSWorkspace\.shared\.frontmostApplication\?\.bundleIdentifier != bundle[\s\S]*running\.activate\(options: \[\.activateAllWindows\]\)/)
  assert.match(source, /guard NSWorkspace\.shared\.frontmostApplication\?\.bundleIdentifier == bundle else \{ try fail\("WECHAT_FOCUS_CHANGED"/)
})

test('wechat send checks platform failures only in the active message table', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /func currentChatHasFailure\(_ application: AXUIElement\) -> Bool/)
  assert.match(source, /let failures = currentChatHasFailure\(application\)/)
  assert.doesNotMatch(source, /let failures = all\(application\)\.contains/)
})

test('split send action and evidence reads never rewrite the composer', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  const sendAction = source.indexOf('if method == "sendAction"')
  const evidence = source.indexOf('if method == "readSendEvidence"')
  const draftMutation = source.indexOf('let replaceExisting = payload["replaceExisting"]')
  assert.ok(sendAction > 0 && evidence > sendAction && draftMutation > evidence)
  assert.match(source.slice(sendAction, evidence), /guard existingDraft == text/)
  assert.doesNotMatch(source.slice(evidence, draftMutation), /AXUIElementSetAttributeValue/)
})

test('wechat contact lookup resolves one visible prefix match to its full chat title', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /func visibleChatTitle\(_ row: AXUIElement, _ query: String\) -> String\?/) 
  assert.match(source, /title == query \|\| title\.hasPrefix\(query \+ "（"\)/)
  assert.match(source, /let visibleMatches = visibleRows\.compactMap \{ visibleChatTitle\(\$0, title\) \}/)
  assert.match(source, /let resolvedTitle = try openContact\(application, title, verifyComposer: method != "findContact"\)/)
  assert.match(source, /"contactId": accountId \+ ":" \+ resolvedTitle/)
})

test('global preview reads a bounded chat accessibility subtree and preserves unread state', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /func chatPreviews\(_ application: AXUIElement, _ accountId: String\)/)
  assert.match(source, /func accessibleText\(_ e: AXUIElement\) -> String/)
  assert.match(source, /children\(e\)\.prefix\(24\)/)
  assert.match(source, /children\(\$0\)\.prefix\(12\)/)
  const accessibleTextSource = source.match(
    /func accessibleText\([\s\S]*?\n}\n/
  )?.[0] ?? ''
  assert.doesNotMatch(accessibleTextSource, /nodes\(e\)/)
  assert.match(source, /func chatRows\(_ table: AXUIElement\) -> \[AXUIElement\]/)
  assert.match(source, /children\(table, "AXVisibleChildren"\) \+ children\(table, "AXRows"\)\)\.filter/)
  assert.match(source, /inspected < 1200 && rows\.count < 120/)
  assert.match(source, /let isChatRow = attr\(element, "AXRole"\) == "AXRow"/)
  assert.match(source, /if isChatRow \{ rows\.append\(element\); continue \}/)
  assert.match(source, /for row in chatRows\(table\)/)
  assert.match(source, /\(\[0-9\]\+\|99\\\\\+\)条未读/)
  assert.match(source, /"hasUnread": hasUnread/)
  assert.match(source, /if method == "listChats" \{ return \["accountId": accountId, "chats": chatPreviews/)
})

test('global drafts may replace a visible existing draft, but never send', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /let replaceExisting = payload\["replaceExisting"\] as\? Bool \?\? false/)
  assert.match(source, /WECHAT_DRAFT_REPLACE_FAILED/)
  assert.match(source, /"replacedExistingDraft": !existingDraft\.isEmpty/)
  assert.match(source, /if method == "draft" \{ return \[/)
})

test('periodic chat scans do not activate WeChat or send focus keys', async () => {
  const source = await readFile(new URL('../native/main.swift', import.meta.url), 'utf8')
  assert.match(source, /func app\(_ activate: Bool = true\)/)
  assert.match(source, /if activate \{[\s\S]*running\.activate\(options: \[\.activateAllWindows\]\)/)
  assert.match(source, /func account\(_ application: AXUIElement, _ allowInteraction: Bool = true\)/)
  assert.match(source, /if !allowInteraction \{[\s\S]*WECHAT_ACCOUNT_UNAVAILABLE/)
  assert.match(source, /let readOnlyScan = method == "listChats"/)
  assert.match(source, /let expectedAccountId = payload\["accountId"\] as\? String/)
  assert.match(source, /let application = try app\(!readOnlyScan\)/)
  assert.match(source, /let accountId = readOnlyScan \? expectedAccountId! : try account\(application\)/)
})
