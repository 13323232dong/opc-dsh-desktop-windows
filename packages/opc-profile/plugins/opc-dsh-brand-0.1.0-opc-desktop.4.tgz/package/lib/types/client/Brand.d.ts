import type { HeroBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { SidebarBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
export declare const PRODUCT_NAME = "Evan\u8D85\u7EA7\u7BA1\u5BB6";
export declare const BOOT_NAME = "Evan-OPC";
type BrandMarkProps = HeroBrandMarkOwnerProps & SidebarBrandMarkOwnerProps;
/** Render the compact Evan-OPC mark at every product brand seat. */
export declare function BrandMark({ size, className }: BrandMarkProps): import("react").JSX.Element;
/** Render the owner-facing product name in the sidebar. */
export declare function BrandName(): import("react").JSX.Element;
export {};
