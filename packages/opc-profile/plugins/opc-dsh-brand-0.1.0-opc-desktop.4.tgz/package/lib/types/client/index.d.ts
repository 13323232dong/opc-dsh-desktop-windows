import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        opcAccount: 'nav' | 'title' | 'intro' | 'account' | 'loading' | 'online' | 'credits' | 'rechargeHint' | 'recharge' | 'password' | 'boundEmail' | 'emailRequired' | 'sendReset' | 'resetSending' | 'resetSent' | 'resetError' | 'reset' | 'logout' | 'logoutConfirm' | 'logoutError' | 'signingOut' | 'restart' | 'restarting' | 'restartConfirm';
    }
}
/** Fill the DSH brand slots with the Evan-OPC identity. */
export declare function apply(ctx: ClientContext): void;
