# @opc/dsh-douyin-comment-ops

Ego Lite 驱动的抖音评论研究与一对一私信插件。

插件在 Agent Teams 中提供唯一的“同行截流”入口，并暴露稳定的 `competitor_chase_*` 工具：采集、状态查询、意向分析、私信提案、授权和发送。结果按当前 Session 隔离；发送必须携带一次性用户确认，遇到验证码、风控或登录失效会停止后续发送。

工具分为只读和写操作：评论搜索、评论读取、账号状态无需确认；私信先生成草稿，再由用户明确确认后单条发送。插件不接受 Cookie、账号密码、外部 URL 或批量发送指令，不尝试绕过验证码和风控。

安装：

```bash
dsh plugin --profile <profile> add /Users/mac/OPC智能体团队/dsh-plugins/opc-douyin-comment-ops
```
