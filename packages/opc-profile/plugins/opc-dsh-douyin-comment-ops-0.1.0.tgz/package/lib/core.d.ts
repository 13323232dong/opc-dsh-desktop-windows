//#region src/core.d.ts
declare class CommentOpsError extends Error {
  readonly code: string;
  constructor(code: string, message: string);
}
interface EgoRunner {
  run(operation: string, input: Record<string, unknown>, onProgress?: (message: string) => void): Promise<Record<string, unknown>>;
}
interface CommentOpsServiceOptions {
  readonly storageFile?: string;
}
interface DouyinAccountRef {
  accountId: string;
  platformUserId?: string;
  handle?: string;
  displayName: string;
  profileUrl?: string;
  accountFingerprint: string;
  capturedAt: string;
}
interface CompetitorAccountRef {
  accountId?: string;
  handle?: string;
  displayName: string;
  profileUrl?: string;
}
interface CompetitorVideoRef {
  videoId?: string;
  title: string;
  url: string;
  publishedAt?: string;
}
interface Proposal {
  proposalId: string;
  agentId: string;
  sessionId: string;
  recipient: string;
  message: string;
  confirmationToken: string;
  status: 'waiting_confirmation' | 'sent';
  senderAccount?: DouyinAccountRef;
}
type BoardItemKind = 'search' | 'comments' | 'dm_prepare' | 'dm_send';
type BoardItemStatus = 'completed' | 'awaiting_approval' | 'sent' | 'failed';
interface BoardItem {
  id: string;
  sessionId: string;
  kind: BoardItemKind;
  status: BoardItemStatus;
  summary: string;
  createdAt: string;
  proposalId?: string;
  collectorAccount?: DouyinAccountRef;
  senderAccount?: DouyinAccountRef;
  sourceAccount?: CompetitorAccountRef;
  sourceVideo?: CompetitorVideoRef;
}
interface CommentOpsBoard {
  items: BoardItem[];
}
type IntentLevel = 'high' | 'medium' | 'low';
type SendItemStatus = 'draft' | 'awaiting_confirmation' | 'queued' | 'sending' | 'sent' | 'failed' | 'skipped';
interface IntentComment {
  commentId: string;
  sourceAccount: string;
  sourceAccountUrl: string;
  sourceAccountRef?: CompetitorAccountRef;
  sourceVideo?: CompetitorVideoRef;
  videoTitle: string;
  videoUrl: string;
  commentAuthor: string;
  commentAuthorId: string;
  avatarUrl?: string;
  commentText: string;
  commentCreatedAt?: string;
  intentLevel: IntentLevel;
  intentReason: string;
  confidence: number;
  analysisSource?: 'rule' | 'agent';
  ruleId?: string;
  matchedKeywords?: string[];
  draftMessage?: string;
  selected?: boolean;
  sendStatus: SendItemStatus;
  sendProgress?: string;
  failureCode?: string;
  deliveryVerifiedAt?: string;
  sessionId: string;
  createdAt: string;
  collectorAccount?: DouyinAccountRef;
  senderAccount?: DouyinAccountRef;
}
interface BatchDmItem {
  commentId: string;
  recipient: string;
  message: string;
}
interface BatchDmProposal {
  proposalId: string;
  agentId: string;
  sessionId: string;
  items: BatchDmItem[];
  confirmationToken: string;
  inputHash: string;
  status: 'waiting_confirmation' | 'authorized' | 'completed';
  collectorAccount?: DouyinAccountRef;
  senderAccount?: DouyinAccountRef;
}
interface BatchDmAuthorization {
  authorizationId: string;
  proposalId: string;
  agentId: string;
  sessionId: string;
  collectorAccount?: DouyinAccountRef;
  senderAccount?: DouyinAccountRef;
  commentIds: string[];
  status: 'active' | 'consumed' | 'stopped';
  createdAt: string;
}
interface BatchDmResult {
  proposalId: string;
  authorizationId?: string;
  sent: number;
  failed: number;
  skipped: number;
  stopped: boolean;
  senderAccount?: DouyinAccountRef;
  items: Array<{
    commentId: string;
    status: SendItemStatus;
    error?: string;
    collectorAccount?: DouyinAccountRef;
    senderAccount?: DouyinAccountRef;
    sourceAccount?: CompetitorAccountRef;
    sourceVideo?: CompetitorVideoRef;
  }>;
}
interface ChaseResult {
  keywordOrAccount: string;
  videos: Array<Record<string, unknown>>;
  comments: IntentComment[];
  collectorAccount?: DouyinAccountRef;
}
interface ChaseRun {
  runId: string;
  requestKey: string;
  sessionId: string;
  keywordOrAccount: string;
  limit: number;
  status: 'running' | 'completed' | 'failed';
  startedAt: string;
  updatedAt: string;
  result?: ChaseResult;
  errorCode?: 'CHASE_FAILED';
}
type InterceptChannel = 'dm' | 'comment';
interface InterceptRuleInput {
  name: string;
  keyword: string;
  commentKeywords: string[];
  draftTemplate: string;
  channel: InterceptChannel;
}
interface InterceptRule extends InterceptRuleInput {
  ruleId: string;
  sessionId: string;
  status: 'enabled' | 'disabled';
  createdAt: string;
  updatedAt: string;
  lastRunAt?: string;
  lastRunReason?: string;
  lastMatchedCount?: number;
}
interface AgentIntentAssessment {
  commentId: string;
  keep: boolean;
  intentLevel: IntentLevel;
  confidence: number;
  reason: string;
}
declare function createCommentOpsService(runner: EgoRunner, options?: CommentOpsServiceOptions): {
  search(keyword: string, limit?: number, sessionId?: string): Promise<Record<string, unknown>>;
  comments(videoUrl: string, limit?: number, sessionId?: string): Promise<{
    collectorAccount?: DouyinAccountRef | undefined;
  }>;
  chase(keywordOrAccount: string, limit?: number, sessionId?: string): Promise<ChaseResult>;
  createInterceptRule(sessionId: string, input: InterceptRuleInput): InterceptRule;
  listInterceptRules(_sessionId?: string): InterceptRule[];
  setInterceptRuleEnabled(ruleId: string, sessionId: string, enabled: boolean): InterceptRule;
  runInterceptRule(ruleId: string, sessionId: string, limit?: number): Promise<ChaseResult>;
  chaseComments(sessionId: string, comments: Array<Omit<IntentComment, "sendStatus" | "sessionId" | "createdAt" | "collectorAccount" | "senderAccount">>, collectorAccount?: DouyinAccountRef): Promise<number>;
  analyzeIntents(sessionId: string, commentIds: string[]): {
    comments: {
      analysisSource: "agent";
      intentLevel: IntentLevel;
      intentReason: string;
      confidence: number;
      commentId: string;
      sourceAccount: string;
      sourceAccountUrl: string;
      sourceAccountRef?: CompetitorAccountRef;
      sourceVideo?: CompetitorVideoRef;
      videoTitle: string;
      videoUrl: string;
      commentAuthor: string;
      commentAuthorId: string;
      avatarUrl?: string;
      commentText: string;
      commentCreatedAt?: string;
      ruleId?: string;
      matchedKeywords?: string[];
      draftMessage?: string;
      selected?: boolean;
      sendStatus: SendItemStatus;
      sendProgress?: string;
      failureCode?: string;
      deliveryVerifiedAt?: string;
      sessionId: string;
      createdAt: string;
      collectorAccount?: DouyinAccountRef;
      senderAccount?: DouyinAccountRef;
    }[];
  };
  reviewInterceptCandidates(sessionId: string, assessments: AgentIntentAssessment[]): {
    comments: IntentComment[];
    excluded: string[];
  };
  prepareBatch(agentId: string, sessionId: string, items: BatchDmItem[]): Promise<BatchDmProposal>;
  authorizeBatch(agentId: string, sessionId: string, input: {
    proposalId: string;
    confirmationToken: string;
    confirm: boolean;
  }): Promise<BatchDmAuthorization>;
  sendAuthorizedBatch(agentId: string, sessionId: string, input: {
    authorizationId: string;
  }): Promise<BatchDmResult>;
  sendBatch(agentId: string, sessionId: string, input: {
    proposalId: string;
    confirmationToken: string;
    confirm: boolean;
  }): Promise<BatchDmResult>;
  account: (sessionId?: string) => Promise<{
    account?: DouyinAccountRef | undefined;
  }>;
  boardForSession(sessionId: string): Promise<CommentOpsBoard & {
    comments: IntentComment[];
    stats: Record<string, number>;
    accounts: Array<{
      name: string;
      url: string;
      videos: number;
      comments: number;
    }>;
    currentAccount?: DouyinAccountRef;
    collectorAccounts: DouyinAccountRef[];
    senderAccounts: DouyinAccountRef[];
    chaseRuns: ChaseRun[];
    interceptRules: InterceptRule[];
  }>;
  prepare(agentId: string, sessionId: string, input: {
    recipient: string;
    message: string;
  }): Promise<Proposal>;
  send(agentId: string, sessionId: string, input: {
    proposalId: string;
    confirmationToken: string;
    recipient: string;
    message: string;
    confirm: boolean;
  }): Promise<{
    senderAccount?: DouyinAccountRef | undefined;
    proposalId: string;
  }>;
  board(sessionId: string): CommentOpsBoard & {
    comments: IntentComment[];
    stats: Record<string, number>;
    accounts: Array<{
      name: string;
      url: string;
      videos: number;
      comments: number;
    }>;
    currentAccount?: DouyinAccountRef;
    collectorAccounts: DouyinAccountRef[];
    senderAccounts: DouyinAccountRef[];
    chaseRuns: ChaseRun[];
    interceptRules: InterceptRule[];
  };
};
//#endregion
export { AgentIntentAssessment, BatchDmAuthorization, BatchDmItem, BatchDmProposal, BatchDmResult, BoardItem, BoardItemKind, BoardItemStatus, ChaseResult, ChaseRun, CommentOpsBoard, CommentOpsError, CommentOpsServiceOptions, CompetitorAccountRef, CompetitorVideoRef, DouyinAccountRef, EgoRunner, IntentComment, IntentLevel, InterceptChannel, InterceptRule, InterceptRuleInput, Proposal, SendItemStatus, createCommentOpsService };
//# sourceMappingURL=core.d.ts.map