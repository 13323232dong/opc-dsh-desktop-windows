import { CommentOpsError, createCommentOpsService } from "./core.js";
import { Context } from "@deepseek-ai/cordis";

//#region src/index.d.ts
declare const name = "opc-douyin-comment-ops";
declare const inject: string[];
interface Config {
  egoCommand: string;
  maxResults: number;
  stateFile?: string;
}
declare const Config: any;
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { CommentOpsError, Config, apply, createCommentOpsService, inject, name };
//# sourceMappingURL=index.d.ts.map