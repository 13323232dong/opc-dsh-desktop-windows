# DSH AI 客服

Mac 微信桌面 AI 客服插件。通过 DSH 对话发起文本发送，或为指定联系人开启自动回复。自动化使用原生 Accessibility，不解密聊天数据库，不注入微信进程。

## 安装与开发

需要 macOS、已登录的微信和辅助功能权限。Windows 返回不支持，不影响其他插件。执行 `npm ci`、`npm run build`、`npm test` 后使用 `npm pack` 生成分发包，在桌面 Profile 中注册该包。客户端标签为“AI 客服”。

`npm run typecheck` 当前执行 JavaScript 语法检查，不代表 TypeScript 静态类型验证。

工具以 `wechat_customer_service_` 为前缀：status、find_contact、read_chat、send、watch、pause、tasks。发送工具返回任务；只有任务状态 `sent` 表示微信客户端出现本次新增出站消息，不表示对方已读。`unknown` 不自动重发。

明确要求给某联系人发送某段文本即可执行；开启指定联系人托管即授权其后续新消息自动回复。停止或人工接管后不继续自动回复。自动回复先只读检索桌面已关联的第二大脑，再由当前 DSH 模型根据检索片段生成；知识库或索引不可用时保留待回复消息，不凭空发送。

本机运行数据与模型路由保存在用户 Application Support 下，不包含在分发包中。模型路由仅记录 provider/model 名称，凭据由 DSH 管理。发送任务只保存知识引用标题和相对路径，不保存完整检索片段。

## 当前验收

参见 [验收记录](docs/acceptance.md)。构建、模拟测试与真实消息发送分别记录，不能互相替代。
