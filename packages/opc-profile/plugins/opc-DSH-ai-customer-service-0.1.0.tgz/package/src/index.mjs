import { homedir } from 'node:os';
import { join } from 'node:path';
import { mkdirSync,readFileSync,writeFileSync,renameSync } from 'node:fs';
import { defineTool } from '@deepseek-ai/dsh-tools';
import z from '@deepseek-ai/schemastery';
import { CustomerService } from './core.mjs';
import { MacWechatAdapter } from './macos.mjs';
import { createReplyGenerator } from './reply.mjs';
import { createKnowledgeReplyGenerator, createSecondBrainSearch } from './knowledge.mjs';
export const name='ai-customer-service';
export const inject=['tools','webServer','systemPrompt','llm'];
export const Config=z.object({stateDir:z.string().default('')});
const installed=new WeakSet();
export function apply(ctx,config={}) {
  if(installed.has(ctx.root)) return;
  installed.add(ctx.root);
  const stateDir=config.stateDir||join(homedir(),'Library','Application Support','DSH-ai-customer-service');
  mkdirSync(stateDir,{recursive:true,mode:0o700});
  const routeFile=join(stateDir,'model-route.json');
  let modelRoute={};
  try { modelRoute=JSON.parse(readFileSync(routeFile,'utf8')); } catch{}
  const replyGenerator=createKnowledgeReplyGenerator({search:createSecondBrainSearch(),reply:createReplyGenerator(ctx,contact=>modelRoute[contact?.name])});
  const service=new CustomerService({stateDir,adapter:new MacWechatAdapter(),replyGenerator});
  const fields={contact:{type:'string',required:true,description:'微信联系人精确名称'}};
  const specs=[
    ['status','查看微信连接、客服状态及错误',{},()=>service.status()],
    ['find_contact','搜索微信联系人，不发送',fields,a=>service.findContact(a.contact)],
    ['read_chat','读取指定微信会话',fields,a=>service.readChat(a.contact)],
    ['send','执行用户已明确要求的微信发送，后台校验后入队；不需要重复确认',{...fields,text:{type:'string',required:true},requestId:{type:'string',required:true,description:'同一次发送重试必须使用相同请求ID'}},(a,e)=>service.send({...a,sessionId:String(e?.agent?.session?.id??'desktop')})],
    ['watch','用户指定联系人并要求自动回复后开启托管；关闭可用 enabled=false',{...fields,enabled:{type:'boolean',required:true},businessInstructions:{type:'string'},style:{type:'string'}},(a,e)=>{
      const agent=e?.agent; const header=agent?.session?.requestHeader?.()?.config;
      const provider=agent?.options?.provider||header?.provider; const model=agent?.options?.model||header?.model;
      if(a.enabled && (!provider||!model)) throw new Error('WECHAT_MODEL_UNAVAILABLE');
      if(provider&&model) {modelRoute={...modelRoute,[a.contact]:{provider,model}};writeFileSync(`${routeFile}.tmp`,JSON.stringify(modelRoute),{mode:0o600});renameSync(`${routeFile}.tmp`,routeFile);}
      return service.watch(a);
    }],
    ['pause','暂停指定微信联系人的自动客服',fields,a=>service.pause(a.contact)],
    ['tasks','查询微信发送任务状态；sent仅表示客户端显示已发送',{},()=>service.tasks()],
  ];
  for(const [suffix,description,parameters,execute] of specs) ctx.tools.register(defineTool({name:`wechat_customer_service_${suffix}`,description:`【AI 客服】${description}`,parameters,
    output:{schema:{type:'object',additionalProperties:true},render:(_a,result)=>[{type:'text',text:JSON.stringify(result)}]},
    execute:async(a,e)=>({result:await execute(a,e)}),
  }));
  ctx.systemPrompt.section({name:'ai-customer-service:routing',order:125,text:'Mac 桌面微信及 AI 客服优先调用 wechat_customer_service_* 工具，无需 device_id。用户明确指定收件人和消息即为本次发送授权，不重复确认；开启指定联系人托管即授权该联系人的自动回复。发送返回 queued 时继续查询 tasks，不得说已发送；只有 sent 才可说微信客户端显示已发送，unknown 不重试。不得调用旧 Android 微信工具代替本插件。'});
  ctx.webServer.register({kind:'prefix',path:'/plugins/ai-customer-service',handler:async(req,res)=>{
    res.setHeader('content-type','application/json; charset=utf-8');res.setHeader('cache-control','no-store');
    // Local desktop service only; reject browser requests from other origins.
    const host=req.headers.host??''; const origin=req.headers.origin;
    if(!/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host) || (origin && origin!==`http://${host}`)) {res.writeHead(403);res.end(JSON.stringify({error:'LOCAL_DESKTOP_REQUIRED'}));return;}
    try{
      const path=new URL(req.url,'http://localhost').pathname;
      if(req.method==='GET'&&path==='/plugins/ai-customer-service/status'){res.end(JSON.stringify(await service.status()));return;}
      if(req.method!=='POST' || req.headers['x-dsh-customer-service']!=='1'){res.writeHead(405);res.end('{}');return;}
      let body='';for await(const part of req){body+=part;if(Buffer.byteLength(body)>16384)throw new Error('REQUEST_TOO_LARGE');}
      const args=JSON.parse(body||'{}'); let result;
      if(path.endsWith('/send')) result=await service.send(args);
      else if(path.endsWith('/pause')) result=await service.pause(args.contact);
      else if(path.endsWith('/watch')) {if(args.enabled&&!modelRoute[typeof args.contact==='string'?args.contact:args.contact?.name])throw new Error('WECHAT_MODEL_UNAVAILABLE: 请先在DSH对话为该联系人开启客服以选择模型');result=await service.watch(args);}
      else {res.writeHead(404);res.end('{}');return;}
      res.end(JSON.stringify({result}));
    }catch(error){res.writeHead(400);res.end(JSON.stringify({error:error.code||'CUSTOMER_SERVICE_ERROR',message:error.code?'请查看工具状态中的诊断信息':String(error.message).slice(0,180)}));}
  }});
  service.start();
  ctx.on('dispose',()=>{service.stop();installed.delete(ctx.root);});
}
