import { build } from 'esbuild';
await build({entryPoints:['src/client.jsx'],bundle:true,format:'cjs',platform:'browser',external:['react','react/jsx-runtime'],outfile:'lib/client.cjs',jsx:'automatic'});
