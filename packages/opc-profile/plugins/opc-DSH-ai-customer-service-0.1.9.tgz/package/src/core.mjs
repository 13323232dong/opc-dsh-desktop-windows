import { randomUUID } from 'node:crypto';
import { Store } from './store.mjs';

const ACTIVE=new Set(['locating','inputting','sending','verifying']);
const HALT=new Set(['WECHAT_ACCOUNT_CHANGED','WECHAT_ACCOUNT_UNAVAILABLE','WECHAT_LOGIN_REQUIRED','WECHAT_NOT_RUNNING','WECHAT_PLATFORM_RESTRICTED','WECHAT_PLATFORM_REJECTED','WECHAT_PERMISSION_DENIED','WECHAT_ACCESSIBILITY_REQUIRED']);
const copy=value=>structuredClone(value);
const field=(value,name,max=4000)=>{if(typeof value!=='string'||!value.trim()||value.length>max) throw new Error(`INVALID_${name}`); return value;};
function failure(error) {
 const code=String(error?.code||error?.message||'WECHAT_AUTOMATION_ERROR');
 return /^[A-Z][A-Z0-9_]{2,80}$/.test(code)?code:'WECHAT_AUTOMATION_ERROR';
}
function responsibility(code) {
 if(code.includes('KNOWLEDGE')) return '第二大脑知识库';
 if(code.includes('MODEL')) return '模型服务';
 if(code.includes('PERMISSION')||code.includes('ACCESSIBILITY')) return '桌面权限';
 if(code.includes('PLATFORM')) return '微信平台';
 if(code.includes('UNKNOWN')||code.includes('INTERRUPTED')) return '发送结果未确认';
 return '桌面自动化';
}
function errorDetail(code) {
 if(code==='WECHAT_KNOWLEDGE_UNAVAILABLE')return {code,message:'第二大脑检索不可用，待回复消息已保留，请检查知识库与索引'};
 if(code==='WECHAT_HISTORY_RESYNC_REQUIRED')return {code,message:'微信可见消息历史发生变化，已暂停自动回复；请重新开启托管建立新基线'};
 const nativeMessages={WECHAT_ACCESSIBILITY_REQUIRED:'请在系统设置授予桌面应用辅助功能权限',WECHAT_NOT_RUNNING:'请先打开并登录 Mac 微信',WECHAT_ACCOUNT_UNAVAILABLE:'无法确认当前微信账号，任务已停止',WECHAT_PLATFORM_REJECTED:'微信界面明确显示发送失败或接收限制',WECHAT_FOCUS_CHANGED:'微信窗口焦点被切换，本条操作已停止',WECHAT_CONTACT_AMBIGUOUS:'找到多个同名联系人，未选择或发送',WECHAT_EXISTING_DRAFT:'目标聊天已有输入草稿，未覆盖或发送',WECHAT_CHAT_MISMATCH:'当前微信聊天标题与目标不一致',WECHAT_DIRECTION_UNKNOWN:'无法确认消息方向，未自动回复',WECHAT_MODEL_UNAVAILABLE:'客服模型不可用，待回复消息已保留',WECHAT_WORKER_ALREADY_RUNNING:'另一个桌面实例正在控制微信，此实例仅查看状态'};
 if(nativeMessages[code])return {code,message:nativeMessages[code]};
 const messages={WECHAT_ACCOUNT_CHANGED:'微信账号已切换，后续任务已停止',WECHAT_LOGIN_REQUIRED:'微信未登录或账号无法识别',WECHAT_PLATFORM_RESTRICTED:'微信界面明确提示操作受限',WECHAT_PERMISSION_DENIED:'缺少 macOS 辅助功能权限',WECHAT_CONTACT_NOT_FOUND:'未找到指定联系人',WECHAT_CONTACT_MISMATCH:'当前聊天与目标联系人不一致',WECHAT_SEND_UNKNOWN:'未确认新增出站消息，请核查聊天记录后再决定是否重试',WECHAT_SEND_INTERRUPTED:'发送过程中服务中断，未自动重发以免重复',WECHAT_WATCH_PAUSED:'该联系人已暂停自动回复',WECHAT_MANUAL_TAKEOVER:'检测到人工发送，自动回复已暂停',MODEL_UNAVAILABLE:'模型服务不可用，待回复消息已保留'};
 return {code,message:messages[code]||'操作未完成，请检查桌面自动化状态与错误码'};
}

export class CustomerService {
 constructor({stateDir,adapter,replyGenerator,pollMs=5000,debounceMs=3000}) {
  this.store=new Store(stateDir); this.state=this.store.read(); this.adapter=adapter;
  this.replyGenerator=replyGenerator; this.pollMs=pollMs; this.debounceMs=debounceMs;
  this.chain=Promise.resolve(); this.running=false; this.stopped=false; this.ticking=false;
  this.readOnly=!this.store.acquire();this.connection=null;
  // A crashed send might already have reached WeChat. Never replay it automatically.
  this.state={...this.state,tasks:this.state.tasks.map(task=>ACTIVE.has(task.status)?{...task,status:'unknown',failureCode:'WECHAT_SEND_INTERRUPTED',error:errorDetail('WECHAT_SEND_INTERRUPTED'),responsibility:'发送结果未确认',updatedAt:Date.now()}:task)};
  if(!this.readOnly)this.store.write(this.state);else this.state=this.store.read();
 }
 save(next) {this.store.write(next);this.state=next;}
 updateTask(id,patch) {this.save({...this.state,tasks:this.state.tasks.map(task=>task.id===id?{...task,...patch,...(patch.failureCode?{error:errorDetail(patch.failureCode)}:{}),updatedAt:Date.now()}:task)});}
 updateWatch(id,patch) {this.save({...this.state,watches:this.state.watches.map(w=>w.id===id?{...w,...patch,...(patch.failureCode?{error:errorDetail(patch.failureCode)}:{}),updatedAt:Date.now()}:w)});}
 locked(operation) {const result=this.chain.then(operation);this.chain=result.catch(()=>{});return result;}
 async account(expected) {
  const status=await this.adapter.status();
  this.connection=status;
  if(!status.ready||!status.accountId) throw new Error(status.failureCode||'WECHAT_LOGIN_REQUIRED');
  if(expected&&status.accountId!==expected) throw new Error('WECHAT_ACCOUNT_CHANGED');
  return status.accountId;
 }
 async status() {
  let connection;
  try {connection=this.running&&this.connection?this.connection:await this.locked(()=>this.adapter.status());this.connection=connection;} catch(error){connection={ready:false,failureCode:failure(error)};}
  if(this.readOnly)this.state=this.store.read();
  const globalPreview=this.state.globalPreview?.accountId===connection.accountId?this.state.globalPreview:{enabled:false,accountId:connection.accountId||'',baseline:{},events:[]};
  return {...connection,watches:copy(this.state.watches.filter(w=>w.accountId===connection.accountId)),globalPreview:copy(globalPreview),tasks:this.tasks(),running:this.running,readOnly:this.readOnly};
 }
 findContact(name) {field(name,'CONTACT',200);if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');return this.locked(()=>this.adapter.findContact(name));}
 async contact(value) {
  if(typeof value==='string') return this.contact(await this.adapter.findContact(field(value,'CONTACT',200)));
  if(!value||typeof value!=='object') throw new Error('INVALID_CONTACT');
  const id=field(value.id||value.contactId,'CONTACT_ID',500);
  const name=field(value.name||value.title,'CONTACT_NAME',200);
  return {id,name,...(value.accountId?{accountId:field(value.accountId,'ACCOUNT_ID',500)}:{})};
 }
 readChat(value) {if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');return this.locked(async()=>{await this.account();return this.adapter.readChat(await this.contact(value));});}
 tasks() {if(this.readOnly)this.state=this.store.read();return copy(this.state.tasks.filter(t=>!this.connection?.accountId||t.accountId===this.connection.accountId));}
 async send({contact,text,requestId,sessionId='',watchId,accountId:expected,knowledgeSources=[]}) {
  field(text,'TEXT');field(requestId,'REQUEST_ID',200);
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  const result=await this.locked(async()=>{
   const accountId=await this.account(expected); const resolved=await this.contact(contact);
   if(resolved.accountId&&resolved.accountId!==accountId)throw new Error('WECHAT_ACCOUNT_CHANGED');
   const existing=this.state.tasks.find(t=>t.accountId===accountId&&t.requestId===requestId);
   if(existing) {
    if(existing.contact.id!==resolved.id||existing.text!==text) throw new Error('IDEMPOTENCY_CONFLICT');
    return copy(existing);
   }
   const task={id:randomUUID(),requestId,accountId,contact:{...resolved,accountId},text,sessionId,status:'queued',watchId,knowledgeSources:copy(knowledgeSources),createdAt:Date.now(),updatedAt:Date.now()};
   this.save({...this.state,tasks:[...this.state.tasks,task]}); return copy(task);
  });
  this.kick(); return result;
 }
 kick() {
  if(this.running||this.stopped||this.readOnly) return;
  this.running=true;
  queueMicrotask(async()=>{
   try {
    while(!this.stopped) {
     const task=this.state.tasks.find(t=>t.status==='queued'); if(!task) break;
     await this.locked(()=>this.execute(task));
    }
   } catch(error) {this.lastError=failure(error);} finally {this.running=false;if(this.stopped&&!this.ticking)this.store.release();}
  });
 }
 async execute(task) {
  try {
   await this.account(task.accountId);
   if(task.watchId&&!this.state.watches.some(w=>w.id===task.watchId&&w.enabled)) {
    this.updateTask(task.id,{status:'skipped',failureCode:'WECHAT_WATCH_PAUSED'});return;
   }
   if(task.watchId) {
    const watch=this.state.watches.find(w=>w.id===task.watchId);
    await this.inspectWatch(watch);
    const inspected=this.state.watches.find(w=>w.id===task.watchId);
    if(!inspected?.enabled) {
     this.updateTask(task.id,{status:'skipped',failureCode:inspected?.failureCode||'WECHAT_WATCH_PAUSED'});return;
    }
   }
   this.updateTask(task.id,{status:'locating'});
   const result=await this.adapter.send({...task.contact,accountId:task.accountId},task.text,{onStage:stage=>{
    if(!ACTIVE.has(stage)) throw new Error('INVALID_SEND_STAGE');
    this.updateTask(task.id,{status:stage});
   }});
   if(result?.status!=='sent'||!result.evidence) {
    this.updateTask(task.id,{status:'unknown',failureCode:'WECHAT_SEND_UNKNOWN',responsibility:'发送结果未确认'});return;
   }
   this.updateTask(task.id,{status:'sent',evidence:result.evidence,failureCode:null});
  } catch(error) {
   const code=failure(error);const current=this.state.tasks.find(t=>t.id===task.id);
   const status=['sending','verifying'].includes(current.status)&&!HALT.has(code)?'unknown':'failed';
   this.updateTask(task.id,{status,failureCode:code,responsibility:responsibility(code)});
   if(HALT.has(code)) {
    this.save({...this.state,tasks:this.state.tasks.map(t=>t.accountId===task.accountId&&t.status==='queued'?{...t,status:'skipped',failureCode:code,error:errorDetail(code),responsibility:responsibility(code),updatedAt:Date.now()}:t),watches:this.state.watches.map(w=>w.accountId===task.accountId?{...w,enabled:false,failureCode:code,error:errorDetail(code)}:w)});
   }
  }
 }
 async watch({contact,enabled=true,businessInstructions='',style=''}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(typeof businessInstructions!=='string'||businessInstructions.length>20000||typeof style!=='string'||style.length>2000) throw new Error('INVALID_INSTRUCTIONS');
  return this.locked(async()=>{
   const accountId=await this.account();const found=await this.contact(contact);
   if(found.accountId&&found.accountId!==accountId)throw new Error('WECHAT_ACCOUNT_CHANGED');
   const resolved={...found,accountId};
   const chat=await this.adapter.readChat(resolved);this.checkChat(chat,accountId,resolved);
   const old=this.state.watches.find(w=>w.accountId===accountId&&w.contact.id===resolved.id);
   const watch={id:old?.id||randomUUID(),revision:randomUUID(),accountId,contact:resolved,enabled:!!enabled,businessInstructions,style,seen:chat.messages.map(m=>m.id),observedIds:chat.messages.map(m=>m.id),pending:[],changedAt:0,createdAt:old?.createdAt||Date.now(),updatedAt:Date.now()};
   this.save({...this.state,watches:[...this.state.watches.filter(w=>w.id!==watch.id),watch]}); return copy(watch);
  });
 }
 async pause(contact) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  return this.locked(async()=>{
   const accountId=await this.account();const resolved=await this.contact(contact);
   const watch=this.state.watches.find(w=>w.accountId===accountId&&w.contact.id===resolved.id);
   if(!watch) throw new Error('WATCH_NOT_FOUND');this.updateWatch(watch.id,{enabled:false,pending:[]});
   return copy(this.state.watches.find(w=>w.id===watch.id));
  });
 }
 async globalPreview({enabled}) {
  if(this.readOnly)throw new Error('WECHAT_WORKER_ALREADY_RUNNING');
  if(typeof enabled!=='boolean')throw new Error('INVALID_ENABLED');
  return this.locked(async()=>{
   const accountId=await this.account();
   if(!enabled) {
    const current=this.state.globalPreview||{};
    const next={...current,enabled:false,accountId,updatedAt:Date.now()};
    this.save({...this.state,globalPreview:next});return copy(next);
   }
   const result=await this.adapter.listChats();
   if(result?.accountId!==accountId||!Array.isArray(result?.chats))throw new Error('WECHAT_CHAT_LIST_UNAVAILABLE');
   const baseline=Object.fromEntries(result.chats.filter(chat=>chat?.id&&chat.unreadCount>0).map(chat=>[chat.id,chat.signature]));
   const next={enabled:true,accountId,baseline,events:[],startedAt:Date.now(),updatedAt:Date.now()};
   this.save({...this.state,globalPreview:next});return copy(next);
  });
 }
 async inspectGlobalPreview() {
  const monitor=this.state.globalPreview;
  if(!monitor?.enabled) return;
  try {
   const accountId=await this.account(monitor.accountId);
   const result=await this.adapter.listChats();
   if(result?.accountId!==accountId||!Array.isArray(result?.chats))throw new Error('WECHAT_CHAT_LIST_UNAVAILABLE');
   const chats=result.chats.filter(chat=>chat&&typeof chat.id==='string'&&typeof chat.title==='string'&&typeof chat.preview==='string'&&chat.unreadCount>0&&typeof chat.signature==='string');
   const baseline=Object.fromEntries(chats.map(chat=>[chat.id,chat.signature]));
   const additions=chats.filter(chat=>monitor.baseline?.[chat.id]!==chat.signature).map(chat=>({id:randomUUID(),chatId:chat.id,title:chat.title,preview:chat.preview,unreadCount:chat.unreadCount,receivedAt:Date.now()}));
   const events=[...(monitor.events||[]),...additions].slice(-100);
   this.save({...this.state,globalPreview:{...monitor,baseline,events,updatedAt:Date.now(),failureCode:null}});
  } catch(error) {
   const code=failure(error);this.save({...this.state,globalPreview:{...monitor,enabled:!HALT.has(code),failureCode:code,updatedAt:Date.now()}});
  }
 }
 checkChat(chat,accountId,contact) {
  if(chat.accountId!==accountId) throw new Error('WECHAT_ACCOUNT_CHANGED');
  if(chat.contactId!==contact.id) throw new Error('WECHAT_CONTACT_MISMATCH');
  if(!Array.isArray(chat.messages)||chat.messages.some(m=>typeof m.id!=='string'||!m.id)) throw new Error('WECHAT_MESSAGE_ID_UNAVAILABLE');
 }
 async inspectWatch(watch) {
  await this.account(watch.accountId);
  const chat=await this.adapter.readChat(watch.contact);this.checkChat(chat,watch.accountId,watch.contact);
  const prior=watch.observedIds||watch.seen;
  const currentIds=chat.messages.map(m=>m.id);
  const lastKnownIndex=prior.length?currentIds.indexOf(prior.at(-1)):-1;
  const overlapBefore=prior.filter(id=>currentIds.includes(id));
  const overlapAfter=currentIds.filter(id=>prior.includes(id));
  if(prior.length&&(lastKnownIndex<0||JSON.stringify(overlapBefore)!==JSON.stringify(overlapAfter))) {
   this.updateWatch(watch.id,{enabled:false,pending:[],failureCode:'WECHAT_HISTORY_RESYNC_REQUIRED',responsibility:'桌面自动化'});return null;
  }
  // The visible prefix can grow when history is scrolled into view. Only
  // messages after the previous tail are eligible incoming events.
  const fresh=chat.messages.slice(lastKnownIndex+1).filter(m=>!watch.seen.includes(m.id));
  const ownIds=new Set(this.state.tasks.filter(t=>t.accountId===watch.accountId&&t.contact.id===watch.contact.id&&t.status==='sent').map(t=>t.evidence?.messageId));
  if(fresh.some(m=>m.direction==='outgoing'&&!ownIds.has(m.id))) {
   this.updateWatch(watch.id,{enabled:false,pending:[],failureCode:'WECHAT_MANUAL_TAKEOVER'});return null;
  }
  const incoming=fresh.filter(m=>m.direction==='incoming'&&typeof m.text==='string'&&m.text.trim());
  const pending=[...watch.pending,...incoming];
  const changedAt=incoming.length?Date.now():watch.changedAt;
  this.updateWatch(watch.id,{seen:[...new Set([...watch.seen,...currentIds])],observedIds:currentIds,pending,changedAt});
  if(!pending.length||Date.now()-changedAt<this.debounceMs) return null;
  return {...watch,pending,changedAt};
 }
 async tick() {
  if(this.ticking||this.stopped||this.readOnly) return;this.ticking=true;
  try {
   await this.locked(()=>this.inspectGlobalPreview());
   for(const snapshot of this.state.watches.filter(w=>w.enabled)) {
    try {
     const batch=await this.locked(async()=>{
      const current=this.state.watches.find(w=>w.id===snapshot.id);return current?.enabled?this.inspectWatch(current):null;
     });
     if(!batch) continue;
     const requestId=`watch:${batch.id}:${batch.pending.at(-1).id}`;
     // Enqueue and cursor updates are separate durable writes. After a crash,
     // an existing task owns this batch even if the model would now reply differently.
     if(this.state.tasks.some(t=>t.accountId===batch.accountId&&t.requestId===requestId)) {
      this.updateWatch(batch.id,{pending:[]});continue;
     }
     if(!this.replyGenerator) throw new Error('MODEL_UNAVAILABLE');
     const reply=await this.replyGenerator({contact:batch.contact,messages:copy(batch.pending),businessInstructions:batch.businessInstructions,style:batch.style});
     const text=typeof reply==='string'?reply:reply.text;
     const knowledgeSources=typeof reply==='string'?[]:reply.knowledgeSources;
     const current=this.state.watches.find(w=>w.id===batch.id);
     if(!current?.enabled||current.revision!==batch.revision) continue;
     await this.send({contact:batch.contact,text,knowledgeSources,requestId,watchId:batch.id,accountId:batch.accountId});
     this.updateWatch(batch.id,{pending:[],failureCode:null});
    } catch(error) {
     const code=failure(error);this.updateWatch(snapshot.id,{failureCode:code,responsibility:responsibility(code),...(HALT.has(code)?{enabled:false}:{})});
    }
   }
  } finally {this.ticking=false;if(this.stopped&&!this.running)this.store.release();}
 }
 start() {if(!this.store.acquire()){this.readOnly=true;return;}this.readOnly=false;this.stopped=false;if(!this.timer){this.timer=setInterval(()=>{this.tick().catch(()=>{});this.kick();},this.pollMs);this.timer.unref?.();}this.kick();}
 stop() {this.stopped=true;if(this.timer)clearInterval(this.timer);this.timer=null;if(!this.running&&!this.ticking)this.store.release();}
}
