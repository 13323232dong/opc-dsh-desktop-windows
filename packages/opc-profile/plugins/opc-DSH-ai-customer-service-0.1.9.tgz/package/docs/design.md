# AI 客服需求与技术设计

## 用户行为

用户在 DSH 对话明确指定收件人和正文后，Agent 调用发送工具入队，随后查询任务。无需重复审批。看板发送按钮具有相同效果。指定联系人托管由用户明确开启，自动处理新文本消息，支持暂停与恢复。

全局消息预览由用户显式开启，仅读取微信会话列表中带未读标记的摘要，建立基线后才记录变化。预览不打开会话、不调用模型、不创建发送任务；DSH 对话输入框为空时，客户端才将最新摘要填入草稿，绝不自动提交。微信 Accessibility 不能可靠识别会话列表摘要方向，因此该模式严格以“未读会话摘要”命名，不声称已读取全部联系人历史或完整消息正文。

## 分层

- `src/index.mjs`：DSH 工具、系统提示、同源本机 HTTP 接口、当前模型路由。
- `src/core.mjs`、`src/store.mjs`：本机持久队列、串行控制、幂等、消息游标、自动回复与跨进程锁。
- `src/macos.mjs`、`native/main.swift`：有界 JSON 协议及 macOS 微信 Accessibility 适配器。只允许预定义操作。
- `src/reply.mjs`：通过 DSH llm 服务生成回复，不读取或复制供应商密钥。
- `src/knowledge.mjs`：使用桌面已安装的 `@opc/dsh-second-brain/core` 只读检索现有资料库，再将带来源的片段交给模型；不创建资料库，不重建索引，不扫描额外目录。第二大脑缺失或检索失败时记录 `WECHAT_KNOWLEDGE_UNAVAILABLE` 并保留待处理消息。
- `src/client.jsx`：唯一 conversation.view 标签，任务阶段和异常提示。

## 接口

工具前缀 `wechat_customer_service_`：

| 工具 | 输入 | 返回 |
| --- | --- | --- |
| status | 无 | 连接、当前账号任务、托管状态 |
| request_accessibility | 无 | 打开 macOS 辅助功能授权入口；权限仍由用户手动允许 |
| find_contact | contact | 唯一匹配的联系人 |
| read_chat | contact | 当前可见文本及方向 |
| send | contact、text、requestId | 持久任务 |
| watch | contact、enabled、businessInstructions、style | 托管设置 |
| pause | contact | 暂停后的状态 |
| tasks | 无 | 任务列表 |
| global_preview | enabled | 开启/停止全局未读会话摘要预览，不回复、不发送 |

本地 UI 接口前缀 `/plugins/ai-customer-service`，GET `/status`，POST `/request-accessibility`、`/send`、`/watch`、`/pause`。写请求要求同源及自定义头，限制请求长度。运行于桌面回环地址，不设计为公网接口。

## 状态与恢复

发送依次经历 queued、locating、inputting、sending、verifying。只有确认新增出站消息才为 sent；执行前明确错误为 failed；可能已发送但无法核验为 unknown。unknown 不自动重试。验证码、登录及账号变化停止相关队列；任务保留稳定错误码和责任归属。

存储通过临时文件、fsync 和 rename 原子更新。进程锁保证同一用户状态目录只有一个 worker；第二实例只读。持久化不存储模型凭据。开发和正式应用使用同一默认状态目录，避免并发操作微信。

每个联系人模型路由记录 provider/model 名称；模型凭据始终由 DSH llm 解析。首次托管需由对话选择模型，UI 可沿用该联系人路由。

macOS 辅助功能权限归属于原生 `wechat-helper`。状态查询只报告权限，不弹系统设置；用户明确发起微信操作后，Agent 或看板可调用权限请求动作打开系统授权入口。最终允许动作仍由用户在系统设置中完成，插件不修改 TCC 数据库。

2026-09-17 知识库回复接线：每次新消息合并后检索至多五条资料，片段作为参考数据而非系统指令。生成结果连同 `knowledgeSources` 入队，任务只保存引用标题与相对路径，不保存完整检索正文。无匹配结果时允许询问或转人工，不得编造业务事实。来源记录只能证明检索依据，不能单独证明模型回复正确或微信已发送。

## 验收边界

模拟测试验证状态机和错误处理，真实桌面 DSH 对话验证工具可调用及消息发送。文本出现在客户端不代表对方已读。普通联系人入站自动回复必须有真实新消息证据；文件传输助手只能作为测试工具，不能代替此项证据。
